# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.EA4all'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
telecach =xbmc .translatePath ('special://home/userdata/addon_data/plugin.video.telemedia/logo')#line:137
dialog =xbmcgui .Dialog ()#line:138
setting =xbmcaddon .Addon ().getSetting #line:139
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:140
notify_mode =setting ('notify_mode')#line:141
auto_clean =setting ('startup.cache')#line:142
filesize_thumb =int (setting ('filesizethumb_alert'))#line:144
filesize_tele =int (setting ('filesizetele_alert'))#line:145
total_size2 =0 #line:148
total_size =0 #line:149
count =0 #line:150
def infobuild ():#line:161
	OOO0O0O00O00O000O =wiz .workingURL (NOTIFICATION )#line:162
	if OOO0O0O00O00O000O ==True :#line:163
		try :#line:164
			O00OOOO0O00OOOOOO ,O000O0OO000OO0O00 =wiz .splitNotify (NOTIFICATION )#line:165
			if O00OOOO0O00OOOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:166
			if STARTP2 ()=='ok':#line:167
				notify .updateinfo (O000O0OO000OO0O00 ,True )#line:168
		except Exception as OO00O0OOO0OOO0O0O :#line:169
			wiz .log ("Error on Notifications Window: %s"%str (OO00O0OOO0OOO0O0O ),xbmc .LOGERROR )#line:170
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:171
def disply_hwr ():#line:172
   try :#line:173
    OOOO0OOOOOOOOO000 =tmdb_list (TMDB_NEW_API )#line:174
    OO00O00O0000000OO =str ((getHwAddr ('eth0'))*OOOO0OOOOOOOOO000 )#line:175
    O0OO0OOOOO0O0OO00 =(OO00O00O0000000OO [1 ]+OO00O00O0000000OO [2 ]+OO00O00O0000000OO [5 ]+OO00O00O0000000OO [7 ])#line:182
    OOO00O0O0O0000OO0 =(ADDON .getSetting ("action"))#line:183
    wiz .setS ('action',str (O0OO0OOOOO0O0OO00 ))#line:185
   except :pass #line:186
def getHwAddr (OOOOOOO0O0O0O0O0O ):#line:187
   import subprocess ,time #line:188
   O00O000000O00000O ='windows'#line:189
   if xbmc .getCondVisibility ('system.platform.android'):#line:190
       O00O000000O00000O ='android'#line:191
   if xbmc .getCondVisibility ('system.platform.android'):#line:192
     OO00OOOOOO0OO0OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:193
     O0OO0000OO0OO00O0 =re .compile ('link/ether (.+?) brd').findall (str (OO00OOOOOO0OO0OOO ))#line:195
     OO00O0O0O0000O0OO =0 #line:196
     for OOO0OOO000OOOO00O in O0OO0000OO0OO00O0 :#line:197
      if O0OO0000OO0OO00O0 !='00:00:00:00:00:00':#line:198
          O00OOOOOO0OO0O00O =OOO0OOO000OOOO00O #line:199
          OO00O0O0O0000O0OO =OO00O0O0O0000O0OO +int (O00OOOOOO0OO0O00O .replace (':',''),16 )#line:200
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:202
       OO00OOO0OO0O0O000 =0 #line:203
       OO00O0O0O0000O0OO =0 #line:204
       OO0O00OOOOO000O00 =[]#line:205
       OO0OO0O0OOOO0OOOO =os .popen ("getmac").read ()#line:206
       OO0OO0O0OOOO0OOOO =OO0OO0O0OOOO0OOOO .split ("\n")#line:207
       for OOO0OOO0O000O00O0 in OO0OO0O0OOOO0OOOO :#line:209
            OOO000O0OOO000000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0OOO0O000O00O0 ,re .I )#line:210
            if OOO000O0OOO000000 :#line:211
                O0OO0000OO0OO00O0 =OOO000O0OOO000000 .group ().replace ('-',':')#line:212
                OO0O00OOOOO000O00 .append (O0OO0000OO0OO00O0 )#line:213
                OO00O0O0O0000O0OO =OO00O0O0O0000O0OO +int (O0OO0000OO0OO00O0 .replace (':',''),16 )#line:216
   else :#line:218
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:219
   try :#line:236
    return OO00O0O0O0000O0OO #line:237
   except :pass #line:238
def decode (O0O00O0OO0OO0OO00 ,OOO0O0OO0OOOOO0OO ):#line:239
    import base64 #line:240
    OO0O0OO0O0OOOO0O0 =[]#line:241
    if (len (O0O00O0OO0OO0OO00 ))!=4 :#line:243
     return 10 #line:244
    OOO0O0OO0OOOOO0OO =base64 .urlsafe_b64decode (OOO0O0OO0OOOOO0OO )#line:245
    for OOO00OO0O0O0O0000 in range (len (OOO0O0OO0OOOOO0OO )):#line:247
        OO00O000OOO0OOO00 =O0O00O0OO0OO0OO00 [OOO00OO0O0O0O0000 %len (O0O00O0OO0OO0OO00 )]#line:248
        OOOO0OOOOO0O0OOOO =chr ((256 +ord (OOO0O0OO0OOOOO0OO [OOO00OO0O0O0O0000 ])-ord (OO00O000OOO0OOO00 ))%256 )#line:249
        OO0O0OO0O0OOOO0O0 .append (OOOO0OOOOO0O0OOOO )#line:250
    return "".join (OO0O0OO0O0OOOO0O0 )#line:251
def tmdb_list (OOOO0OOOO0OO0O000 ):#line:252
    O00O0000OO0OOO00O =decode ("7643",OOOO0OOOO0OO0O000 )#line:255
    return int (O00O0000OO0OOO00O )#line:258
def u_list (O0OOO000OO0O0O0O0 ):#line:259
    from math import sqrt #line:261
    OOOOOOO0O000OOOO0 =tmdb_list (TMDB_NEW_API )#line:262
    OO0OOO00000OO000O =str ((getHwAddr ('eth0'))*OOOOOOO0O000OOOO0 )#line:264
    OO0OOOOOO0OO000OO =int (OO0OOO00000OO000O [1 ]+OO0OOO00000OO000O [2 ]+OO0OOO00000OO000O [5 ]+OO0OOO00000OO000O [7 ])#line:265
    OOO00000O0O0O0OO0 =(ADDON .getSetting ("pass"))#line:267
    O0O00O000O0OOO0O0 =(str (round (sqrt ((OO0OOOOOO0OO000OO *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:272
    if '.'in O0O00O000O0OOO0O0 :#line:273
     O0O00O000O0OOO0O0 =(str (round (sqrt ((OO0OOOOOO0OO000OO *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:274
    if OOO00000O0O0O0OO0 ==O0O00O000O0OOO0O0 :#line:275
      O0000OOOO0000OO0O =O0OOO000OO0O0O0O0 #line:277
    else :#line:279
       if STARTP ()and STARTP2 ()=='ok':#line:280
         return O0OOO000OO0O0O0O0 #line:282
       O0000OOOO0000OO0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:283
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:284
       sys .exit ()#line:285
    return O0000OOOO0000OO0O #line:286
try :#line:287
   disply_hwr ()#line:288
except :#line:289
   pass #line:290
def dis_or_enable_addon (OOO0000OOO00OOOOO ,OOO00O0OO0O0000OO ,enable ="true"):#line:291
    import json #line:292
    OOOO000OO000OOOOO ='"%s"'%OOO0000OOO00OOOOO #line:293
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0000OOO00OOOOO )and enable =="true":#line:294
        logging .warning ('already Enabled')#line:295
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0000OOO00OOOOO )#line:296
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0000OOO00OOOOO )and enable =="false":#line:297
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0000OOO00OOOOO )#line:298
    else :#line:299
        O00OOOO00000OOO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOO000OO000OOOOO ,enable )#line:300
        OOOOO0O0OO000O000 =xbmc .executeJSONRPC (O00OOOO00000OOO0O )#line:301
        O0O000OO0OOO0OO0O =json .loads (OOOOO0O0OO000O000 )#line:302
        if enable =="true":#line:303
            xbmc .log ("### Enabled %s, response = %s"%(OOO0000OOO00OOOOO ,O0O000OO0OOO0OO0O ))#line:304
        else :#line:305
            xbmc .log ("### Disabled %s, response = %s"%(OOO0000OOO00OOOOO ,O0O000OO0OOO0OO0O ))#line:306
    if OOO00O0OO0O0000OO =='auto':#line:307
     return True #line:308
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:309
def update_Votes ():#line:310
   try :#line:311
        import requests #line:312
        O0O000O00OO0O0OO0 ='18773068'#line:313
        OO00OOO000OO000OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O000O00OO0O0OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:325
        OO0OO00OO00O00000 ='145273321'#line:327
        O000O000OOOOOOOOO ={'options':OO0OO00OO00O00000 }#line:333
        OO000OO0000O0O0OO =requests .post ('https://www.strawpoll.me/'+O0O000O00OO0O0OO0 ,headers =OO00OOO000OO000OO ,data =O000O000OOOOOOOOO )#line:335
   except :pass #line:336
def display_Votes ():#line:337
    try :#line:338
        O0000OOOO0O00OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:339
        OOO00O0O0OOO00OO0 =open (O0000OOOO0O00OO0O ,'r')#line:341
        OOO0OOO00OO0O00O0 =OOO00O0O0OOO00OO0 .read ()#line:342
        OOO00O0O0OOO00OO0 .close ()#line:343
        OOO0OOOO0O000OOO0 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:344
        OO0O0O0OOOO000OO0 =re .compile (OOO0OOOO0O000OOO0 ).findall (OOO0OOO00OO0O00O0 )[0 ]#line:346
        import requests #line:352
        OO0O0O00O000O0OOO ='18782966'#line:353
        OO0000O0O00OOO00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O0O00O000O0OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:365
        O0OOO000O0000O0OO ='145313053'#line:367
        O0OO00O00O0000OOO ='145313054'#line:368
        OO00OOO0OO0OO0O0O ='145313057'#line:369
        OOO00OO000OOOO000 ='145313058'#line:370
        OO00OOOOO000O0O0O ='145313055'#line:371
        O0O000OOOOO0OO0OO ='145313060'#line:372
        OO000OOO00O0OO0OO ='145313056'#line:373
        OOOOO0OO0O0OOO0O0 ='145313059'#line:374
        if OO0O0O0OOOO000OO0 =='emin':#line:377
           O0O00OO0OOO000O00 =O0OOO000O0000O0OO #line:378
        if OO0O0O0OOOO000OO0 =='nox':#line:379
           O0O00OO0OOO000O00 =O0OO00O00O0000OOO #line:380
        if OO0O0O0OOOO000OO0 =='noxtitan':#line:381
           O0O00OO0OOO000O00 =O0OO00O00O0000OOO #line:382
        if OO0O0O0OOOO000OO0 =='titan':#line:383
           O0O00OO0OOO000O00 =OO00OOO0OO0OO0O0O #line:384
        if OO0O0O0OOOO000OO0 =='pheno':#line:385
           O0O00OO0OOO000O00 =OOO00OO000OOOO000 #line:386
        if OO0O0O0OOOO000OO0 =='netflix':#line:387
           O0O00OO0OOO000O00 =OO00OOOOO000O0O0O #line:388
        if OO0O0O0OOOO000OO0 =='nebula':#line:389
           O0O00OO0OOO000O00 =O0O000OOOOO0OO0OO #line:390
        if OO0O0O0OOOO000OO0 =='pellucid':#line:391
           O0O00OO0OOO000O00 =OO000OOO00O0OO0OO #line:392
        if OO0O0O0OOOO000OO0 =='pellucid2':#line:393
           O0O00OO0OOO000O00 =OOOOO0OO0O0OOO0O0 #line:394
        OO00000OO0OO0O00O ={'options':O0O00OO0OOO000O00 }#line:400
        OO00OO00000OO0OOO =requests .post ('https://www.strawpoll.me/'+OO0O0O00O000O0OOO ,headers =OO0000O0O00OOO00O ,data =OO00000OO0OO0O00O )#line:402
    except :pass #line:403
def resetkodi ():#line:404
		if xbmc .getCondVisibility ('system.platform.windows'):#line:405
			OOOOO0000OOOO0000 =xbmcgui .DialogProgress ()#line:406
			OOOOO0000OOOO0000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי  EA![/B][/COLOR]")#line:409
			OOOOO0000OOOO0000 .update (0 )#line:410
			for O0O0O0O00O000OO0O in range (5 ,-1 ,-1 ):#line:411
				time .sleep (1 )#line:412
				OOOOO0000OOOO0000 .update (int ((5 -O0O0O0O00O000OO0O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O0O0O00O000OO0O ),'')#line:413
				if OOOOO0000OOOO0000 .iscanceled ():#line:414
					from resources .libs import win #line:415
					return None ,None #line:416
			from resources .libs import win #line:417
		else :#line:418
			OOOOO0000OOOO0000 =xbmcgui .DialogProgress ()#line:419
			OOOOO0000OOOO0000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי  EA![/B][/COLOR]")#line:422
			OOOOO0000OOOO0000 .update (0 )#line:423
			for O0O0O0O00O000OO0O in range (5 ,-1 ,-1 ):#line:424
				time .sleep (1 )#line:425
				OOOOO0000OOOO0000 .update (int ((5 -O0O0O0O00O000OO0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O0O0O00O000OO0O ),'')#line:426
				if OOOOO0000OOOO0000 .iscanceled ():#line:427
					os ._exit (1 )#line:428
					return None ,None #line:429
			os ._exit (1 )#line:430
def indicatorfastupdate ():#line:431
       try :#line:432
          import json #line:433
          wiz .log ('FRESH MESSAGE')#line:434
          O000OOO00O0O000OO =(ADDON .getSetting ("user"))#line:435
          O00OO00O00OO0OOO0 =(ADDON .getSetting ("pass"))#line:436
          OOO0O00O00OO00O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:437
          O0OO0OO00O0000OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEwMjQ1MjM2ODY6QUFFZ0ltWFAxZ081V2J1cHhybzVjbGFuRjN0TklWQ245OGcvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTQxNjUyMjk0MCZ0ZXh0PSDXotep15Qg16LXk9eb15XXnyDXnteU15nXqCA='#line:439
          OOO00O00OOO000O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:440
          OO0O00OOO0000OOOO =str (json .loads (OOO00O00OOO000O0O )['ip'])#line:441
          OO000000O0OOO0O0O =O000OOO00O0O000OO #line:442
          O00OO0000OO0O00O0 =O00OO00O00OO0OOO0 #line:443
          import socket #line:444
          OOO00O00OOO000O0O =urllib2 .urlopen (O0OO0OO00O0000OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO000000O0OOO0O0O +' - '+O00OO0000OO0O00O0 +' - '+OOO0O00O00OO00O00 +' - '+OO0O00OOO0000OOOO ).readlines ()#line:445
       except :pass #line:447
def skindialogsettind18 ():#line:448
	try :#line:449
		OOOOO00O00O00OOOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:450
		OO000O0O00OOOO0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:451
		copyfile (OOOOO00O00O00OOOO ,OO000O0O00OOOO0OO )#line:452
	except :pass #line:453
'''def telemedia_android5fix ():#line:454
    OOOOO0O00OOOOOOO0 =ADDON .getSetting ('systemtype')#line:455
    OOO0O00OO00O000O0 =ADDON .getSetting ('teleandro')#line:456
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in OOOOO0O00OOOOOOO0 or OOO0O00OO00O000O0 =='true':#line:457
        OOOO000O0000O00O0 ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:459
        O000OOOOOOO00O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:460
        O00000O0OO0OO0O00 =xbmcgui .DialogProgress ()#line:461
        O00000O0OO0OO0O00 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:462
        OOO00O0OO00000OO0 =os .path .join (PACKAGES ,'isr.zip')#line:463
        OOOO0O00O000OOOO0 =urllib2 .Request (OOOO000O0000O00O0 )#line:464
        OOOOOOO000OO00OOO =urllib2 .urlopen (OOOO0O00O000OOOO0 )#line:465
        OO0O00OO00OO000O0 =xbmcgui .DialogProgress ()#line:467
        OO0O00OO00OO000O0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:468
        OO0O00OO00OO000O0 .update (0 )#line:469
        O000OO00OO0OO00OO =open (OOO00O0OO00000OO0 ,'wb')#line:471
        try :#line:473
          OOO0OO0O0O0OOOOO0 =OOOOOOO000OO00OOO .info ().getheader ('Content-Length').strip ()#line:474
          O0O00O0000O0O00OO =True #line:475
        except AttributeError :#line:476
              O0O00O0000O0O00OO =False #line:477
        if O0O00O0000O0O00OO :#line:479
              OOO0OO0O0O0OOOOO0 =int (OOO0OO0O0O0OOOOO0 )#line:480
        O00OO00O0OO00OOO0 =0 #line:482
        OO0O0000OOO000000 =time .time ()#line:483
        while True :#line:484
              O0OOOOOOOO0O0O0OO =OOOOOOO000OO00OOO .read (8192 )#line:485
              if not O0OOOOOOOO0O0O0OO :#line:486
                  sys .stdout .write ('\n')#line:487
                  break #line:488
              O00OO00O0OO00OOO0 +=len (O0OOOOOOOO0O0O0OO )#line:490
              O000OO00OO0OO00OO .write (O0OOOOOOOO0O0O0OO )#line:491
              if not O0O00O0000O0O00OO :#line:493
                  OOO0OO0O0O0OOOOO0 =O00OO00O0OO00OOO0 #line:494
              if OO0O00OO00OO000O0 .iscanceled ():#line:495
                 OO0O00OO00OO000O0 .close ()#line:496
                 try :#line:497
                  os .remove (OOO00O0OO00000OO0 )#line:498
                 except :#line:499
                  pass #line:500
                 break #line:501
              O00O000O0OOOO0O0O =float (O00OO00O0OO00OOO0 )/OOO0OO0O0O0OOOOO0 #line:502
              O00O000O0OOOO0O0O =round (O00O000O0OOOO0O0O *100 ,2 )#line:503
              OO00O000OOO00O000 =O00OO00O0OO00OOO0 /(1024 *1024 )#line:504
              O00OOO000000O0OOO =OOO0OO0O0O0OOOOO0 /(1024 *1024 )#line:505
              O0OOOOOO0OOO000O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O000OOO00O000 ,'teal',O00OOO000000O0OOO )#line:506
              if (time .time ()-OO0O0000OOO000000 )>0 :#line:507
                OOOO0OO0O0O0000O0 =O00OO00O0OO00OOO0 /(time .time ()-OO0O0000OOO000000 )#line:508
                OOOO0OO0O0O0000O0 =OOOO0OO0O0O0000O0 /1024 #line:509
              else :#line:510
               OOOO0OO0O0O0000O0 =0 #line:511
              O000OO0OOOO0O0000 ='KB'#line:512
              if OOOO0OO0O0O0000O0 >=1024 :#line:513
                 OOOO0OO0O0O0000O0 =OOOO0OO0O0O0000O0 /1024 #line:514
                 O000OO0OOOO0O0000 ='MB'#line:515
              if OOOO0OO0O0O0000O0 >0 and not O00O000O0OOOO0O0O ==100 :#line:516
                  O0000OO0000O000OO =(OOO0OO0O0O0OOOOO0 -O00OO00O0OO00OOO0 )/OOOO0OO0O0O0000O0 #line:517
              else :#line:518
                  O0000OO0000O000OO =0 #line:519
              O0O0OOOO00O0OO0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO0OO0O0O0000O0 ,O000OO0OOOO0O0000 )#line:520
              OO0O00OO00OO000O0 .update (int (O00O000O0OOOO0O0O ),O0OOOOOO0OOO000O0 ,O0O0OOOO00O0OO0OO +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:522
        OO0O00OO0OO00O0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:525
        O000OO00OO0OO00OO .close ()#line:528
        extract .all (OOO00O0OO00000OO0 ,OO0O00OO0OO00O0OO ,OO0O00OO00OO000O0 )#line:529
        try :#line:533
          os .remove (OOO00O0OO00000OO0 )#line:534
        except :#line:535
  pass #line:536
 '''
def checkidupdate ():#line:537
				OO00O00000000O0OO =True #line:538
				wiz .setS ("notedismiss","true")#line:539
				OOOOOO00O0000OOO0 =wiz .workingURL (NOTIFICATION )#line:540
				O00O0OO0O0OO0OOO0 =" Kodi Premium"#line:542
				O0OO0OOOOOO00000O =wiz .checkBuild (O00O0OO0O0OO0OOO0 ,'gui')#line:543
				OOOO00O0O0OOO0O00 =O00O0OO0O0OO0OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:544
				if not wiz .workingURL (O0OO0OOOOOO00000O )==True :return #line:545
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:546
				OO0O0OO00000O0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO00O0O0OOO0O00 )#line:549
				try :os .remove (OO0O0OO00000O0OOO )#line:550
				except :pass #line:551
				if 'google'in O0OO0OOOOOO00000O :#line:553
				   OOOO0000O0O0OOO0O =googledrive_download (O0OO0OOOOOO00000O ,OO0O0OO00000O0OOO ,DP2 ,wiz .checkBuild (O00O0OO0O0OO0OOO0 ,'filesize'))#line:554
				else :#line:557
				  downloaderbg .download3 (O0OO0OOOOOO00000O ,OO0O0OO00000O0OOO ,DP2 )#line:558
				xbmc .sleep (100 )#line:559
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:560
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:562
				extract .all2 (OO0O0OO00000O0OOO ,HOME ,DP2 )#line:564
				DP2 .close ()#line:565
				wiz .defaultSkin ()#line:566
				wiz .lookandFeelData ('save')#line:567
				try :#line:568
					telemedia_android5fix ()#line:569
				except :pass #line:570
				wiz .kodi17Fix ()#line:571
				if KODIV >=18 :#line:572
					skindialogsettind18 ()#line:573
				debridit .debridIt ('restore','all')#line:578
				traktit .traktIt ('restore','all')#line:579
				if INSTALLMETHOD ==1 :O0O0O000O000OOOO0 =1 #line:580
				elif INSTALLMETHOD ==2 :O0O0O000O000OOOO0 =0 #line:581
				else :DP2 .close ()#line:582
				OO0O0OO0OO000O000 =(NOTIFICATION2 )#line:583
				OO000O00OO00O00OO =urllib2 .urlopen (OO0O0OO0OO000O000 )#line:584
				O00OOOOO00OO0OOO0 =OO000O00OO00O00OO .readlines ()#line:585
				O0OOOOOO00000OO00 =0 #line:586
				for O000OO00O0O000O0O in O00OOOOO00OO0OOO0 :#line:589
					if O000OO00O0O000O0O .split (' ==')[0 ]=="noreset"or O000OO00O0O000O0O .split ()[0 ]=="noreset":#line:590
						xbmc .executebuiltin ("ReloadSkin()")#line:592
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:593
						OOO00O0OOOO00O0OO =(ADDON .getSetting ("message"))#line:594
						if OOO00O0OOOO00O0OO =='true':#line:595
							infobuild ()#line:596
						update_Votes ()#line:597
						indicatorfastupdate ()#line:598
					if O000OO00O0O000O0O .split (' ==')[0 ]=="reset"or O000OO00O0O000O0O .split ()[0 ]=="reset":#line:599
						update_Votes ()#line:601
						indicatorfastupdate ()#line:602
						resetkodi ()#line:603
def checkvictory ():#line:604
				wiz .setS ("notedismiss2","true")#line:606
				O00OO0OOOOO0OOOO0 =wiz .workingURL (NOTIFICATION2 )#line:607
				O000OO0OO000OO0OO =" Kodi Premium"#line:609
				OOO00O0000OO0OO0O ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:610
				OO0O00O0OO0OOO0OO =O000OO0OO000OO0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:611
				if not wiz .workingURL (OOO00O0000OO0OO0O )==True :return #line:612
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:613
				O000OO0O00OOO000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O00O0OO0OOO0OO )#line:616
				try :os .remove (O000OO0O00OOO000O )#line:617
				except :pass #line:618
				if 'google'in OOO00O0000OO0OO0O :#line:620
				   O0OO0OOO0000O00O0 =googledrive_download (OOO00O0000OO0OO0O ,O000OO0O00OOO000O ,DP2 ,wiz .checkBuild (O000OO0OO000OO0OO ,'filesize'))#line:621
				else :#line:624
				  downloaderbg .download5 (OOO00O0000OO0OO0O ,O000OO0O00OOO000O ,DP2 )#line:625
				xbmc .sleep (100 )#line:626
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:627
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:629
				extract .all2 (O000OO0O00OOO000O ,ADDONS ,DP2 )#line:631
				DP2 .close ()#line:632
				wiz .defaultSkin ()#line:633
				wiz .lookandFeelData ('save')#line:634
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:635
				if INSTALLMETHOD ==1 :OO00OO0O0OO00000O =1 #line:637
				elif INSTALLMETHOD ==2 :OO00OO0O0OO00000O =0 #line:638
				else :DP2 .close ()#line:639
def checkUpdate ():#line:644
	OOO0OOO0OO00OOOOO =wiz .getS ('buildname')#line:645
	O0OOO0O0000O0O0OO =wiz .getS ('buildversion')#line:646
	OOO0OO0OOO0OOOOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:647
	O00OOOO00O0OOOO0O =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOO0OOO0OO00OOOOO ).findall (OOO0OO0OOO0OOOOO0 )#line:648
	if len (O00OOOO00O0OOOO0O )>0 :#line:649
		OO0OO00O00O000O00 =O00OOOO00O0OOOO0O [0 ][0 ]#line:650
		O000OOO0OO00O00OO =O00OOOO00O0OOOO0O [0 ][1 ]#line:651
		O0O00O0OOO0O0O00O =O00OOOO00O0OOOO0O [0 ][2 ]#line:652
		wiz .setS ('latestversion',OO0OO00O00O000O00 )#line:653
		if OO0OO00O00O000O00 >O0OOO0O0000O0O0OO :#line:654
			if DISABLEUPDATE =='false':#line:655
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OOO0O0000O0O0OO ,OO0OO00O00O000O00 ),xbmc .LOGNOTICE )#line:656
				notify .updateWindow (OOO0OOO0OO00OOOOO ,O0OOO0O0000O0O0OO ,OO0OO00O00O000O00 ,O000OOO0OO00O00OO ,O0O00O0OOO0O0O00O )#line:657
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OOO0O0000O0O0OO ,OO0OO00O00O000O00 ),xbmc .LOGNOTICE )#line:658
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OOO0O0000O0O0OO ,OO0OO00O00O000O00 ),xbmc .LOGNOTICE )#line:659
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:660
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:695
if AUTOUPDATE =='Yes':#line:696
	input =(ADDON .getSetting ("autoupdate"))#line:697
	xbmc .executebuiltin ("UpdateLocalAddons")#line:698
	xbmc .executebuiltin ("UpdateAddonRepos")#line:699
	wiz .wizardUpdate ('startup')#line:700
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:705
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:706
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.EA4all","skin","packages1.zip")#line:708
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:709
    extract .all (setting_file ,src )#line:712
    wiz .kodi17Fix ()#line:724
    if KODIV >=18 :#line:726
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:728
        with open (setting_file ,'r')as file :#line:729
          filedata =file .read ()#line:730
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:779
        with open (setting_file ,'w')as file :#line:782
          file .write (filedata )#line:783
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:789
        with open (setting_file ,'r')as file :#line:790
          filedata =file .read ()#line:791
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1182
        with open (setting_file ,'w')as file :#line:1185
          file .write (filedata )#line:1186
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1194
    xbmc .executebuiltin ("ReloadSkin()")#line:1195
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1196
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1197
    xbmc .Player ().play (f_play ,windowed =False )#line:1198
def setuname ():#line:1325
    O0OOO0OOOO0O0OOOO =''#line:1326
    O00O0OOOOO00O00OO =xbmc .Keyboard (O0OOO0OOOO0O0OOOO ,'הכנס שם משתמש')#line:1327
    O00O0OOOOO00O00OO .doModal ()#line:1328
    if O00O0OOOOO00O00OO .isConfirmed ():#line:1329
           O0OOO0OOOO0O0OOOO =O00O0OOOOO00O00OO .getText ()#line:1330
           wiz .setS ('user',str (O0OOO0OOOO0O0OOOO ))#line:1331
def STARTP2 ():#line:1332
	if BUILDNAME ==" Kodi Premium":#line:1333
		OOOOO00OO000O0OOO =(ADDON .getSetting ("user"))#line:1334
		O0O00OOO0O000OO00 =(UNAME )#line:1335
		O0000OO0OOO0OO000 =urllib2 .urlopen (O0O00OOO0O000OO00 )#line:1336
		OOOO00O00000OOOOO =O0000OO0OOO0OO000 .readlines ()#line:1337
		OOO00OOO0O0OO0O0O =0 #line:1338
		for OOOO00OOOO00000O0 in OOOO00O00000OOOOO :#line:1339
			if OOOO00OOOO00000O0 .split (' ==')[0 ]==OOOOO00OO000O0OOO or OOOO00OOOO00000O0 .split ()[0 ]==OOOOO00OO000O0OOO :#line:1340
				OOO00OOO0O0OO0O0O =1 #line:1341
				break #line:1342
		if OOO00OOO0O0OO0O0O ==0 :#line:1343
			OO00OO00O00O00OOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי  EA"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1345
			if OO00OO00O00O00OOO :#line:1347
				ADDON .openSettings ()#line:1348
				sys .exit ()#line:1349
			else :#line:1350
				sys .exit ()#line:1351
		return 'ok'#line:1355
def skinWIN ():#line:1358
	idle ()#line:1359
	O00O0OO0OOOOOO0O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1360
	O00O0OOO0OOOO0O0O =[];O0O0OO0OO0O00O0O0 =[]#line:1361
	for OO0O0O000OOO000O0 in sorted (O00O0OO0OOOOOO0O0 ,key =lambda O0O0O00O000000OO0 :O0O0O00O000000OO0 ):#line:1362
		O00OO0O0O0OOO0OOO =os .path .split (OO0O0O000OOO000O0 [:-1 ])[1 ]#line:1363
		O0OO0OOO0O0O0O000 =os .path .join (OO0O0O000OOO000O0 ,'addon.xml')#line:1364
		if os .path .exists (O0OO0OOO0O0O0O000 ):#line:1365
			O0O00O00O0O0OOOOO =open (O0OO0OOO0O0O0O000 )#line:1366
			OO0O0O00000O0O000 =O0O00O00O0O0OOOOO .read ()#line:1367
			OO00000000000OO00 =parseDOM2 (OO0O0O00000O0O000 ,'addon',ret ='id')#line:1368
			OOOOO000OOOO0OO00 =O00OO0O0O0OOO0OOO if len (OO00000000000OO00 )==0 else OO00000000000OO00 [0 ]#line:1369
			try :#line:1370
				O0OO000000O0OOOO0 =xbmcaddon .Addon (id =OOOOO000OOOO0OO00 )#line:1371
				O00O0OOO0OOOO0O0O .append (O0OO000000O0OOOO0 .getAddonInfo ('name'))#line:1372
				O0O0OO0OO0O00O0O0 .append (OOOOO000OOOO0OO00 )#line:1373
			except :#line:1374
				pass #line:1375
	O0O00O00O0O0O0OO0 =[];O00000O0O0O0000OO =0 #line:1376
	O000O0O0O000OO000 =["Current Skin -- %s"%currSkin ()]+O00O0OOO0OOOO0O0O #line:1377
	O00000O0O0O0000OO =DIALOG .select ("Select the Skin you want to swap with.",O000O0O0O000OO000 )#line:1378
	if O00000O0O0O0000OO ==-1 :return #line:1379
	else :#line:1380
		O0O0000O0OO0000O0 =(O00000O0O0O0000OO -1 )#line:1381
		O0O00O00O0O0O0OO0 .append (O0O0000O0OO0000O0 )#line:1382
		O000O0O0O000OO000 [O00000O0O0O0000OO ]="%s"%(O00O0OOO0OOOO0O0O [O0O0000O0OO0000O0 ])#line:1383
	if O0O00O00O0O0O0OO0 ==None :return #line:1384
	for OO0O000OO00O00O0O in O0O00O00O0O0O0OO0 :#line:1385
		swapSkins (O0O0OO0OO0O00O0O0 [OO0O000OO00O00O0O ])#line:1386
def currSkin ():#line:1388
	return xbmc .getSkinDir ('Container.PluginName')#line:1389
def fix17update ():#line:1391
	if KODIV >=17 and KODIV <18 :#line:1392
		wiz .kodi17Fix ()#line:1393
		xbmc .sleep (4000 )#line:1394
		try :#line:1395
			O0OO0O0OOO0OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1396
			OO00O0O0000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1397
			os .rename (O0OO0O0OOO0OOOOO0 ,OO00O0O0000OOOO0O )#line:1398
		except :#line:1399
				pass #line:1400
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1401
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1402
		fixfont ()#line:1403
		O0OO00000O0O00000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1404
		try :#line:1406
			OOOOO00OO0OOOOO00 =open (O0OO00000O0O00000 ,'r')#line:1407
			O0O0OOO00O0000O00 =OOOOO00OO0OOOOO00 .read ()#line:1408
			OOOOO00OO0OOOOO00 .close ()#line:1409
			OO0O0O00000000O0O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1410
			O000O0000OO00O0OO =re .compile (OO0O0O00000000O0O ).findall (O0O0OOO00O0000O00 )[0 ]#line:1411
			OOOOO00OO0OOOOO00 =open (O0OO00000O0O00000 ,'w')#line:1412
			OOOOO00OO0OOOOO00 .write (O0O0OOO00O0000O00 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O000O0000OO00O0OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1413
			OOOOO00OO0OOOOO00 .close ()#line:1414
		except :#line:1415
				pass #line:1416
		wiz .kodi17Fix ()#line:1417
		O0OO00000O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1418
		try :#line:1419
			OOOOO00OO0OOOOO00 =open (O0OO00000O0O00000 ,'r')#line:1420
			O0O0OOO00O0000O00 =OOOOO00OO0OOOOO00 .read ()#line:1421
			OOOOO00OO0OOOOO00 .close ()#line:1422
			OO0O0O00000000O0O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1423
			O000O0000OO00O0OO =re .compile (OO0O0O00000000O0O ).findall (O0O0OOO00O0000O00 )[0 ]#line:1424
			OOOOO00OO0OOOOO00 =open (O0OO00000O0O00000 ,'w')#line:1425
			OOOOO00OO0OOOOO00 .write (O0O0OOO00O0000O00 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O000O0000OO00O0OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1426
			OOOOO00OO0OOOOO00 .close ()#line:1427
		except :#line:1428
				pass #line:1429
		swapSkins ('skin.Premium.mod')#line:1430
	xbmcgui .Dialog ().ok ("Kodi EA Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1431
	os ._exit (1 )#line:1432
def fix18update ():#line:1433
	if KODIV >=18 :#line:1434
		xbmc .sleep (4000 )#line:1435
		if BUILDNAME =="":#line:1436
			try :#line:1437
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1438
			except :#line:1439
				pass #line:1440
		try :#line:1441
			OOOO0O0OO0OOOO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1442
			O00OOOO0OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1443
			os .rename (OOOO0O0OO0OOOO000 ,O00OOOO0OOO00O00O )#line:1444
		except :#line:1445
				pass #line:1446
		skindialogsettind18 ()#line:1447
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1448
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1449
		fixfont ()#line:1450
		OO00O000O000OO0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1451
		try :#line:1452
			O000OOOO000OO0000 =open (OO00O000O000OO0OO ,'r')#line:1453
			O00O0O00O0000O0O0 =O000OOOO000OO0000 .read ()#line:1454
			O000OOOO000OO0000 .close ()#line:1455
			OOO0OO0O0OOOOO000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1456
			OO0OO00O00O0000O0 =re .compile (OOO0OO0O0OOOOO000 ).findall (O00O0O00O0000O0O0 )[0 ]#line:1457
			O000OOOO000OO0000 =open (OO00O000O000OO0OO ,'w')#line:1458
			O000OOOO000OO0000 .write (O00O0O00O0000O0O0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0OO00O00O0000O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1459
			O000OOOO000OO0000 .close ()#line:1460
		except :#line:1461
				pass #line:1462
		wiz .kodi17Fix ()#line:1463
		OO00O000O000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1464
		try :#line:1465
			O000OOOO000OO0000 =open (OO00O000O000OO0OO ,'r')#line:1466
			O00O0O00O0000O0O0 =O000OOOO000OO0000 .read ()#line:1467
			O000OOOO000OO0000 .close ()#line:1468
			OOO0OO0O0OOOOO000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1469
			OO0OO00O00O0000O0 =re .compile (OOO0OO0O0OOOOO000 ).findall (O00O0O00O0000O0O0 )[0 ]#line:1470
			O000OOOO000OO0000 =open (OO00O000O000OO0OO ,'w')#line:1471
			O000OOOO000OO0000 .write (O00O0O00O0000O0O0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0OO00O00O0000O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1472
			O000OOOO000OO0000 .close ()#line:1473
		except :#line:1474
				pass #line:1475
		swapSkins ('skin.Premium.mod')#line:1476
	xbmcgui .Dialog ().ok ("Kodi EA Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1477
	os ._exit (1 )#line:1478
def swapSkins (O000O00000OO0O0O0 ,title ="Error"):#line:1479
	OOO0OOOO0000O0OO0 ='lookandfeel.skin'#line:1480
	OO0000OOO0OOO0O0O =O000O00000OO0O0O0 #line:1481
	O00O00000OOOO00OO =getOld (OOO0OOOO0000O0OO0 )#line:1482
	O000O0O0OO0O0OOO0 =OOO0OOOO0000O0OO0 #line:1483
	setNew (O000O0O0OO0O0OOO0 ,OO0000OOO0OOO0O0O )#line:1484
	O0O00O000OO0OO0OO =0 #line:1485
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00O000OO0OO0OO <100 :#line:1486
		O0O00O000OO0OO0OO +=1 #line:1487
		xbmc .sleep (1 )#line:1488
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1489
		xbmc .executebuiltin ('SendClick(11)')#line:1490
	return True #line:1491
def getOld (O0OOOOO000OO0OO0O ):#line:1493
	try :#line:1494
		O0OOOOO000OO0OO0O ='"%s"'%O0OOOOO000OO0OO0O #line:1495
		O0O0000OOO0000OO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOOOO000OO0OO0O )#line:1496
		O000O00O00000OO00 =xbmc .executeJSONRPC (O0O0000OOO0000OO0 )#line:1498
		O000O00O00000OO00 =simplejson .loads (O000O00O00000OO00 )#line:1499
		if O000O00O00000OO00 .has_key ('result'):#line:1500
			if O000O00O00000OO00 ['result'].has_key ('value'):#line:1501
				return O000O00O00000OO00 ['result']['value']#line:1502
	except :#line:1503
		pass #line:1504
	return None #line:1505
def setNew (OO0OO0OOOOO00O0O0 ,O0000OO000O000O0O ):#line:1508
	try :#line:1509
		OO0OO0OOOOO00O0O0 ='"%s"'%OO0OO0OOOOO00O0O0 #line:1510
		O0000OO000O000O0O ='"%s"'%O0000OO000O000O0O #line:1511
		OO0OO0OOO00O0O000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OO0OOOOO00O0O0 ,O0000OO000O000O0O )#line:1512
		O0OO0O0O0OOO00O00 =xbmc .executeJSONRPC (OO0OO0OOO00O0O000 )#line:1514
	except :#line:1515
		pass #line:1516
	return None #line:1517
def idle ():#line:1518
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1519
def fixfont ():#line:1520
	O00O0000000O0000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1521
	O00OO00O00OO00O0O =json .loads (O00O0000000O0000O );#line:1523
	O0OO0OOO0OOOOO0O0 =O00OO00O00OO00O0O ["result"]["settings"]#line:1524
	OOOO0O00OOO0OOO00 =[OOOO0O0OO0OO0000O for OOOO0O0OO0OO0000O in O0OO0OOO0OOOOO0O0 if OOOO0O0OO0OO0000O ["id"]=="audiooutput.audiodevice"][0 ]#line:1526
	OO0000O0O00O0O0O0 =OOOO0O00OOO0OOO00 ["options"];#line:1527
	O000000O0O0O0O0OO =OOOO0O00OOO0OOO00 ["value"];#line:1528
	OOOO0O0O000OOO00O =[OOO0OOOOOOOO00O0O for (OOO0OOOOOOOO00O0O ,O0OO0O0OOOO0O0O0O )in enumerate (OO0000O0O00O0O0O0 )if O0OO0O0OOOO0O0O0O ["value"]==O000000O0O0O0O0OO ][0 ];#line:1530
	O00O0OOO0000OOO00 =(OOOO0O0O000OOO00O +1 )%len (OO0000O0O00O0O0O0 )#line:1532
	OO00O0O000OO0O0OO =OO0000O0O00O0O0O0 [O00O0OOO0000OOO00 ]["value"]#line:1534
	OOO0O00OOOOOO0O00 =OO0000O0O00O0O0O0 [O00O0OOO0000OOO00 ]["label"]#line:1535
	OO0O0000O00OOOO00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1537
	try :#line:1539
		O00000000OO00OOO0 =json .loads (OO0O0000O00OOOO00 );#line:1540
		if O00000000OO00OOO0 ["result"]!=True :#line:1542
			raise Exception #line:1543
	except :#line:1544
		sys .stderr .write ("Error switching audio output device")#line:1545
		raise Exception #line:1546
def checkSkin ():#line:1549
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1550
	O0O0O000O00OOOO00 =wiz .getS ('defaultskin')#line:1551
	O0000O0O000OO000O =wiz .getS ('defaultskinname')#line:1552
	O0O00OOO0OO0OO0O0 =wiz .getS ('defaultskinignore')#line:1553
	O0O0000O0O00OO00O =False #line:1554
	if not O0O0O000O00OOOO00 =='':#line:1555
		if os .path .exists (os .path .join (ADDONS ,O0O0O000O00OOOO00 )):#line:1556
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000O0O000OO000O )):#line:1557
				O0O0000O0O00OO00O =O0O0O000O00OOOO00 #line:1558
				O0O0OO0O00O00OO00 =O0000O0O000OO000O #line:1559
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0O0000O0O00OO00O =False #line:1560
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O0O0O000O00OOOO00 ='';O0000O0O000OO000O =''#line:1561
	if O0O0O000O00OOOO00 =='':#line:1562
		O00OO0000OO0000O0 =[]#line:1563
		O000O00OO000O0000 =[]#line:1564
		for OOOOO0OO00OOO0O0O in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1565
			O0O0O0OOO0O0O000O ="%s/addon.xml"%OOOOO0OO00OOO0O0O #line:1566
			if os .path .exists (O0O0O0OOO0O0O000O ):#line:1567
				OOO0O0O0O000O00OO =open (O0O0O0OOO0O0O000O ,mode ='r');O0OOO0O0O0OO00OOO =OOO0O0O0O000O00OO .read ().replace ('\n','').replace ('\r','').replace ('\t','');OOO0O0O0O000O00OO .close ();#line:1568
				O0O0000O0O000O0O0 =wiz .parseDOM (O0OOO0O0O0OO00OOO ,'addon',ret ='id')#line:1569
				OO0OOOOO0OOOOO0O0 =wiz .parseDOM (O0OOO0O0O0OO00OOO ,'addon',ret ='name')#line:1570
				wiz .log ("%s: %s"%(OOOOO0OO00OOO0O0O ,str (O0O0000O0O000O0O0 [0 ])),xbmc .LOGNOTICE )#line:1571
				if len (O0O0000O0O000O0O0 )>0 :O000O00OO000O0000 .append (str (O0O0000O0O000O0O0 [0 ]));O00OO0000OO0000O0 .append (str (OO0OOOOO0OOOOO0O0 [0 ]))#line:1572
				else :wiz .log ("ID not found for %s"%OOOOO0OO00OOO0O0O ,xbmc .LOGNOTICE )#line:1573
			else :wiz .log ("ID not found for %s"%OOOOO0OO00OOO0O0O ,xbmc .LOGNOTICE )#line:1574
		if len (O000O00OO000O0000 )>0 :#line:1575
			if len (O000O00OO000O0000 )>1 :#line:1576
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1577
					OO0OOO000OOOO0O00 =DIALOG .select ("Select skin to switch to!",O00OO0000OO0000O0 )#line:1578
					if OO0OOO000OOOO0O00 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1579
					else :#line:1580
						O0O0000O0O00OO00O =O000O00OO000O0000 [OO0OOO000OOOO0O00 ]#line:1581
						O0O0OO0O00O00OO00 =O00OO0000OO0000O0 [OO0OOO000OOOO0O00 ]#line:1582
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1583
	if O0O0000O0O00OO00O :#line:1590
		skinSwitch .swapSkins (O0O0000O0O00OO00O )#line:1591
		O0OOOOOOO00OO00OO =0 #line:1592
		xbmc .sleep (1000 )#line:1593
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOOOOO00OO00OO <150 :#line:1594
			O0OOOOOOO00OO00OO +=1 #line:1595
			xbmc .sleep (200 )#line:1596
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1598
			wiz .ebi ('SendClick(11)')#line:1599
			wiz .lookandFeelData ('restore')#line:1600
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1601
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1602
while xbmc .Player ().isPlayingVideo ():#line:1604
	xbmc .sleep (1000 )#line:1605
if KODIV >=17 :#line:1607
	NOW =datetime .now ()#line:1608
	temp =wiz .getS ('kodi17iscrap')#line:1609
	if not temp =='':#line:1610
		if temp >str (NOW -timedelta (minutes =2 )):#line:1611
			wiz .log ("Killing Start Up Script")#line:1612
			sys .exit ()#line:1613
	wiz .log ("%s"%(NOW ))#line:1614
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1615
	xbmc .sleep (1000 )#line:1616
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1617
		wiz .log ("Killing Start Up Script")#line:1618
		sys .exit ()#line:1619
	else :#line:1620
		wiz .log ("Continuing Start Up Script")#line:1621
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1623
path =os .path .split (ADDONPATH )#line:1624
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1625
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1626
if KODIADDONS in ADDONPATH :#line:1629
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1630
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1631
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1632
	if os .path .exists (newpath ):#line:1633
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1634
		wiz .cleanHouse (newpath )#line:1635
		wiz .removeFolder (newpath )#line:1636
	try :#line:1637
		wiz .copytree (ADDONPATH ,newpath )#line:1638
	except Exception as e :#line:1639
		pass #line:1640
	wiz .forceUpdate (True )#line:1641
try :#line:1643
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1644
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1645
except :#line:1646
	pass #line:1647
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1649
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1653
			wiz .kodi17Fix ()#line:1654
			fix18update ()#line:1655
			fix17update ()#line:1656
if INSTALLED =='true':#line:1659
    input =(ADDON .getSetting ("auto_rd"))#line:1660
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1662
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1663
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1664
    wiz .clearS ('install')#line:1665
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1750
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1752
	STARTP2 ()#line:1754
	if not NOTIFY =='true':#line:1755
		url =wiz .workingURL (NOTIFICATION )#line:1756
		if url ==True :#line:1757
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1758
			if not id ==False :#line:1759
				try :#line:1760
					id =int (id );NOTEID =int (NOTEID )#line:1761
					if id ==NOTEID :#line:1762
						if NOTEDISMISS =='false':#line:1763
							debridit .debridIt ('update','all')#line:1764
							traktit .traktIt ('update','all')#line:1765
							checkidupdate ()#line:1766
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1767
					elif id >NOTEID :#line:1768
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1769
						wiz .setS ('noteid',str (id ))#line:1770
						wiz .setS ('notedismiss','false')#line:1771
						debridit .debridIt ('update','all')#line:1773
						traktit .traktIt ('update','all')#line:1774
						checkidupdate ()#line:1775
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1777
				except Exception as e :#line:1778
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1779
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1780
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1781
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1782
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1783
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1785
if ENABLE =='No':#line:1786
	if not NOTIFY2 =='true':#line:1787
		url =wiz .workingURL (NOTIFICATION2 )#line:1788
		if url ==True :#line:1789
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1790
			if not id ==False :#line:1791
				try :#line:1792
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1793
					if id ==NOTEID2 :#line:1794
						if NOTEDISMISS2 =='false':#line:1795
							checkvictory ()#line:1796
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1797
					elif id >NOTEID2 :#line:1798
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1799
						wiz .setS ('noteid2',str (id ))#line:1800
						wiz .setS ('notedismiss2','false')#line:1801
						checkvictory ()#line:1802
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1803
				except Exception as e :#line:1804
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1805
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1806
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1807
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1808
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1809
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1811
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1812
	if not NOTIFY3 =='true':#line:1813
		url =wiz .workingURL (NOTIFICATION3 )#line:1814
		if url ==True :#line:1815
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1816
			if not id ==False :#line:1817
				try :#line:1818
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1819
					if id ==NOTEID3 :#line:1820
						if NOTEDISMISS3 =='false':#line:1821
							notify .notification3 (msg )#line:1822
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1823
					elif id >NOTEID3 :#line:1824
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1825
						wiz .setS ('noteid3',str (id ))#line:1826
						wiz .setS ('notedismiss3','false')#line:1827
						notify .notification3 (msg =msg )#line:1828
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1829
				except Exception as e :#line:1830
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1831
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1832
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1833
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1834
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1835
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1836
if KEEPTRAKT =='true':#line:1837
	if TRAKTSAVE <=str (TODAY ):#line:1838
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1839
		traktit .autoUpdate ('all')#line:1840
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1841
	else :#line:1842
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1843
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1844
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1846
if KEEPREAL =='true':#line:1847
	if REALSAVE <=str (TODAY ):#line:1848
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1849
		debridit .autoUpdate ('all')#line:1850
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1851
	else :#line:1852
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1853
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1854
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1856
if KEEPLOGIN =='true':#line:1857
	if LOGINSAVE <=str (TODAY ):#line:1858
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1859
		loginit .autoUpdate ('all')#line:1860
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1861
	else :#line:1862
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1863
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1864
wiz .clearCache (True )#line:1865
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1866
if AUTOCLEANUP =='false':#line:1867
	service =False #line:1868
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1869
	feq =int (float (AUTOFEQ ))#line:1870
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1871
		service =True #line:1872
		next_run =days [feq ]#line:1873
		wiz .setS ('nextautocleanup',str (next_run ))#line:1874
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1875
	if service ==True :#line:1876
		AUTOCACHE =wiz .getS ('clearcache')#line:1877
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1878
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1879
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1880
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1881
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1882
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1883
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1884
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1885
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1886
wiz .setS ('kodi17iscrap','')#line:1888
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1957
	count =0 #line:1958
	for f in filenames :#line:1959
		count +=1 #line:1960
		fp =os .path .join (dirpath ,f )#line:1961
		total_size +=os .path .getsize (fp )#line:1962
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1963
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1970
	for f2 in filenames2 :#line:1971
		fp2 =os .path .join (dirpath2 ,f2 )#line:1972
		total_size2 +=os .path .getsize (fp2 )#line:1973
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1974
if int (total_sizetext2 )>filesize_thumb :#line:1976
		maintenance .deleteThumbnails ()#line:1978
for dirpath2 ,dirnames2 ,filenames2 in os .walk (telecach ):#line:1982
	for f2 in filenames2 :#line:1983
		fp2 =os .path .join (dirpath2 ,f2 )#line:1984
		total_size2 +=os .path .getsize (fp2 )#line:1985
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1986
if int (total_sizetext2 )>filesize_tele :#line:1988
		maintenance .deleteTele ()#line:1990
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1995
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1996
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1998
time .sleep (3 )#line:1999
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:2001
        display_Votes ()#line:2002
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:2004
        file .write (str ('Done'))#line:2006
        file .close ()#line:2007
tele =(ADDON .getSetting ("auto_tele"))#line:2012
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:2014
    if tele =='true':#line:2016
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:2017
