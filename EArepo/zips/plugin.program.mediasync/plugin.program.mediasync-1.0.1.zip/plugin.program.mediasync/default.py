# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,time,random
import shutil
import urllib2,urllib,xbmcvfs
import re
import requests,json
import logging
from resources.libs.zfile import Items







Addon = xbmcaddon.Addon()
addon_id = 'plugin.program.mediasync'
ADDON = xbmcaddon.Addon(id=addon_id)
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
VERSION = "3.0.0"
PATH = "forceclose"            
BASE = "fclose"
DIALOG         = xbmcgui.Dialog()
COLOR1         = 'yellow'
COLOR2         = 'white'
log            = xbmc.translatePath('special://logpath/')
LOGO=os.path.join(addonPath, 'resources', 'logos/')
ADDONTITLE='Media Sync'


def LogNotify(title, message, times=4000, icon=ICON,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def get_custom_params(item):
        param=[]
        item=item.split("?")
        if len(item)>=2:
          paramstring=item[1]
          
          if len(paramstring)>=2:
                params=item[1]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def get_params():
        param=[]

        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param  
def backup_vik():
    import datetime
    strptime = datetime.datetime.strptime
    logging.warning('backing up')
    threading.Thread(target=do_bakcup).start()
    return '1'


def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png",fanart="DefaultFolder.png",description=' '):
 

          
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name),'plot':description   })
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def main_menu():
      addNolink('סנכרון נתונים לערוץ','www',3,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('סנכרון נתונים למכשיר זה','www',4,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('בחר ערוץ לסנכרון נתונים','www',2,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('הגדרות','www',5,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')


def do_bakcup(silent='True'):
  global Pass
  if Addon.getSetting("bot_id")=='' or Addon.getSetting("user_name")=='':
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא הוגדר שם למכשיר או ערוץ לסנכרון[/COLOR]' % COLOR2)
    if Addon.getSetting("user_name")=='':
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס שם למכשיר')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               Addon.setSetting('user_name', str(search_entered))
    if Addon.getSetting("bot_id")=='':
     
      set_bot_id()
  else:
   
    logging.warning('silent')
    logging.warning(silent)
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מסנכרן[/COLOR]' % COLOR2)
    KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    if KODIV > 17:
        import zfile as zipfile #FTG mod for Kodi 18
    else:
        import zipfile
    import datetime,os
    from shutil import copyfile
    from os.path import basename
    if silent=='False':
        logging.warning('silent2')
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מתחבר לשרת', '','')
        dp.update(0, 'אנא המתן','מכווץ', '' )
    exclude_files = ['xmltv.xml.cache']
    tele=os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.telemedia'))
    databasetele=os.path.join(tele, 'database.db')
    databasetele2=os.path.join(tele, 'cache_play.db')
    
    
    
    torrent=os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.torrent'))

    
    
    mando=os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.mando'))
    databasemando=os.path.join(mando, 'database.db')
    databasemando2=os.path.join(mando, 'cache_play.db')
    databasemando3=os.path.join(mando, 'settings.xml')
    
    shadow=os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.shadow'))
    databaseshadow=os.path.join(shadow, 'database.db')
    databaseshadow2=os.path.join(shadow, 'cache_play.db')
    databaseshadow3=os.path.join(shadow, 'settings.xml')
    

    iptvsimple=os.path.join(xbmc.translatePath('special://profile/addon_data/pvr.iptvsimple'))

    
    resolveurl=os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.resolveurl'))
    resolveurlsettings=os.path.join(resolveurl, 'settings.xml')

    seren=os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.seren'))
    serensettings=os.path.join(seren, 'settings.xml')
    
    exodusredux=os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.exodusredux'))
    exodusreduxsettings=os.path.join(exodusredux, 'settings.xml')

    last_played=os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.last_played'))



    favourites=os.path.join(xbmc.translatePath('special://profile'))
    favouritesfile=os.path.join(favourites, 'favourites.xml')

    guisettings=os.path.join(xbmc.translatePath('special://profile'))
    guisettingsfile=os.path.join(guisettings, 'guisettings.xml')


    Database=os.path.join(xbmc.translatePath('special://profile/Database'))
    DatabaseView=os.path.join(Database, 'ViewModes6.db')
    DatabaseVideos=os.path.join(Database, 'MyVideos107.db')
    DatabaseVideos18=os.path.join(Database, 'MyVideos116.db')

    skinshortcuts=os.path.join(xbmc.translatePath('special://profile/addon_data/script.skinshortcuts'))

    username=Addon.getSetting("user_name")
    
#"%Y,%m,%d,%H,%M,%S"
    zp_file=os.path.join(user_dataDir,str(time.strftime("%d/%m/%Y").replace('/','.')+' שעה '+str(time.strftime("%H/%M").replace('/',':')+' '+username +'.zip')))
    if os.path.isfile(zp_file):
        os.remove(zp_file)
    zipf = zipfile.ZipFile(zp_file , mode='w')
    
    
    dirname=os.path.join(xbmc.translatePath('special://profile'))
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databasetele,databasetele[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasetele2,databasetele2[len(dirname):])
        except:pass
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databasemando,databasemando[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasemando2,databasemando2[len(dirname):])
        except:pass
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databasemando3,databasemando3[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databaseshadow,databaseshadow[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databaseshadow2,databaseshadow2[len(dirname):])
        except:pass
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databaseshadow3,databaseshadow3[len(dirname):])
        except:pass
        
        
      
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(resolveurlsettings,resolveurlsettings[len(dirname):])
        except:pass
        try:
         zipf.write(serensettings,serensettings[len(dirname):])
        except:pass
        try:
         zipf.write(exodusreduxsettings,exodusreduxsettings[len(dirname):])
        except:pass
    if Addon.getSetting("sync_favo")=='true':
        try:
         zipf.write(favouritesfile,favouritesfile[len(dirname):])
        except:pass
    if Addon.getSetting("sync_display")=='true':
        try:
         zipf.write(DatabaseView,DatabaseView[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(DatabaseVideos,DatabaseVideos[len(dirname):])
        except:pass
        try:
         zipf.write(DatabaseVideos18,DatabaseVideos18[len(dirname):])
        except:pass
        
    if Addon.getSetting("guisettings")=='true':
        try:
         zipf.write(guisettingsfile,guisettingsfile[len(dirname):])
        except:pass
        
        
    if Addon.getSetting("sync_skinshortcuts")=='true':
       for base, dirs, files in os.walk(skinshortcuts):
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    if Addon.getSetting("sync_lastview")=='true':
       for base, dirs, files in os.walk(last_played):
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    if Addon.getSetting("sync_iptv")=='true':
       for base, dirs, files in os.walk(iptvsimple):
        files[:] = [f for f in files if f not in exclude_files]
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    if Addon.getSetting("sync_lastview")=='true':
       for base, dirs, files in os.walk(torrent):
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    
    zipf.close()
    

    
    
    from os.path import basename
    if Addon.getSetting("remote_selection")=='0':
        onlyfiles=[]
        db_bk_folder=xbmc.translatePath(Addon.getSetting("remote_path"))
        dirList, onlyfiles =xbmcvfs.listdir(db_bk_folder)
      
        ct_min=0
        
            
        count=0
        for files in onlyfiles:
            f_patch_file=os.path.join(db_bk_folder,files)
            if Addon.getSetting("db_bk_name") in basename(files):
                count+=1
        
        if count>5:
            for files in onlyfiles:
                f_file=(os.path.join(db_bk_folder,files))
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                logging.warning(ct_date)
                #ct_date=time.ctime(os.path.getctime(f_file))
                if ct_min==0:
                    ct_min=ct_date
                elif ct_date<ct_min:
                    ct_min=ct_date
            
            for files in onlyfiles:
                f_file=os.path.join(db_bk_folder,files)
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                #ct_date=time.ctime(os.path.getctime(f_file))
               
                if ct_date==ct_min:
                   
                    xbmcvfs.delete(f_file)
                    break
        xbmcvfs.copy (zp_file,os.path.join(db_bk_folder,Addon.getSetting("db_bk_name")+'_'+str(time.strftime("%d/%m/%Y")).replace('/','_')))
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
    elif Addon.getSetting("remote_selection")=='1':
        if silent=='False':
            dp.update(20, 'אנא המתן','מתחבר לשרת', '' )
        import ftplib
        import os,urllib
        from datetime import datetime
        import _strptime
            
        server=Addon.getSetting("ftp_host")
        username=Addon.getSetting("ftp_user")
        password=Addon.getSetting("ftp_pass")
        try:
            myFTP = ftplib.FTP(server, username, password)
            if silent=='False':
                dp.update(40, 'אנא המתן','התחבר בהצלחה', '' )
            files = myFTP.nlst()
            found=0
            if silent=='False':
                dp.update(60, 'אנא המתן','אוסף קבצים', '' )
            for f in files:
                
               
                
                if 'kodi_backup' in f:
                    found=1
                    
            if found==0:
                myFTP.mkd('kodi_backup')
            myFTP.cwd('kodi_backup')
            files = myFTP.nlst()
           
            count=0
            ct_min=0
            for f in files:
                
                if Addon.getSetting("db_bk_name") in basename(f):
                    count+=1
            if count>5:
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
                    try:
                        modifiedTime = myFTP.sendcmd('MDTM ' + f)
                       
                        
                        #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        try:
                            ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        except TypeError:
                            ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                            ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                        
                        if ct_min==0:
                            ct_min=ct_date
                        elif ct_date<ct_min:
                            ct_min=ct_date
                    except Exception as e:
                        logging.warning(e)
                        pass
             
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
            
                    modifiedTime = myFTP.sendcmd('MDTM ' + f)
          
             
                    
                    #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    try:
                        ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    except TypeError:
                        ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                        ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                   
                    if ct_date==ct_min:
                    
                        
                        myFTP.delete(f)
                        break
            if silent=='False':
                dp.update(80, 'אנא המתן','מעלה לשרת', '' )
            uploadThis(zp_file,myFTP)
            
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
        except Exception as e:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'שגיאה בגיבוי לשרת בדוק הגדרות'.decode('utf8'))).encode('utf-8'))
    else:
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        selected_group_id=Addon.getSetting("bot_id")
        num2=random.randint(0,60000)
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num2})
                 }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        exit_now=0

        if 'status' in event:
            xbmcgui.Dialog().ok('Error occurred',event['status'])
            exit_now=1
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'sendMessage','chat_id': selected_group_id,'input_message_content': {'@type':'inputMessageDocument','document': {'@type':'inputFileLocal','path': zp_file}},'@extra': 1 })
                     }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        xbmc.sleep(10000)
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון בוצע![/COLOR]' % COLOR2)
    try:
        xbmc.sleep(1000)
        if os.path.isfile(zp_file):
            os.remove(zp_file)
    except:
        pass
    if silent=='False':
        dp.close()
    logging.warning('Done backing up')
def uploadThis(f,myFTP):
    from os.path import basename
    fh = open(f, 'rb')
    myFTP.storbinary('STOR %s' % Addon.getSetting("db_bk_name")+'1_'+str(time.strftime("%d/%m/%Y")).replace('/','_'), fh)
    fh.close()
def unzip(file,path):
       
        from resources.libs.zfile import ZipFile
        
        
        zip_file = file
        ptp = 'Masterpenpass'
        zf=ZipFile(zip_file)
        logging.warning('Extracting')
        listOfFileNames = zf.namelist()
        # Iterate over the file names
        for fileName in listOfFileNames:
            logging.warning(fileName)
        #zf.setpassword(bytes(ptp))
        #with ZipFile(zip_file) as zf:
        #zf.extractall(path)
        with ZipFile(zip_file, 'r') as zipObj:
           # Extract all the contents of zip file in current directory
           zipObj.extractall(path)
def restore_backup():
  if Addon.getSetting("bot_id")=='' or Addon.getSetting("user_name")=='':
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא הוגדר שם למכשיר או ערוץ לסנכרון[/COLOR]' % COLOR2)
    if Addon.getSetting("user_name")=='':
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס שם למכשיר')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               Addon.setSetting('user_name', str(search_entered))
    if Addon.getSetting("bot_id")=='':
   
      set_bot_id()
  else:
    import random
    from shutil import copyfile
    import os
    if 1:#try:
        cacheFile = os.path.join(user_dataDir, 'cache_play.db')
        zp_file= os.path.join(user_dataDir, 'data.zip')
        from os.path import basename
        if Addon.getSetting("remote_selection")=='0':
           
            onlyfiles=[]
            db_bk_folder=xbmc.translatePath(Addon.getSetting("remote_path"))
            dirList, onlyfiles =xbmcvfs.listdir(db_bk_folder)
            
    
            all_n=[]
            all_f=[]
            for f in onlyfiles:
                all_n.append(basename(f))
                all_f.append(os.path.join(db_bk_folder,f))
            ret = xbmcgui.Dialog().select("בחר קובץ גיבוי", all_n)
            if ret!=-1:
                ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                if ok:
                    db_name=Addon.getSetting('db_bk_name')
                    if '.db' not in all_n[ret]:
                        xbmcvfs.copy(all_f[ret],os.path.join(user_dataDir,'temp_zip'))
                        unzip(os.path.join(user_dataDir,'temp_zip'),user_dataDir)
                        xbmcvfs.delete(os.path.join(user_dataDir,'temp_zip'))
                    else:
                        xbmcvfs.copy(all_f[ret],cacheFile)
                    #xbmc.executebuiltin('Container.Update')
                    #Addon.setSetting('db_bk_name',db_name)
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון בוצע בהצלחה[/COLOR]' % COLOR2)
            else:
               sys.exit()
        elif Addon.getSetting("remote_selection")=='1':
            dp = xbmcgui . DialogProgress ( )
            dp.create('אנא המתן','מתחבר לשרת', '','')
            dp.update(0, 'אנא המתן','מתחבר לשרת', '' )
            import ftplib
            import os,urllib
            from datetime import datetime
            server=Addon.getSetting("ftp_host")
            username=Addon.getSetting("ftp_user")
            password=Addon.getSetting("ftp_pass")
            try:
            
              myFTP = ftplib.FTP(server, username, password)
            except Exception as e:
               xbmcgui.Dialog().ok('שגיאת התחברות',str(e))
               sys.exit()
            dp.update(0, 'אנא המתן','התחבר בהצלחה', '' )
            files = myFTP.nlst()
            found=0
            for f in files:
         
                if 'kodi_backup' in f:
                    found=1
            if found==0:
            
                xbmcgui.Dialog().ok("שחזור מגיבוי",'[COLOR red][I]לא קיימים גיבויים[/I][/COLOR]')
                sys.exit()
            myFTP.cwd('kodi_backup')
            files = myFTP.nlst()
           
            count=0
            ct_min=0
            all_n=[]
            all_f=[]
            dp.update(0, 'אנא המתן','אוסף קבצים', '' )
            for f in files:

                all_n.append(basename(f))
                all_f.append(f)
            ret = xbmcgui.Dialog().select("בחר קובץ גיבוי", all_n)
            if ret!=-1:
                ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                if ok:
                    
                    db_name=Addon.getSetting('db_bk_name')
                    i=cacheFile
                    dp.update(0, 'אנא המתן','מוריד קובץ', '' )
                    myFTP.retrbinary("RETR " + all_f[ret] ,open(i, 'wb').write)
                    dp.close()
                    if '.db' not in all_n[ret]:
                        myFTP.retrbinary("RETR " + all_f[ret] ,open(zp_file, 'wb').write)
                        unzip(zp_file,user_dataDir)
                    else:
                        myFTP.retrbinary("RETR " + all_f[ret] ,open(i, 'wb').write)
                    Addon.setSetting('db_bk_name',db_name)
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון בוצע בהצלחה[/COLOR]' % COLOR2)
            else:
               sys.exit()
        else:
            resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
            listen_port=resuaddon.getSetting('port')
            selected_group_id=Addon.getSetting("bot_id")
            num=random.randint(1,1001)
            
            

            num2=random.randint(0,60000)
            data={'type':'td_send',
                     'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num2})
                     }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            exit_now=0

            if 'status' in event:
                xbmcgui.Dialog().ok('Error occurred',event['status'])
                exit_now=1
            
            
            
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(selected_group_id), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }

           
         
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            all_n=[]
            all_ids=[]



            for items in event['messages']:
                file_name=items['content']['document']['file_name']
                all_n.append(file_name.replace('.zip',''))
                all_ids.append(str(items['content']['document']['document']['id']))
            ret = xbmcgui.Dialog().select("בחר תאריך סנכרון", all_n)
            if ret!=-1 and Items==True:
                # ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                # if ok:
                    data={'type':'download_photo',
                             'info':all_ids[ret]
                             }
                    logging.warning('Sending')
                    
                    file=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                    logging.warning('file:'+file)
                    xbmc.sleep(100)
                    dirname=os.path.join(xbmc.translatePath('special://profile'))
                    unzip(file,dirname)
                    # xbmcvfs.delete(file)
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון בוצע בהצלחה[/COLOR]' % COLOR2)
            else:
             xbmc.log( "Sync Is: %s." % ('המתן') , 5)

                        
        if os.path.isfile(zp_file):
            os.remove(zp_file)
        if Addon.getSetting("guisettings")=='true':
            Addon.setSetting('guisettings','false')
            DP = xbmcgui.DialogProgress()
            DP.create("להלשמת הפעולה הקודי יסגר ", "אנא המתן 5 שניות", '',
            
            "[COLOR orange][B]מסיים פעולות[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                DP.update(int((5 - s) / 5.0 * 100), "הקודי יסגר", 'בעוד {0} שניות'.format(s), '')
                if DP.iscanceled():
                    os._exit(1)
                    return None, None
            os._exit(1)
         # os._exit(1)
    #except Exception as e:
    #    xbmcgui.Dialog().ok('תקלה','[COLOR red] בדוק את הגדרות ההרחבה [/COLOR]'+str(e))
    
    try:
        dp.close()
    except:
        pass
def backup_vik():
    import datetime
    strptime = datetime.datetime.strptime
    logging.warning('backing up')
    threading.Thread(target=do_bakcup).start()
    return '1'
def set_bot_id():
   # try:
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    num=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
   
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    if exit_now==0:
       

        
        
        counter=0
        counter_ph=10000
    
        j_enent_o=(event)
        zzz=0
        items=''
        names=[]
        ids=[]
        for items in j_enent_o['chat_ids']:
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            order=event['positions'][0]['order']
            
           
                         
                          
            j_enent=(event)
            
            
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                
              
                names.append(j_enent['title'])
                ids.append(items)
    selected_group_id=-1
    if len(names)>0:
        ret = xbmcgui.Dialog().select("בחר ערוץ בו ישמר המידע", names)
        if ret==-1:
            sys.exit()
        else:
            selected_group_id=ids[ret]
        if selected_group_id!=-1:
            Addon.setSetting('bot_id',str(ids[ret]))
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הערוץ הוגדר בהצלחה[/COLOR]' % COLOR2)
    do_bakcup(silent='True')




# resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
# listen_port=resuaddon.getSetting('port')
# num=random.randint(0,60000)
# data={'type':'td_send',
         # 'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
         # }
# event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
# exit_now=0

# if 'status' in event:
    # xbmcgui.Dialog().ok('Error occurred',event['status'])
    # exit_now=1



params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

#######################################    ^
# Manual Mode Old Method (For Pussies)#    |
#######################################    |


##########################################
	
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        

if mode==None or url==None or len(url)<1 and len(sys.argv)>1:
        main_menu()
elif mode==2:
    
    try:
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source is True:


       set_bot_id()
    else: 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
     # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן שטלמדיה תתחבר[/COLOR]' % COLOR2)
elif mode==3:
    try:  
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source is True:
      do_bakcup(silent=url)
    else: 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
     # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן שטלמדיה תתחבר[/COLOR]' % COLOR2)
elif mode==4:
    try:
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source is True:
      restore_backup()
    else: 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
     # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן שטלמדיה תתחבר[/COLOR]' % COLOR2)
elif mode==5:
    
   Addon.openSettings()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
