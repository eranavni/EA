# -*- coding: utf-8 -*-
import xbmc,time,xbmcaddon,os,requests,xbmcgui,re,logging,threading,urllib,json,datetime

Addon = xbmcaddon.Addon()

START=True

COLOR2='yellow'
COLOR1='white'
ADDONTITLE='Media Sync'
iconx = Addon.getAddonInfo('icon')
DIALOG         = xbmcgui.Dialog()

def LogNotify(title, message, times=2000, icon=iconx,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound) 


monitor = xbmc.Monitor()

strings = time.strftime("%Y,%m,%d,%H,%M,%S")
t = strings.split(',')
numbers = [ int(x) for x in t ]
pre_date=numbers[2]
while not monitor.abortRequested():
 
    if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            
            break
    
   

 
    START=False
    strings = time.strftime("%Y,%m,%d,%H,%M,%S")
    t = strings.split(',')
    numbers = [ int(x) for x in t ]
    
    if numbers[3]==int(Addon.getSetting("update")) and numbers[2]!=pre_date:

        
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מסנכרן נתונים בערוץ[/COLOR]' % COLOR2)
        pre_date=numbers[2]
        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=3&url=www)")

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון הסתיים[/COLOR]' % COLOR2)

       
    xbmc.sleep(1000)
del monitor


